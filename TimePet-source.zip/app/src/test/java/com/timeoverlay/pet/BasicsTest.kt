package com.timeoverlay.pet

import com.timeoverlay.pet.data.Category
import com.timeoverlay.pet.data.DefaultCategories
import com.timeoverlay.pet.data.TimeFormat
import org.junit.Assert.assertEquals
import org.junit.Test

class BasicsTest {

    @Test
    fun `tiktok is lazy by default`() {
        assertEquals(
            Category.LAZY,
            DefaultCategories.guess("com.zhiliaoapp.musically")
        )
    }

    @Test
    fun `anki and obsidian are productive by default`() {
        assertEquals(Category.PRODUCTIVE, DefaultCategories.guess("com.ichi2.anki"))
        assertEquals(Category.PRODUCTIVE, DefaultCategories.guess("md.obsidian"))
    }

    @Test
    fun `youtube browser messenger are neutral by default`() {
        assertEquals(
            Category.NEUTRAL,
            DefaultCategories.guess("app.google.android.youtube")
        )
        assertEquals(
            Category.NEUTRAL, DefaultCategories.guess("com.android.chrome")
        )
        assertEquals(
            Category.NEUTRAL, DefaultCategories.guess("org.telegram.messenger")
        )
    }

    @Test
    fun `time formats`() {
        assertEquals("0:00", TimeFormat.short(0))
        assertEquals("1:05", TimeFormat.short(65_000))
        assertEquals("2:03:04", TimeFormat.short(7_384_000))
        assertEquals("5 min", TimeFormat.long(300_000, "h", "min", "s"))
        assertEquals("1 h 30 min", TimeFormat.long(5_400_000, "h", "min", "s"))
    }
}
