package com.timeoverlay.pet

import com.timeoverlay.pet.pet.PetAction
import com.timeoverlay.pet.pet.PetAtlas
import com.timeoverlay.pet.pet.PetClip
import com.timeoverlay.pet.pet.PetDef
import com.timeoverlay.pet.pet.PetMove
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Раскладка кадров всех питомцев: в пределах атласа 8x9, состояния настроения различимы. */
class PetDefTest {

    @Test
    fun `every clip stays inside the 8x9 atlas`() {
        for (pet in PetDef.ALL) for (action in PetAction.values()) {
            val clip = pet.clip(action)
            for (i in clip.frames.indices) {
                assertTrue("${pet.id}/$action col", clip.frames[i] in 0 until PetAtlas.COLS)
                assertTrue("${pet.id}/$action row", clip.rowAt(i) in 0 until PetAtlas.ROWS)
                assertTrue("${pet.id}/$action duration", clip.durations[i] > 0)
            }
            assertTrue("${pet.id}/$action still", clip.still in clip.frames.indices)
        }
    }

    @Test
    fun `mood states use their own clips for every pet`() {
        val moods = listOf(PetAction.IDLE, PetAction.HAPPY, PetAction.SAD, PetAction.TIRED, PetAction.SLEEP, PetAction.EXHAUSTED)
        for (pet in PetDef.ALL) {
            for (a in moods) assertTrue("${pet.id} lacks $a", pet.has(a))
            // Грусть и сон не должны совпадать с idle по первому кадру — иначе состояние не видно.
            val idle = pet.clip(PetAction.IDLE)
            for (a in listOf(PetAction.SAD, PetAction.SLEEP)) {
                val c = pet.clip(a)
                assertNotEquals("${pet.id}/$a looks like idle", idle.rowAt(idle.still) to idle.frames[idle.still], c.rowAt(c.still) to c.frames[c.still])
            }
        }
    }

    @Test
    fun `missing clips fall back to a sensible one`() {
        val minimal = PetDef(
            "t", "T", "t", 0, false, emptySet(),
            mapOf(
                PetAction.IDLE to PetClip(0, intArrayOf(0), longArrayOf(100)),
                PetAction.SAD to PetClip(5, intArrayOf(0), longArrayOf(100))
            )
        )
        assertEquals(5, minimal.clip(PetAction.EXHAUSTED).row)
        assertEquals(5, minimal.clip(PetAction.LIE).row)
        assertEquals(0, minimal.clip(PetAction.HAPPY).row)
        assertEquals(0, minimal.clip(PetAction.WALK_RIGHT).row)
    }

    @Test
    fun `moves are backed by clips`() {
        for (pet in PetDef.ALL) for (m in pet.moves) {
            val needed = when (m) {
                PetMove.WALK, PetMove.SLIDE -> listOf(PetAction.WALK_LEFT, PetAction.WALK_RIGHT)
                PetMove.RUN -> listOf(PetAction.RUN_LEFT, PetAction.RUN_RIGHT)
                PetMove.JUMP -> listOf(PetAction.JUMP)
                PetMove.SIT -> listOf(PetAction.SIT)
                PetMove.LIE -> listOf(PetAction.LIE)
                PetMove.LOOK_AROUND -> listOf(PetAction.LOOK_AROUND)
                PetMove.WAVE -> listOf(PetAction.WAVE)
                PetMove.STRETCH -> listOf(PetAction.STRETCH)
                PetMove.WOBBLE -> listOf(PetAction.WOBBLE)
                PetMove.PEEK -> listOf(PetAction.LOOK_AROUND)
            }
            for (a in needed) assertTrue("${pet.id}: $m needs $a", pet.has(a))
        }
    }

    @Test
    fun `unknown pet id falls back to mimi`() {
        assertEquals("mimi", PetDef.byId("nope").id)
        assertEquals("wally", PetDef.byId("wally").id)
    }
}
