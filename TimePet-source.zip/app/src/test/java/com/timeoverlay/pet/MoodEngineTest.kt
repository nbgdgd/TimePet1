package com.timeoverlay.pet.mood

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MoodEngineTest {

    @Test
    fun `short fun inside allowance barely moves mood`() {
        // 10 минут развлечений внутри лимита 60: −1, частично смягчается отдыхом.
        val r = MoodEngine.compute(
            productiveMs = 0, lazyMs = 10 * 60_000L,
            awakeMs = 4 * 3_600_000L, screenMs = 10 * 60_000L,
            funAllowanceMinutes = 60, isNight = false
        )
        assertTrue("score=${r.score}", r.score in 58..65)
        assertEquals(MoodEngine.State.CONTENT, r.state)
    }

    @Test
    fun `productive day makes pet happy`() {
        val r = MoodEngine.compute(
            productiveMs = 120 * 60_000L, lazyMs = 20 * 60_000L,
            awakeMs = 8 * 3_600_000L, screenMs = 150 * 60_000L,
            funAllowanceMinutes = 60, isNight = false
        )
        assertEquals(MoodEngine.State.HAPPY, r.state)
    }

    @Test
    fun `long doomscrolling exhausts`() {
        // 8 часов ленты при 9 часах бодрствования: штраф упирается в потолок −40,
        // отдых почти нулевой — итог ниже 25.
        val r = MoodEngine.compute(
            productiveMs = 0, lazyMs = 480 * 60_000L,
            awakeMs = 9 * 3_600_000L, screenMs = 480 * 60_000L,
            funAllowanceMinutes = 60, isNight = false
        )
        assertEquals(MoodEngine.State.EXHAUSTED, r.state)
    }

    @Test
    fun `rest without phone caps at content`() {
        // Телефон почти не трогали весь день: отдых тянет вверх, но не к счастью.
        val r = MoodEngine.compute(
            productiveMs = 0, lazyMs = 0,
            awakeMs = 12 * 3_600_000L, screenMs = 5 * 60_000L,
            funAllowanceMinutes = 60, isNight = false
        )
        assertTrue(r.score <= 72)
        assertEquals(MoodEngine.State.CONTENT, r.state)
    }

    @Test
    fun `night means sleep`() {
        val r = MoodEngine.compute(
            productiveMs = 200 * 60_000L, lazyMs = 0,
            awakeMs = 1 * 3_600_000L, screenMs = 200 * 60_000L,
            funAllowanceMinutes = 60, isNight = true
        )
        assertEquals(MoodEngine.State.SLEEP, r.state)
    }

    @Test
    fun `productivity score needs data`() {
        assertEquals(-1, MoodEngine.productivityScore(0, 0, 0, 60))
    }

    @Test
    fun `productivity score is transparent`() {
        // 60 продуктивных, 0 ленивых, 60 нейтральных -> 50.
        assertEquals(
            50,
            MoodEngine.productivityScore(3_600_000, 0, 3_600_000, 60)
        )
    }

    @Test
    fun `treat bonus lifts mood and is capped at 100`() {
        val base = MoodEngine.compute(0, 0, 0, 0, 60, isNight = false)
        val treat = MoodEngine.compute(0, 0, 0, 0, 60, isNight = false, bonus = 10)
        assertEquals(base.score + 10, treat.score)
        val max = MoodEngine.compute(3_600_000, 0, 0, 0, 60, isNight = false, bonus = 100)
        assertEquals(100, max.score)
        assertEquals(MoodEngine.State.HAPPY, max.state)
    }

    @Test
    fun `night makes sleep unless awake`() {
        assertEquals(MoodEngine.State.SLEEP, MoodEngine.compute(0, 0, 0, 0, 60, isNight = true).state)
        assertEquals(MoodEngine.State.CONTENT, MoodEngine.compute(0, 0, 0, 0, 60, isNight = false).state)
    }
}
