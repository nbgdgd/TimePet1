package com.timeoverlay.pet

import com.timeoverlay.pet.data.DayLedger
import com.timeoverlay.pet.data.DayLedger.Companion.ACTIVITY_PAUSED
import com.timeoverlay.pet.data.DayLedger.Companion.ACTIVITY_RESUMED
import com.timeoverlay.pet.data.DayLedger.Companion.ACTIVITY_STOPPED
import com.timeoverlay.pet.data.DayLedger.Companion.KEYGUARD_SHOWN
import com.timeoverlay.pet.data.DayLedger.Companion.SCREEN_INTERACTIVE
import com.timeoverlay.pet.data.DayLedger.Companion.SCREEN_NON_INTERACTIVE
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class DayLedgerTest {

    private val day = 1_000_000L
    private fun e(type: Int, pkg: String?, t: Long, cls: String? = null) =
        DayLedger.Event(type, pkg, day + t, cls ?: pkg)

    @Test
    fun `switching apps continues today's total instead of resetting`() {
        val l = DayLedger(day)
        l.apply(e(ACTIVITY_RESUMED, "tiktok", 0))
        l.apply(e(ACTIVITY_PAUSED, "tiktok", 5_000))
        l.apply(e(ACTIVITY_RESUMED, "telegram", 5_000))
        l.apply(e(ACTIVITY_STOPPED, "tiktok", 5_100))
        l.apply(e(ACTIVITY_PAUSED, "telegram", 8_000))
        l.apply(e(ACTIVITY_RESUMED, "tiktok", 8_000))
        assertEquals("tiktok", l.foregroundPackage)
        // 5 с до переключения + 2 с после возврата.
        assertEquals(7_000L, l.totalOf("tiktok", day + 10_000))
        assertEquals(3_000L, l.totalOf("telegram", day + 10_000))
        assertEquals(10_000L, l.totalMillis(day + 10_000))
    }

    @Test
    fun `screen off and keyguard stop the clock`() {
        val l = DayLedger(day)
        l.apply(e(ACTIVITY_RESUMED, "tiktok", 0))
        l.apply(e(SCREEN_NON_INTERACTIVE, "android", 4_000))
        l.apply(e(ACTIVITY_PAUSED, "tiktok", 4_050))
        l.apply(e(KEYGUARD_SHOWN, "android", 4_100))
        l.apply(e(SCREEN_INTERACTIVE, "android", 60_000))
        // На экране блокировки ничего не считается.
        assertNull(l.foregroundPackage)
        assertEquals(4_000L, l.totalOf("tiktok", day + 70_000))
        l.apply(e(ACTIVITY_RESUMED, "tiktok", 70_000))
        assertEquals(5_000L, l.totalOf("tiktok", day + 71_000))
    }

    @Test
    fun `two-pane settings keep the package open until all activities stop`() {
        // Реальная последовательность двухпанельных Настроек на планшете.
        val l = DayLedger(day)
        l.apply(e(ACTIVITY_RESUMED, "settings", 0, "Home"))
        l.apply(e(ACTIVITY_RESUMED, "settings", 100, "Home2"))
        l.apply(e(ACTIVITY_PAUSED, "settings", 200, "Home2"))
        l.apply(e(ACTIVITY_RESUMED, "settings", 300, "Network"))
        l.apply(e(ACTIVITY_STOPPED, "settings", 400, "Home2"))
        assertEquals("settings", l.foregroundPackage)
        assertEquals(10_000L, l.totalOf("settings", day + 10_000))
        l.apply(e(ACTIVITY_PAUSED, "settings", 10_000, "Network"))
        l.apply(e(ACTIVITY_PAUSED, "settings", 10_000, "Home"))
        assertNull(l.foregroundPackage)
        assertEquals(10_000L, l.totalOf("settings", day + 20_000))
    }

    @Test
    fun `duplicate resumed events do not double count`() {
        val l = DayLedger(day)
        l.apply(e(ACTIVITY_RESUMED, "a", 0))
        l.apply(e(ACTIVITY_RESUMED, "a", 1_000)) // повтор той же Activity
        l.apply(e(ACTIVITY_PAUSED, "a", 3_000))
        assertEquals(3_000L, l.totalOf("a", day + 10_000))
        // PAUSED чужого пакета не закрывает текущий.
        l.apply(e(ACTIVITY_RESUMED, "b", 10_000))
        l.apply(e(ACTIVITY_PAUSED, "a", 11_000))
        assertEquals("b", l.foregroundPackage)
        assertEquals(2_000L, l.totalOf("b", day + 12_000))
    }

    @Test
    fun `events before day start are clamped to midnight`() {
        val l = DayLedger(day)
        l.apply(DayLedger.Event(ACTIVITY_RESUMED, "a", day - 5_000))
        assertEquals(2_000L, l.totalOf("a", day + 2_000))
    }

    @Test
    fun `closeOpen freezes the running interval`() {
        val l = DayLedger(day)
        l.apply(e(ACTIVITY_RESUMED, "a", 0))
        l.closeOpen(day + 3_000)
        assertNull(l.foregroundPackage)
        assertEquals(3_000L, l.totalOf("a", day + 30_000))
    }
}
