package com.timeoverlay.pet

import com.timeoverlay.pet.data.Category
import com.timeoverlay.pet.data.DayLedger
import com.timeoverlay.pet.data.DefaultCategories
import com.timeoverlay.pet.data.Reminders
import com.timeoverlay.pet.overlay.PetBehavior
import com.timeoverlay.pet.pet.PetDef
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Логика раунда 7: напоминания, база категорий, восстановление интервала, профиль движения, характеры. */
class Round7Test {

    private val day = 24 * 60 * 60_000L

    @Test
    fun `reminders normal schedule 2-3, 5-7, then weekly`() {
        assertFalse(Reminders.isDue(2, 1, 0, day))
        assertTrue(Reminders.isDue(2, 2, 0, day))
        assertFalse(Reminders.isDue(2, 4, 1, 2 * day))
        assertTrue(Reminders.isDue(2, 5, 1, 3 * day))
        assertFalse(Reminders.isDue(2, 10, 2, 6 * day))
        assertTrue(Reminders.isDue(2, 12, 2, 7 * day))
        // Дважды в один день не шлём.
        assertFalse(Reminders.isDue(2, 5, 1, 0L))
    }

    @Test
    fun `reminders rare is slower and off never fires`() {
        assertFalse(Reminders.isDue(1, 3, 0, day))
        assertTrue(Reminders.isDue(1, 4, 0, day))
        assertFalse(Reminders.isDue(1, 12, 2, 13 * day))
        assertTrue(Reminders.isDue(1, 12, 2, 14 * day))
        assertFalse(Reminders.isDue(0, 30, 0, 30 * day))
    }

    @Test
    fun `builtin category database is case-insensitive and knows the priorities`() {
        assertEquals(Category.LAZY, DefaultCategories.lookup("com.miHoYo.GenshinImpact"))
        assertEquals(Category.LAZY, DefaultCategories.lookup("COM.ZHILIAOAPP.MUSICALLY"))
        assertEquals(Category.PRODUCTIVE, DefaultCategories.lookup("com.duolingo"))
        assertEquals(Category.NEUTRAL, DefaultCategories.lookup("org.telegram.messenger"))
        assertEquals(Category.NEUTRAL, DefaultCategories.lookup("com.google.android.youtube"))
        assertNull(DefaultCategories.lookup("com.example.unknown.app"))
        assertEquals(Category.NEUTRAL, DefaultCategories.guess("com.example.unknown.app"))
    }

    @Test
    fun `ledger reopen restores the foreground package only when nothing is open`() {
        val l = DayLedger(0L)
        l.reopen("a", 1_000L)
        assertEquals("a", l.foregroundPackage)
        assertEquals(4_000L, l.totalOf("a", 5_000L))
        l.reopen("b", 6_000L)
        assertEquals("a", l.foregroundPackage)
        l.apply(DayLedger.Event(DayLedger.ACTIVITY_PAUSED, "a", 7_000L, "a"))
        assertNull(l.foregroundPackage)
        assertEquals(6_000L, l.totalOf("a", 9_000L))
    }

    @Test
    fun `motion profile is monotonic, starts slow and ends at 1`() {
        val ramp = 300f
        val cruise = 1_000f
        var prev = 0f
        var e = 0f
        while (e <= ramp * 2 + cruise) {
            val p = PetBehavior.motionProgress(e, ramp, cruise)
            assertTrue("monotonic at $e", p >= prev)
            prev = p
            e += 10f
        }
        assertEquals(1f, PetBehavior.motionProgress(ramp * 2 + cruise, ramp, cruise), 1e-4f)
        // Разгон: за первые 10 % времени пройдено меньше 10 % пути.
        assertTrue(PetBehavior.motionProgress(160f, ramp, cruise) < 0.1f)
        // Середина хода — ровно половина пути.
        assertEquals(0.5f, PetBehavior.motionProgress(ramp + cruise / 2, ramp, cruise), 1e-3f)
    }

    @Test
    fun `pets differ in temper and three are free`() {
        assertTrue(PetDef.MIMI.temper.walkRate < PetDef.EIGENBLOB.temper.walkRate)
        assertTrue(PetDef.MIMI.temper.runChance > PetDef.EIGENBLOB.temper.runChance)
        assertTrue(PetDef.EIGENBLOB.temper.restChance > PetDef.MIMI.temper.restChance)
        assertEquals(3, PetDef.ALL.count { it.unlock == null })
        assertEquals(7, PetDef.ALL.size)
        for (p in PetDef.ALL.filter { it.unlock != null }) {
            assertTrue("${p.id} unlock", p.unlock!!.minutes > 0 && p.unlock!!.days > 0)
        }
    }
}
