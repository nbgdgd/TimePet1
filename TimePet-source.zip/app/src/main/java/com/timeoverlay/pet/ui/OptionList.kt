package com.timeoverlay.pet.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.timeoverlay.pet.R

/**
 * Список вариантов «строка с галочкой» (как уровень активности в референсе):
 * строки в одном скруглённом контейнере, выбранная подсвечена и отмечена.
 */
class OptionList(private val container: ViewGroup, labels: List<String>, private val onPick: (Int) -> Unit) {

    private val rows = ArrayList<View>()
    private var selected = -1

    init {
        val inflater = LayoutInflater.from(container.context)
        container.removeAllViews()
        for ((i, label) in labels.withIndex()) {
            val row = inflater.inflate(R.layout.item_option_row, container, false)
            row.findViewById<TextView>(R.id.optionText).text = label
            row.setOnClickListener {
                if (selected != i) {
                    select(i)
                    onPick(i)
                }
            }
            container.addView(row)
            rows.add(row)
        }
    }

    fun select(index: Int) {
        selected = index
        val ctx = container.context
        for ((i, row) in rows.withIndex()) {
            val on = i == index
            row.findViewById<View>(R.id.optionCheck).visibility = if (on) View.VISIBLE else View.INVISIBLE
            row.setBackgroundColor(if (on) ctx.themeColor(R.attr.tp_track) else 0)
        }
    }

    fun setLabel(index: Int, text: String) {
        rows.getOrNull(index)?.findViewById<TextView>(R.id.optionText)?.text = text
    }
}
