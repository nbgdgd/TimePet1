package com.timeoverlay.pet.pet

/**
 * Один клип поверх атласа: ряд, колонки и длительности кадров (мс).
 * Если задан [rows], каждый кадр берётся из своего ряда (кадры одного
 * действия у авторов атласов часто разбросаны по разным рядам).
 */
class PetClip(
    val row: Int,
    val frames: IntArray,
    val durations: LongArray,
    /** false — клип играет один раз и возвращает к базовому состоянию. */
    val loop: Boolean = true,
    private val rows: IntArray? = null,
    /** Кадр для режима без анимации (один статичный кадр состояния). */
    val still: Int = 0,
    /** Рисовать зеркально по горизонтали (ряд «бег» в атласах смотрит вправо). */
    val mirror: Boolean = false
) {
    init {
        require(frames.size == durations.size) { "frames/durations mismatch" }
        require(rows == null || rows.size == frames.size) { "rows/frames mismatch" }
        require(still in frames.indices) { "still out of range" }
    }

    fun rowAt(index: Int): Int = rows?.get(index) ?: row
}

/**
 * Действия питомца. Каждый питомец ([PetDef]) сопоставляет их
 * с кадрами своего атласа по-своему; чего нет — [PetDef.clip] подставляет
 * ближайшее по смыслу.
 */
enum class PetAction {
    IDLE, HAPPY, WALK_RIGHT, WALK_LEFT, RUN_RIGHT, RUN_LEFT, WAVE, JUMP, CELEBRATE,
    SAD, EXHAUSTED, SLEEP, TIRED, WORK, REVIEW,
    /** Недовольный взгляд: вход в развлекательное приложение сверх лимита. */
    ANNOYED,
    /** Самостоятельные действия поверх приложений. */
    LOOK_AROUND, SIT, LIE, STRETCH, WOBBLE
}

/** Что питомец умеет делать сам, поверх приложений. */
enum class PetMove {
    WALK, RUN, SLIDE, JUMP, SIT, LIE, LOOK_AROUND, WAVE, STRETCH, WOBBLE, PEEK
}
