package com.timeoverlay.pet.data

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.timeoverlay.pet.R
import com.timeoverlay.pet.pet.PetDef
import com.timeoverlay.pet.overlay.OverlayPrefs
import com.timeoverlay.pet.ui.MainActivity
import java.util.Calendar

/**
 * Мягкие напоминания, когда пользователь давно не заходил в TimePet.
 *
 * Раз в сутки (неточный будильник около полудня) проверяется, сколько дней
 * прошло с последнего открытия. «Обычно»: первый день тишина, одно
 * напоминание на 2–3 день, следующее на 5–7, дальше не чаще раза в неделю.
 * «Редко»: 4 дня, 10 дней, затем раз в две недели. Открытие приложения
 * сбрасывает цикл. Одно уведомление с одним id — дублей и очередей нет.
 *
 * Без системного разрешения на уведомления ничего не отправляется; экран
 * настроек показывает реальный статус.
 */
object Reminders {

    private const val CHANNEL = "reminders"
    private const val NOTIF_ID = 2
    private const val REQ = 20
    private const val DAY_MS = 24 * 60 * 60_000L

    /** Пороги в днях: первое, второе, дальше — период. */
    private val NORMAL = intArrayOf(2, 5, 7)
    private val RARE = intArrayOf(4, 10, 14)

    /** Пользователь открыл приложение: цикл заново, висящее напоминание убрать. */
    fun onAppOpened(context: Context) {
        val prefs = AppPrefs(context)
        prefs.lastOpenAt = System.currentTimeMillis()
        prefs.reminderStage = 0
        prefs.lastReminderAt = 0L
        NotificationManagerCompat.from(context).cancel(NOTIF_ID)
        schedule(context)
    }

    fun canNotify(context: Context): Boolean = NotificationManagerCompat.from(context).areNotificationsEnabled()

    /** Ежедневная неточная проверка около полудня; при «Выкл» будильник снимается. */
    fun schedule(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(context)
        if (AppPrefs(context).reminders == 0) {
            am.cancel(pi)
            return
        }
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 12); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        runCatching { am.setInexactRepeating(AlarmManager.RTC_WAKEUP, c.timeInMillis, AlarmManager.INTERVAL_DAY, pi) }
    }

    private fun pending(context: Context): PendingIntent = PendingIntent.getBroadcast(
        context, REQ, Intent(context, ReminderReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** Проверка по будильнику. Возвращает true, если напоминание ушло. */
    fun check(context: Context, nowMs: Long = System.currentTimeMillis()): Boolean {
        val prefs = AppPrefs(context)
        val level = prefs.reminders
        if (level == 0 || !canNotify(context)) return false
        val lastOpen = prefs.lastOpenAt
        if (lastOpen <= 0L) {
            prefs.lastOpenAt = nowMs
            return false
        }
        val daysAway = ((nowMs - lastOpen) / DAY_MS).toInt()
        val stage = prefs.reminderStage
        if (!isDue(level, daysAway, stage, nowMs - prefs.lastReminderAt)) return false
        notify(context, stage)
        prefs.reminderStage = stage + 1
        prefs.lastReminderAt = nowMs
        return true
    }

    /**
     * Пора ли напоминать: [level] 1 редко / 2 обычно, [daysAway] дней с последнего
     * открытия, [stage] сколько напоминаний уже ушло, [sinceLastMs] — с последнего.
     */
    fun isDue(level: Int, daysAway: Int, stage: Int, sinceLastMs: Long): Boolean {
        if (level == 0) return false
        val t = if (level == 1) RARE else NORMAL
        return when (stage) {
            0 -> daysAway >= t[0]
            1 -> daysAway >= t[1] && sinceLastMs >= DAY_MS
            else -> sinceLastMs >= t[2] * DAY_MS
        }
    }

    private fun notify(context: Context, stage: Int) {
        val loc = AppPrefs(context).localized(context)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, loc.getString(R.string.reminder_channel), NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val pet = PetDef.byId(OverlayPrefs(context).petId).displayName
        val texts = loc.resources.getStringArray(R.array.reminder_texts)
        val text = texts[stage.coerceIn(0, texts.size - 1)].replace("%s", pet)
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_pet)
            .setContentTitle(loc.getString(R.string.reminder_title, pet))
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(NOTIF_ID, n) }
    }
}

/** Будильник напоминаний. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Reminders.check(context)
    }
}
