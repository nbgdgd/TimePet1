package com.timeoverlay.pet

import android.app.Application
import com.timeoverlay.pet.data.AppPrefs
import com.timeoverlay.pet.data.PermissionHelper
import com.timeoverlay.pet.overlay.OverlayPrefs
import com.timeoverlay.pet.overlay.PetOverlayService

class TimePetApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Язык AppCompat хранит сам (autoStoreLocales в манифесте) и применяет к экранам.
        AppPrefs(this).applyTheme()
        // Процесс подняли заново (после выгрузки системой): если питомец был включён — вернуть,
        // не дожидаясь открытия приложения.
        val overlay = OverlayPrefs(this)
        if (overlay.enabled && !PetOverlayService.running && PermissionHelper.hasOverlayRequired(this)) {
            runCatching { PetOverlayService.start(this) }
        }
    }
}
