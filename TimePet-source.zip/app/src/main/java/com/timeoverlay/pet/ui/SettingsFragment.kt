package com.timeoverlay.pet.ui

import android.os.Bundle
import androidx.core.content.ContextCompat
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.GradientDrawable
import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.google.android.material.button.MaterialButton
import com.google.android.material.slider.Slider
import com.timeoverlay.pet.R
import com.timeoverlay.pet.data.AppCategoryStore
import com.timeoverlay.pet.data.AppPrefs
import com.timeoverlay.pet.data.HistoryStore
import com.timeoverlay.pet.data.PermissionHelper

/** Настройки: тема, лимит развлечений, доступ, данные, как считается настроение, авторство. */
class SettingsFragment : Fragment() {

    private lateinit var store: AppCategoryStore
    private lateinit var appPrefs: AppPrefs

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_settings, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        store = AppCategoryStore(requireContext())
        appPrefs = AppPrefs(requireContext())
        view.findViewById<View>(R.id.backButton).setOnClickListener { requireActivity().finish() }
        setupTheme(view)
        setupLanguage(view)
        setupLimit(view)
        setupPermissions(view)
        setupData(view)
    }

    override fun onResume() {
        super.onResume()
        refreshPermission()
    }

    /** Темы как в Telegram: карточки базовых тем и кружки акцента. */
    private fun setupTheme(v: View) {
        val cards = v.findViewById<ViewGroup>(R.id.themeCards)
        val inflater = LayoutInflater.from(v.context)
        val ids = listOf(ThemeManager.SYSTEM) + ThemeManager.THEMES
        val previews = ArrayList<Pair<String, ThemePreviewView>>()
        for (id in ids) {
            val card = inflater.inflate(R.layout.item_theme_card, cards, false)
            val preview = card.findViewById<ThemePreviewView>(R.id.themePreview)
            val p = palette(v.context, id)
            preview.set(p[0], p[1], p[2], p.getOrNull(3), p.getOrNull(4))
            card.findViewById<TextView>(R.id.themeName).setText(themeName(id))
            card.setOnClickListener {
                if (appPrefs.themeId == id) return@setOnClickListener
                appPrefs.themeId = id
                ThemeManager.bump()
                requireActivity().recreate()
            }
            cards.addView(card)
            previews.add(id to preview)
        }
        for ((id, preview) in previews) preview.setChosen(id == appPrefs.themeId)

        val row = v.findViewById<ViewGroup>(R.id.accentRow)
        val d = resources.displayMetrics.density
        val size = (34 * d).toInt()
        for ((i, color) in ThemeManager.ACCENT_PREVIEW.withIndex()) {
            val dot = View(v.context)
            dot.background = ContextCompat.getDrawable(v.context, R.drawable.bg_accent_dot)?.mutate()
            dot.backgroundTintList = ColorStateList.valueOf(color)
            val lp = ViewGroup.MarginLayoutParams(size, size)
            lp.marginEnd = (10 * d).toInt()
            dot.layoutParams = lp
            if (i == appPrefs.accent) {
                // Выбранный: кольцо в цвете акцента с зазором.
                val ring = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(color)
                    setStroke((3 * d).toInt(), v.context.themeColor(R.attr.tp_card_bg))
                }
                val outer = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
                dot.background = LayerDrawable(arrayOf(outer, ring)).apply {
                    val inset = (3 * d).toInt()
                    setLayerInset(1, inset, inset, inset, inset)
                }
                dot.backgroundTintList = null
            }
            dot.setOnClickListener {
                if (appPrefs.accent == i) return@setOnClickListener
                appPrefs.accent = i
                ThemeManager.bump()
                requireActivity().recreate()
            }
            row.addView(dot)
        }
    }

    private fun themeName(id: String): Int = when (id) {
        "classic" -> R.string.theme_classic
        "day" -> R.string.theme_day
        "tinted" -> R.string.theme_tinted
        "night" -> R.string.theme_night
        "amoled" -> R.string.theme_amoled
        else -> R.string.theme_system
    }

    /** Цвета превью из самой темы: фон, карточка, акцент (+ вторая пара для «как в системе»). */
    private fun palette(ctx: android.content.Context, id: String): IntArray {
        fun of(themeId: String): IntArray {
            val themed = android.view.ContextThemeWrapper(ctx, ThemeManager.baseStyle(themeId))
            themed.theme.applyStyle(ThemeManager.accentStyle(appPrefs.accent, ThemeManager.isLight(themeId)), true)
            return intArrayOf(
                themed.themeColor(R.attr.tp_window_bg), themed.themeColor(R.attr.tp_card_bg), themed.themeColor(R.attr.tp_seed)
            )
        }
        if (id != ThemeManager.SYSTEM) return of(id)
        val day = of("day")
        val night = of("night")
        return intArrayOf(day[0], day[1], day[2], night[0], night[1])
    }

    private fun setupLanguage(v: View) {
        val tags = listOf("", "ru", "en", "de")
        val list = OptionList(
            v.findViewById(R.id.langList),
            listOf(getString(R.string.lang_system), getString(R.string.lang_ru), getString(R.string.lang_en), getString(R.string.lang_de))
        ) { i ->
            val tag = tags[i]
            if (tag != appPrefs.language) {
                appPrefs.language = tag
                // Экраны пересоздаются сами; данные и настройки не трогаются.
                appPrefs.applyLanguage()
            }
        }
        list.select(tags.indexOf(appPrefs.language).coerceAtLeast(0))
    }

    private fun setupLimit(v: View) {
        val slider: Slider = v.findViewById(R.id.limitSlider)
        val value: TextView = v.findViewById(R.id.limitValue)
        val explain: TextView = v.findViewById(R.id.limitExplain)
        fun show(m: Int) {
            value.text = getString(R.string.limit_minutes, m)
            explain.text = getString(R.string.limit_explain, m)
        }
        slider.value = store.funAllowanceMinutes.toFloat().coerceIn(0f, 240f)
        show(store.funAllowanceMinutes)
        slider.addOnChangeListener { _, s, _ ->
            val m = s.toInt()
            store.funAllowanceMinutes = m
            show(m)
        }
    }

    private fun setupPermissions(v: View) {
        v.findViewById<MaterialButton>(R.id.permUsageButton).setOnClickListener {
            startActivity(PermissionHelper.usageAccessIntent())
        }
        v.findViewById<MaterialButton>(R.id.permOverlayButton).setOnClickListener {
            startActivity(PermissionHelper.overlayPermissionIntent(requireContext()))
        }
    }

    private fun refreshPermission() {
        val v = view ?: return
        val usage = PermissionHelper.hasUsageAccess(requireContext())
        val ov = PermissionHelper.hasOverlayPermission(requireContext())
        v.findViewById<TextView>(R.id.permUsageStatus).text =
            getString(if (usage) R.string.perm_granted else R.string.perm_missing)
        v.findViewById<MaterialButton>(R.id.permUsageButton).apply {
            setText(if (usage) R.string.setup_done else R.string.setup_allow)
            isEnabled = !usage
        }
        v.findViewById<TextView>(R.id.permOverlayStatus).text =
            getString(if (ov) R.string.perm_granted else R.string.perm_missing)
        v.findViewById<MaterialButton>(R.id.permOverlayButton).apply {
            setText(if (ov) R.string.setup_done else R.string.setup_allow)
            isEnabled = !ov
        }
    }

    private fun setupData(v: View) {
        v.findViewById<MaterialButton>(R.id.deleteButton).setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setMessage(R.string.delete_confirm)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.delete) { _, _ ->
                    HistoryStore(requireContext()).clearAll()
                    Toast.makeText(requireContext(), R.string.delete_done, Toast.LENGTH_SHORT).show()
                }
                .show()
        }
        val formula: TextView = v.findViewById(R.id.formulaText)
        v.findViewById<MaterialButton>(R.id.formulaButton).setOnClickListener {
            formula.visibility = if (formula.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        v.findViewById<MaterialButton>(R.id.creditsButton).setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle(R.string.about_credits_title)
                .setMessage(R.string.credits_full)
                .setPositiveButton(android.R.string.ok, null)
                .show()
        }
    }
}
