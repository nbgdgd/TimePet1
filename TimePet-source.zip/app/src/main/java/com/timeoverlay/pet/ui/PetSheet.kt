package com.timeoverlay.pet.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.button.MaterialButton
import com.timeoverlay.pet.R
import com.timeoverlay.pet.data.UnlockStore
import com.timeoverlay.pet.mood.DayMood
import com.timeoverlay.pet.overlay.OverlayPrefs
import com.timeoverlay.pet.pet.PetAction
import com.timeoverlay.pet.pet.PetCredits
import com.timeoverlay.pet.pet.PetDef
import java.util.concurrent.Executors

/**
 * Выбор персонажа: вертикальный список; нажатие раскрывает карточку прямо
 * в строке (превью, характер, описание, условие открытия и прогресс,
 * лицензия) с кнопкой «Применить». Просмотр не меняет питомца.
 */
class PetSheet : BottomSheetDialogFragment() {

    private val io = Executors.newSingleThreadExecutor()
    private lateinit var overlay: OverlayPrefs
    private lateinit var unlocks: UnlockStore
    private var shown: PetDef? = null
    private val rows = HashMap<String, View>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.sheet_pet, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        overlay = OverlayPrefs(requireContext())
        unlocks = UnlockStore(requireContext())
        val list = view.findViewById<ViewGroup>(R.id.petList)
        val inflater = LayoutInflater.from(view.context)
        val progress = unlocks.progress()
        for (def in PetDef.ALL) {
            val row = inflater.inflate(R.layout.item_pet_row, list, false)
            val preview = row.findViewById<PetSpriteView>(R.id.petPreview)
            preview.preview = true
            preview.setPet(def)
            val open = unlocks.isUnlocked(def, progress)
            // Закрытый — силуэт: только форма, без деталей.
            preview.alpha = if (open) 1f else 0.35f
            row.findViewById<TextView>(R.id.petName).text = def.displayName
            row.findViewById<TextView>(R.id.petTemper).setText(temperRes(def))
            row.findViewById<TextView>(R.id.detailDesc).setText(PetCredits.descRes(def))
            row.findViewById<TextView>(R.id.detailLicense).setText(PetCredits.licenseRes(def))
            row.findViewById<View>(R.id.petHeader).setOnClickListener { toggle(def) }
            row.findViewById<MaterialButton>(R.id.applyButton).setOnClickListener { apply(def) }
            list.addView(row)
            rows[def.id] = row
        }
        refreshStates()
        val initial = PetDef.byId(arguments?.getString("pet") ?: overlay.petId)
        toggle(initial)
        io.execute {
            val state = DayMood.todayState(view.context)
            activity?.runOnUiThread {
                if (!isAdded) return@runOnUiThread
                for (r in rows.values) r.findViewById<PetSpriteView>(R.id.petPreview).setMood(state)
            }
        }
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }

    /** Раскрыть карточку персонажа (повторное нажатие сворачивает). */
    private fun toggle(def: PetDef) {
        val next = if (shown?.id == def.id) null else def
        shown = next
        for ((id, row) in rows) {
            val on = id == next?.id
            row.findViewById<View>(R.id.petDetail).visibility = if (on) View.VISIBLE else View.GONE
            row.setBackgroundResource(if (on) R.drawable.bg_pet_selected else R.drawable.bg_tile)
            if (on) row.findViewById<PetSpriteView>(R.id.petPreview).play(PetAction.WAVE)
        }
        refreshStates()
    }

    private fun refreshStates() {
        val progress = unlocks.progress()
        for (def in PetDef.ALL) {
            val row = rows[def.id] ?: continue
            val open = unlocks.isUnlocked(def, progress)
            val current = def.id == overlay.petId
            row.findViewById<TextView>(R.id.petState).text = when {
                current -> getString(R.string.pet_applied)
                !open -> getString(R.string.pet_locked)
                else -> ""
            }
            val unlock = def.unlock
            val cond = row.findViewById<TextView>(R.id.detailUnlock)
            val prog = row.findViewById<TextView>(R.id.detailProgress)
            if (unlock == null || open) {
                cond.visibility = View.GONE
                prog.visibility = View.GONE
            } else {
                cond.visibility = View.VISIBLE
                prog.visibility = View.VISIBLE
                cond.text = getString(R.string.pet_unlock_cond, unlock.minutes, unlock.days)
                prog.text = getString(R.string.pet_progress_min, progress.minutes.coerceAtMost(unlock.minutes), unlock.minutes) +
                    "   " + getString(R.string.pet_progress_days, progress.days.coerceAtMost(unlock.days), unlock.days)
            }
            row.findViewById<MaterialButton>(R.id.applyButton).apply {
                isEnabled = open && !current
                setText(if (current) R.string.pet_applied else R.string.pet_apply)
            }
        }
    }

    private fun temperRes(def: PetDef): Int = when {
        def.temper.walkRate <= 0.8f -> R.string.pet_temper_active
        def.temper.walkRate >= 1.25f -> R.string.pet_temper_calm
        else -> R.string.pet_temper_normal
    }

    private fun apply(def: PetDef) {
        if (!unlocks.isUnlocked(def)) return
        overlay.petId = def.id
        (parentFragment as? PetFragment)?.onPetApplied()
        dismiss()
    }

    companion object {
        fun new(petId: String? = null): PetSheet = PetSheet().apply {
            arguments = Bundle().apply { putString("pet", petId) }
        }
    }
}
