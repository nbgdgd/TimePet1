package com.timeoverlay.pet.data

import android.content.Context
import android.content.SharedPreferences
import com.timeoverlay.pet.pet.PetDef
import java.time.LocalDate

/**
 * Постепенное открытие питомцев. Условие у каждого своё ([PetDef.unlock]):
 * столько-то продуктивных минут суммарно ИЛИ столько-то разных дней
 * с TimePet. Прогресс только растёт: день без телефона ничего не отнимает.
 *
 * Открытие запоминается навсегда; отдельно помечается, что праздник
 * уже показан, чтобы не повторять его.
 */
class UnlockStore(context: Context) {

    private val app = context.applicationContext
    private val prefs: SharedPreferences = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val history = HistoryStore(app)

    data class Progress(val minutes: Int, val days: Int)

    /** Отметить сегодняшний день как день использования. */
    fun markUsedToday(today: LocalDate = LocalDate.now()) {
        val key = today.toString()
        val days = prefs.getStringSet(KEY_DAYS, emptySet())?.toMutableSet() ?: HashSet()
        if (days.add(key)) prefs.edit().putStringSet(KEY_DAYS, days).apply()
    }

    fun progress(): Progress {
        val minutes = (history.allRecords().sumOf { it.productiveMs } / 60_000L).toInt()
        val days = prefs.getStringSet(KEY_DAYS, emptySet())?.size ?: 0
        return Progress(minutes, days)
    }

    fun isUnlocked(def: PetDef, p: Progress = progress()): Boolean {
        val u = def.unlock ?: return true
        if (prefs.getStringSet(KEY_UNLOCKED, emptySet())?.contains(def.id) == true) return true
        val ok = p.minutes >= u.minutes || p.days >= u.days
        if (ok) remember(def.id)
        return ok
    }

    private fun remember(id: String) {
        val s = prefs.getStringSet(KEY_UNLOCKED, emptySet())?.toMutableSet() ?: HashSet()
        if (s.add(id)) prefs.edit().putStringSet(KEY_UNLOCKED, s).apply()
    }

    /** Открытые, но ещё не отпразднованные; вызов помечает их показанными. */
    fun takeFreshlyUnlocked(): List<PetDef> {
        val p = progress()
        val shown = prefs.getStringSet(KEY_CELEBRATED, emptySet())?.toMutableSet() ?: HashSet()
        val fresh = PetDef.ALL.filter { it.unlock != null && isUnlocked(it, p) && !shown.contains(it.id) }
        if (fresh.isNotEmpty()) {
            shown.addAll(fresh.map { it.id })
            prefs.edit().putStringSet(KEY_CELEBRATED, shown).apply()
        }
        return fresh
    }

    /** Для отладки/тестов: считать всех уже отпразднованными (без анимации при первом запуске). */
    fun markAllCelebrated() {
        val p = progress()
        val ids = PetDef.ALL.filter { isUnlocked(it, p) }.map { it.id }.toSet()
        prefs.edit().putStringSet(KEY_CELEBRATED, ids).apply()
    }

    companion object {
        private const val PREFS = "unlocks"
        private const val KEY_DAYS = "days_used"
        private const val KEY_UNLOCKED = "unlocked"
        private const val KEY_CELEBRATED = "celebrated"
    }
}
