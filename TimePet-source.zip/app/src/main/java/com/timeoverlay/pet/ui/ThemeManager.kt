package com.timeoverlay.pet.ui

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.util.TypedValue
import com.timeoverlay.pet.R
import com.timeoverlay.pet.data.AppPrefs

/** Цвет из атрибута текущей темы (палитры тем - в themes.xml). */
fun Context.themeColor(attr: Int): Int {
    val tv = TypedValue()
    theme.resolveAttribute(attr, tv, true)
    return tv.data
}

/**
 * Темы как в Telegram: базовая (Классика, Дневная, Цветная, Ночная, AMOLED
 * или как в системе - Дневная/Ночная) плюс цвет акцента. Применяется в
 * onCreate каждой Activity; после смены в настройках экраны пересоздаются.
 */
object ThemeManager {

    const val SYSTEM = "system"
    val THEMES = listOf("classic", "day", "tinted", "night", "amoled")
    val LIGHT = setOf("classic", "day")

    @Volatile var version = 0
        private set

    fun bump() { version++ }

    fun resolved(context: Context, prefs: AppPrefs = AppPrefs(context)): String {
        val id = prefs.themeId
        if (id != SYSTEM) return id
        val night = context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK ==
            Configuration.UI_MODE_NIGHT_YES
        return if (night) "night" else "day"
    }

    fun isLight(id: String): Boolean = id in LIGHT

    fun apply(activity: Activity) {
        val prefs = AppPrefs(activity)
        val id = resolved(activity, prefs)
        activity.setTheme(baseStyle(id))
        activity.theme.applyStyle(accentStyle(prefs.accent, isLight(id)), true)
    }

    fun baseStyle(id: String): Int = when (id) {
        "classic" -> R.style.Theme_TimePet_Classic
        "tinted" -> R.style.Theme_TimePet_Tinted
        "night" -> R.style.Theme_TimePet_Night
        "amoled" -> R.style.Theme_TimePet_Amoled
        else -> R.style.Theme_TimePet_Day
    }

    private val ACCENTS_LIGHT = intArrayOf(
        R.style.ThemeOverlay_TimePet_Accent_Blue_Light, R.style.ThemeOverlay_TimePet_Accent_Cyan_Light,
        R.style.ThemeOverlay_TimePet_Accent_Green_Light, R.style.ThemeOverlay_TimePet_Accent_Pink_Light,
        R.style.ThemeOverlay_TimePet_Accent_Orange_Light, R.style.ThemeOverlay_TimePet_Accent_Purple_Light,
        R.style.ThemeOverlay_TimePet_Accent_Red_Light, R.style.ThemeOverlay_TimePet_Accent_Slate_Light,
        R.style.ThemeOverlay_TimePet_Accent_Gold_Light
    )
    private val ACCENTS_DARK = intArrayOf(
        R.style.ThemeOverlay_TimePet_Accent_Blue_Dark, R.style.ThemeOverlay_TimePet_Accent_Cyan_Dark,
        R.style.ThemeOverlay_TimePet_Accent_Green_Dark, R.style.ThemeOverlay_TimePet_Accent_Pink_Dark,
        R.style.ThemeOverlay_TimePet_Accent_Orange_Dark, R.style.ThemeOverlay_TimePet_Accent_Purple_Dark,
        R.style.ThemeOverlay_TimePet_Accent_Red_Dark, R.style.ThemeOverlay_TimePet_Accent_Slate_Dark,
        R.style.ThemeOverlay_TimePet_Accent_Gold_Dark
    )
    val ACCENT_COUNT = ACCENTS_LIGHT.size

    fun accentStyle(index: Int, light: Boolean): Int =
        (if (light) ACCENTS_LIGHT else ACCENTS_DARK)[index.coerceIn(0, ACCENT_COUNT - 1)]

    /** Цвета акцента для кружков выбора (тот же список, что в overlay-стилях). */
    val ACCENT_PREVIEW = intArrayOf(
        0xFF2F6BFF.toInt(), 0xFF1FA6DE.toInt(), 0xFF3E8E41.toInt(), 0xFFC2599B.toInt(), 0xFFC2782A.toInt(),
        0xFF6C5CE7.toInt(), 0xFFC4443C.toInt(), 0xFF5E7A99.toInt(), 0xFFB39A2A.toInt()
    )
}
