package com.timeoverlay.pet.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.timeoverlay.pet.R
import com.timeoverlay.pet.data.Category
import com.timeoverlay.pet.mood.MoodEngine
import com.timeoverlay.pet.mood.MoodText

/**
 * Плашка таймера (отдельное окно; питомец — в [PetHolderView] рядом):
 * иконка и название текущего приложения со стрелкой, знак категории
 * («+» продуктивное, «−» развлечение, «0» нейтральное) и крупный таймер,
 * короткий статус и строка настроения (лицо, полоска 0..100, %).
 *
 * Виды: полный; без названия приложения; простой (только знак и таймер);
 * свёрнутый (двойной тап) — то же, что простой, но меньше.
 *
 * Жесты: тап — открыть TimePet; двойной тап — свернуть/развернуть;
 * долгое нажатие — перетаскивание домашней точки (отпустить над крестиком
 * внизу экрана — убрать питомца).
 */
@SuppressLint("ViewConstructor")
class OverlayView(context: Context, private val listener: Listener) : LinearLayout(context) {

    interface Listener {
        fun onDragStart()
        fun onDragTo(rawX: Float, rawY: Float, downX: Float, downY: Float)
        fun onDragEnd()
        fun onToggleCollapse()
        fun onOpenApp()
    }

    private val appRow = LinearLayout(context)
    private val appIcon = ImageView(context)
    private val appName = TextView(context)
    private val chevron = ImageView(context)
    private val timerRow = LinearLayout(context)
    private val sign = TextView(context)
    val timer = TextView(context)
    private val status = TextView(context)
    private val moodRow = LinearLayout(context)
    private val moodFace = ImageView(context)
    private val bar = LimitBarView(context)
    private val moodPercent = TextView(context)

    private var dragging = false
    private var downRawX = 0f
    private var downRawY = 0f
    private var collapsed = false
    private var simple = false
    private var showAppName = true

    private val detector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            listener.onOpenApp()
            return true
        }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            listener.onToggleCollapse()
            return true
        }
        override fun onLongPress(e: MotionEvent) {
            dragging = true
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            listener.onDragStart()
        }
    })

    init {
        orientation = VERTICAL
        gravity = Gravity.START or Gravity.CENTER_VERTICAL
        background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(0xF0202127.toInt())
        }

        // Иконка + имя приложения + стрелка «открыть».
        appRow.orientation = HORIZONTAL
        appRow.gravity = Gravity.CENTER_VERTICAL
        appRow.addView(appIcon, LayoutParams(dp(16), dp(16)))
        appName.setTextColor(Color.WHITE)
        appName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        appName.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        appName.setSingleLine()
        appName.ellipsize = TextUtils.TruncateAt.END
        appName.includeFontPadding = false
        appRow.addView(appName, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(6) })
        chevron.setImageResource(R.drawable.ic_chevron_right)
        chevron.imageTintList = ColorStateList.valueOf(0x8CFFFFFF.toInt())
        appRow.addView(chevron, LayoutParams(dp(14), dp(14)).apply { marginStart = dp(2) })
        addView(appRow, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        // Знак категории + таймер.
        timerRow.orientation = HORIZONTAL
        timerRow.gravity = Gravity.CENTER_VERTICAL
        sign.gravity = Gravity.CENTER
        sign.setTextColor(Color.WHITE)
        sign.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        sign.includeFontPadding = false
        sign.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF8A94A6.toInt()) }
        timerRow.addView(sign, LayoutParams(dp(15), dp(15)).apply { marginEnd = dp(6) })
        timer.setTextColor(Color.WHITE)
        timer.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        timer.fontFeatureSettings = "tnum"
        timer.setSingleLine()
        timer.includeFontPadding = false
        timerRow.addView(timer, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
        addView(timerRow, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(3)
        })

        status.setTextColor(0x9EFFFFFF.toInt())
        status.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
        status.setSingleLine()
        status.ellipsize = TextUtils.TruncateAt.END
        status.includeFontPadding = false
        addView(status, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(2)
        })

        // Настроение: лицо, тонкая полоска 0..100 и процент — в цвете состояния.
        moodRow.orientation = HORIZONTAL
        moodRow.gravity = Gravity.CENTER_VERTICAL
        moodRow.addView(moodFace, LayoutParams(dp(13), dp(13)))
        moodRow.addView(bar, LayoutParams(0, dp(4), 1f).apply { marginStart = dp(6); marginEnd = dp(6) })
        moodPercent.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        moodPercent.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        moodPercent.fontFeatureSettings = "tnum"
        moodPercent.includeFontPadding = false
        moodPercent.setSingleLine()
        moodRow.addView(moodPercent, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
        addView(moodRow, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(6)
        })

        applyStyle(OverlayPrefs.DEFAULT_SIZE, collapsed = false, simple = false, showAppName = true)
    }

    /** Ширина плашки в полном виде фиксирована: текст статуса меняется, окно — нет. */
    fun applyStyle(sizeDp: Int, collapsed: Boolean, simple: Boolean, showAppName: Boolean) {
        this.collapsed = collapsed
        this.simple = simple
        this.showAppName = showAppName
        val mini = collapsed || simple
        val sp = if (collapsed) 14f else (11f + sizeDp / 6f).coerceIn(17f, 24f)
        timer.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        sign.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (collapsed) 9f else 10f)
        val ph = if (mini) dp(9) else dp(11)
        val pv = if (mini) dp(5) else dp(8)
        setPadding(ph, pv, ph, pv)
        val width = if (mini) LayoutParams.WRAP_CONTENT else dp(84 + (sizeDp * 0.7f).toInt())
        minimumWidth = if (mini) 0 else width
        appRow.visibility = if (mini || !showAppName) View.GONE else View.VISIBLE
        status.visibility = if (mini) View.GONE else View.VISIBLE
        moodRow.visibility = if (mini) View.GONE else View.VISIBLE
        requestLayout()
    }

    /** Ширина окна для WindowManager: фиксированная в полном виде, иначе по содержимому. */
    val preferredWidth: Int
        get() = if (collapsed || simple) LayoutParams.WRAP_CONTENT else minimumWidth

    fun setApp(icon: Drawable?, name: String) {
        appIcon.setImageDrawable(icon)
        appIcon.visibility = if (icon == null) View.GONE else View.VISIBLE
        appName.text = name
    }

    /** Знак категории текущего приложения. */
    fun setCategory(c: Category?) {
        val (text, color) = when (c) {
            Category.PRODUCTIVE -> "+" to ContextCompat.getColor(context, R.color.productive)
            Category.LAZY -> "−" to ContextCompat.getColor(context, R.color.lazy)
            Category.NEUTRAL -> "0" to ContextCompat.getColor(context, R.color.neutral)
            else -> "" to 0x00000000
        }
        sign.text = text
        sign.visibility = if (text.isEmpty()) View.GONE else View.VISIBLE
        (sign.background as? GradientDrawable)?.setColor(color)
    }

    fun setStatus(text: String) {
        status.text = text
    }

    /** Строка настроения: лицо и цвет по состоянию, полоска и процент по счёту 0..100. */
    fun setMood(state: MoodEngine.State, score: Int) {
        val color = ContextCompat.getColor(context, MoodText.colorRes(state))
        moodFace.setImageResource(MoodText.faceRes(state))
        moodFace.imageTintList = ColorStateList.valueOf(color)
        bar.set(score / 100f, color)
        moodPercent.text = "$score%"
        moodPercent.setTextColor(color)
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = true

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        detector.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downRawX = ev.rawX
                downRawY = ev.rawY
            }
            MotionEvent.ACTION_MOVE -> if (dragging) listener.onDragTo(ev.rawX, ev.rawY, downRawX, downRawY)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (dragging) {
                dragging = false
                listener.onDragEnd()
            }
        }
        return true
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
}
