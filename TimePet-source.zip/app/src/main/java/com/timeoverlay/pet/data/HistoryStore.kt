package com.timeoverlay.pet.data

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter

/**
 * Локальная история дневных итогов (JSON-файлы, без сервера и регистрации).
 *
 * Ключ дня — локальная дата (yyyy-MM-dd). При смене часового пояса даты
 * пересчитываются естественным образом при следующем сохранении.
 * Переход между днями: новый день = новая запись, старые не трогаем.
 */
class HistoryStore(context: Context) {

    private val dir = File(context.filesDir, "history").apply { mkdirs() }
    private val fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd")

    data class DayRecord(
        val date: String,
        val productiveMs: Long,
        val lazyMs: Long,
        val neutralMs: Long,
        val totalMs: Long,
        val mood: Int
    )

    fun save(record: DayRecord) {
        runCatching {
            val o = JSONObject()
            o.put("date", record.date)
            o.put("productive", record.productiveMs)
            o.put("lazy", record.lazyMs)
            o.put("neutral", record.neutralMs)
            o.put("total", record.totalMs)
            o.put("mood", record.mood)
            File(dir, "${record.date}.json").writeText(o.toString())
        }
    }

    fun load(date: LocalDate): DayRecord? {
        val f = File(dir, "${date.format(fmt)}.json")
        if (!f.exists()) return null
        return runCatching {
            val o = JSONObject(f.readText())
            DayRecord(
                date = o.getString("date"),
                productiveMs = o.getLong("productive"),
                lazyMs = o.getLong("lazy"),
                neutralMs = o.getLong("neutral"),
                totalMs = o.getLong("total"),
                mood = o.getInt("mood")
            )
        }.getOrNull()
    }

    /** Все сохранённые дни (порядок не гарантирован). */
    fun allRecords(): List<DayRecord> =
        dir.listFiles().orEmpty().mapNotNull { f ->
            runCatching {
                val o = JSONObject(f.readText())
                DayRecord(
                    date = o.getString("date"),
                    productiveMs = o.getLong("productive"),
                    lazyMs = o.getLong("lazy"),
                    neutralMs = o.getLong("neutral"),
                    totalMs = o.getLong("total"),
                    mood = o.getInt("mood")
                )
            }.getOrNull()
        }

    /** Последние [days] дней (включая сегодня), от старых к новым. */
    fun lastDays(days: Int, today: LocalDate = LocalDate.now()): List<DayRecord?> {
        return (days - 1 downTo 0).map { back -> load(today.minusDays(back.toLong())) }
    }

    /** Удаление всей собранной истории. Категории не трогает. */
    fun clearAll() {
        dir.listFiles()?.forEach { runCatching { it.delete() } }
    }

    fun todayKey(today: LocalDate = LocalDate.now()): String = today.format(fmt)
}
