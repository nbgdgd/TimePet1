package com.timeoverlay.pet.data

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager

/**
 * Хранилище пользовательских категорий + лимита развлечений.
 * Файл SharedPreferences "timepet" — всё локально, без сервера.
 *
 * Категория пакета: ручной выбор пользователя, затем встроенная база
 * ([DefaultCategories]), затем системная категория приложения
 * (ApplicationInfo.category / FLAG_IS_GAME — игры считаются развлечением),
 * иначе «Нейтральное».
 */
class AppCategoryStore(context: Context) {

    private val app = context.applicationContext
    private val prefs: SharedPreferences =
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val systemCache = HashMap<String, Category>()

    fun categoryOf(packageName: String): Category {
        val saved = prefs.getString(keyOf(packageName), null)
        if (saved != null) {
            return runCatching { Category.valueOf(saved) }.getOrDefault(Category.NEUTRAL)
        }
        return DefaultCategories.lookup(packageName) ?: systemCategory(packageName)
    }

    /** Откуда взялась категория: ручная, из базы, системная или по умолчанию. */
    enum class Source { USER, BUILTIN, SYSTEM, DEFAULT }

    fun sourceOf(packageName: String): Source = when {
        prefs.contains(keyOf(packageName)) -> Source.USER
        DefaultCategories.lookup(packageName) != null -> Source.BUILTIN
        systemCategory(packageName) != Category.NEUTRAL -> Source.SYSTEM
        else -> Source.DEFAULT
    }

    /** Системная категория: только игры распознаются как развлечение. */
    private fun systemCategory(packageName: String): Category = synchronized(systemCache) {
        systemCache.getOrPut(packageName) {
            runCatching {
                val ai = app.packageManager.getApplicationInfo(packageName, 0)
                val game = ai.category == ApplicationInfo.CATEGORY_GAME ||
                    (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                if (game) Category.LAZY else Category.NEUTRAL
            }.getOrDefault(Category.NEUTRAL)
        }
    }

    fun setCategory(packageName: String, category: Category) {
        prefs.edit().putString(keyOf(packageName), category.name).apply()
    }

    /** Вернуть автоматическое определение (убрать ручной выбор). */
    fun clearCategory(packageName: String) {
        prefs.edit().remove(keyOf(packageName)).apply()
    }

    fun isExcluded(packageName: String): Boolean =
        categoryOf(packageName) == Category.EXCLUDED

    /** Допустимые минуты развлечений в день. По умолчанию 60. */
    var funAllowanceMinutes: Int
        get() = prefs.getInt(KEY_ALLOWANCE, 60).coerceIn(0, 480)
        set(value) {
            prefs.edit().putInt(KEY_ALLOWANCE, value.coerceIn(0, 480)).apply()
        }

    fun registerListener(l: SharedPreferences.OnSharedPreferenceChangeListener) =
        prefs.registerOnSharedPreferenceChangeListener(l)

    fun unregisterListener(l: SharedPreferences.OnSharedPreferenceChangeListener) =
        prefs.unregisterOnSharedPreferenceChangeListener(l)

    private fun keyOf(packageName: String) = "cat_$packageName"

    companion object {
        private const val PREFS = "timepet"
        private const val KEY_ALLOWANCE = "fun_allowance_min"
    }
}
