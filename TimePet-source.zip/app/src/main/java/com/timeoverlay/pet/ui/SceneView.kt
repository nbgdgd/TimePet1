package com.timeoverlay.pet.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import android.widget.FrameLayout
import com.timeoverlay.pet.R
import com.timeoverlay.pet.data.AppPrefs
import com.timeoverlay.pet.pet.PetDef
import kotlin.math.sin

/**
 * Окружение питомца внутри приложения: комната из лёгких слоёв, нарисованных
 * кодом (стена, окно с небом, полка с растением, пол и коврик, тень).
 * Дневной и ночной варианты — по теме. Мягкое движение: облака плывут,
 * солнце/луна чуть покачиваются, звёзды мерцают, листья качаются.
 *
 * Одна сцена для всех персонажей: [placePet] ставит спрайт ступнями на
 * пол по его [PetDef.Stance] (масштаб, линия ступней, ширина тени).
 * При выключенной анимации питомца сцена тоже неподвижна.
 */
class SceneView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()
    private val prefs = AppPrefs(context)
    private var night = false
    private var animating = false
    private val start = SystemClock.uptimeMillis()

    /** Где стоит питомец: центр x (доля ширины) и линия ступней (доля высоты). */
    private var petCx = 0.5f
    private var petShadowW = 0f
    private var petPresent = false
    private var placed: Placed? = null

    // Палитры: стена верх/низ, пол, коврик, рама окна, небо верх/низ, полка, горшок, лист, тень.
    private class Palette(
        val wallTop: Int, val wallBottom: Int, val floor: Int, val floorEdge: Int, val rug: Int, val rugLine: Int,
        val frame: Int, val skyTop: Int, val skyBottom: Int, val shelf: Int, val pot: Int, val leaf: Int,
        val leafDark: Int, val sun: Int, val cloud: Int, val star: Int, val shadow: Int
    )

    private val day = Palette(
        wallTop = 0xFFF3F0FA.toInt(), wallBottom = 0xFFE9E7F5.toInt(), floor = 0xFFDBD9EA.toInt(),
        floorEdge = 0xFFCFCDE2.toInt(), rug = 0xFFD2CDEC.toInt(), rugLine = 0xFFC3BDE4.toInt(),
        frame = 0xFFFFFFFF.toInt(), skyTop = 0xFFBFE0FF.toInt(), skyBottom = 0xFFE3F2FF.toInt(),
        shelf = 0xFFD9D4C8.toInt(), pot = 0xFFD89A6A.toInt(), leaf = 0xFF7DBB7A.toInt(),
        leafDark = 0xFF5E9E5C.toInt(), sun = 0xFFFFD36A.toInt(), cloud = 0xFFFFFFFF.toInt(),
        star = 0x00000000, shadow = 0x26000000
    )
    private val nightP = Palette(
        wallTop = 0xFF1A1B2A.toInt(), wallBottom = 0xFF14151F.toInt(), floor = 0xFF1B1C2B.toInt(),
        floorEdge = 0xFF23243A.toInt(), rug = 0xFF25264A.toInt(), rugLine = 0xFF2F3060.toInt(),
        frame = 0xFF2B2C3E.toInt(), skyTop = 0xFF141B36.toInt(), skyBottom = 0xFF26325C.toInt(),
        shelf = 0xFF2A2B3C.toInt(), pot = 0xFF7A5A46.toInt(), leaf = 0xFF3E7A56.toInt(),
        leafDark = 0xFF2E5C42.toInt(), sun = 0xFFF2E6B8.toInt(), cloud = 0x00000000,
        star = 0xFFE8ECFF.toInt(), shadow = 0x66000000
    )
    private val stars = floatArrayOf(0.12f, 0.18f, 0.30f, 0.10f, 0.48f, 0.22f, 0.62f, 0.09f, 0.80f, 0.20f, 0.90f, 0.35f, 0.70f, 0.40f)

    private val ticker = object : Runnable {
        override fun run() {
            if (!animating) return
            invalidate()
            postDelayed(this, 40L)
        }
    }

    init {
        night = !ThemeManager.isLight(ThemeManager.resolved(context))
    }

    /** Ночной вариант (по умолчанию — по теме). */
    fun setNight(n: Boolean) {
        night = n
        invalidate()
    }

    /**
     * Поставить питомца на пол сцены: размер по [PetDef.Stance.scale] от
     * [baseWidthPx], нижний отступ так, чтобы ступни легли на линию пола.
     * Сцена и питомец должны лежать в одном FrameLayout.
     */
    fun placePet(pet: PetSpriteView, def: PetDef, baseWidthPx: Int, topInsetPx: Int = 0) {
        val lp = pet.layoutParams as? FrameLayout.LayoutParams ?: return
        val sceneH = if (height > 0) height else (parent as? View)?.height ?: 0
        val floorY = sceneH * FLOOR
        var w = (baseWidthPx * def.stance.scale).toInt()
        var h = (w * 208f / 192f).toInt()
        // На узком экране пузырь реплики сверху: макушка питомца не выше него.
        if (sceneH > 0 && topInsetPx > 0) {
            val maxH = (floorY - topInsetPx) / def.stance.foot
            if (h > maxH) {
                h = maxH.toInt().coerceAtLeast(1)
                w = (h * 192f / 208f).toInt()
            }
        }
        lp.width = w
        lp.height = h
        lp.gravity = android.view.Gravity.CENTER_HORIZONTAL or android.view.Gravity.BOTTOM
        // top + foot*h = floorY  →  bottomMargin = sceneH - (top + h)
        lp.bottomMargin = (sceneH - floorY - (1f - def.stance.foot) * h).toInt().coerceAtLeast(0)
        pet.layoutParams = lp
        petShadowW = w * def.stance.shadow
        petPresent = true
        placed = Placed(pet, def, baseWidthPx, topInsetPx)
        invalidate()
    }

    private class Placed(val pet: PetSpriteView, val def: PetDef, val base: Int, val inset: Int)

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        // Питомец мог быть поставлен до измерения сцены — пересчитать отступ.
        placed?.let { placePet(it.pet, it.def, it.base, it.inset) }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        updateRunning()
    }

    override fun onDetachedFromWindow() {
        animating = false
        removeCallbacks(ticker)
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        updateRunning()
    }

    private fun updateRunning() {
        val want = isAttachedToWindow && visibility == VISIBLE && prefs.animations
        if (want && !animating) { animating = true; post(ticker) }
        else if (!want && animating) { animating = false; removeCallbacks(ticker) }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val d = resources.displayMetrics.density
        val p = if (night) nightP else day
        val t = if (prefs.animations) (SystemClock.uptimeMillis() - start) / 1000f else 0f
        val r = 16f * d
        rect.set(0f, 0f, w, h)
        path.reset()
        path.addRoundRect(rect, r, r, Path.Direction.CW)
        val saved = canvas.save()
        canvas.clipPath(path)

        // Стена.
        paint.shader = LinearGradient(0f, 0f, 0f, h, p.wallTop, p.wallBottom, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null

        // Пол и коврик.
        val floorY = h * FLOOR
        paint.color = p.floor
        canvas.drawRect(0f, floorY - h * 0.06f, w, h, paint)
        paint.color = p.floorEdge
        canvas.drawRect(0f, floorY - h * 0.06f, w, floorY - h * 0.06f + 2f * d, paint)
        val rugW = w * 0.46f
        rect.set(w * petCx - rugW / 2f, floorY - h * 0.055f, w * petCx + rugW / 2f, floorY + h * 0.075f)
        paint.color = p.rug
        canvas.drawRoundRect(rect, 10f * d, 10f * d, paint)
        paint.color = p.rugLine
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f * d
        rect.inset(6f * d, 5f * d)
        canvas.drawRoundRect(rect, 8f * d, 8f * d, paint)
        paint.style = Paint.Style.FILL

        // Окно справа: рама, небо, солнце/луна, облака или звёзды, переплёт.
        val winL = w * 0.68f
        val winT = h * 0.10f
        val winR = w * 0.94f
        val winB = h * 0.52f
        rect.set(winL - 4f * d, winT - 4f * d, winR + 4f * d, winB + 4f * d)
        paint.color = p.frame
        canvas.drawRoundRect(rect, 6f * d, 6f * d, paint)
        rect.set(winL, winT, winR, winB)
        paint.shader = LinearGradient(0f, winT, 0f, winB, p.skyTop, p.skyBottom, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(rect, 3f * d, 3f * d, paint)
        paint.shader = null
        val c2 = canvas.save()
        canvas.clipRect(winL, winT, winR, winB)
        val bob = sin(t * 0.6f) * 2f * d
        if (night) {
            // Звёзды мерцают.
            for (i in stars.indices step 2) {
                val a = (0.55f + 0.45f * sin(t * (1.3f + i * 0.17f) + i)).coerceIn(0f, 1f)
                paint.color = p.star
                paint.alpha = (a * 255).toInt()
                canvas.drawCircle(winL + (winR - winL) * stars[i], winT + (winB - winT) * stars[i + 1], 1.3f * d, paint)
            }
            paint.alpha = 255
            // Луна: серп.
            val mx = winL + (winR - winL) * 0.68f
            val my = winT + (winB - winT) * 0.30f + bob
            val mr = (winR - winL) * 0.13f
            paint.color = p.sun
            canvas.drawCircle(mx, my, mr, paint)
            paint.color = p.skyTop
            canvas.drawCircle(mx + mr * 0.45f, my - mr * 0.25f, mr * 0.85f, paint)
        } else {
            paint.color = p.sun
            canvas.drawCircle(winL + (winR - winL) * 0.30f, winT + (winB - winT) * 0.32f + bob, (winR - winL) * 0.12f, paint)
            // Два облака плывут слева направо и возвращаются.
            paint.color = p.cloud
            val span = (winR - winL) + 40f * d
            for (i in 0..1) {
                val cx = winL - 20f * d + ((t * (6f + i * 4f) * d + i * span * 0.55f) % span)
                val cy = winT + (winB - winT) * (0.22f + i * 0.30f)
                cloud(canvas, cx, cy, (8f + i * 3f) * d)
            }
        }
        canvas.restoreToCount(c2)
        paint.color = p.frame
        canvas.drawRect((winL + winR) / 2f - 1.5f * d, winT, (winL + winR) / 2f + 1.5f * d, winB, paint)
        canvas.drawRect(winL, (winT + winB) / 2f - 1.5f * d, winR, (winT + winB) / 2f + 1.5f * d, paint)

        // Полка слева с растением: листья качаются.
        val shelfY = h * 0.56f
        rect.set(w * 0.06f, shelfY, w * 0.30f, shelfY + 4f * d)
        paint.color = p.shelf
        canvas.drawRoundRect(rect, 2f * d, 2f * d, paint)
        val px = w * 0.18f
        rect.set(px - 9f * d, shelfY - 16f * d, px + 9f * d, shelfY)
        paint.color = p.pot
        canvas.drawRoundRect(rect, 3f * d, 3f * d, paint)
        val sway = sin(t * 1.1f) * 4f
        leaf(canvas, px, shelfY - 16f * d, -28f + sway, 22f * d, p.leafDark)
        leaf(canvas, px, shelfY - 16f * d, 26f + sway * 0.8f, 20f * d, p.leafDark)
        leaf(canvas, px, shelfY - 16f * d, sway * 0.6f, 26f * d, p.leaf)

        // Тень под питомцем — следует за ним (демонстрация бега сдвигает спрайт).
        if (petPresent) {
            paint.color = p.shadow
            val sw = petShadowW
            val pet = placed?.pet
            val cx = if (pet != null && pet.width > 0) pet.left + pet.width / 2f + pet.translationX else w * petCx
            rect.set(cx - sw / 2f, floorY - 5f * d, cx + sw / 2f, floorY + 5f * d)
            canvas.drawOval(rect, paint)
        }
        canvas.restoreToCount(saved)
    }

    private fun cloud(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        canvas.drawCircle(cx, cy, r, paint)
        canvas.drawCircle(cx - r * 1.1f, cy + r * 0.25f, r * 0.75f, paint)
        canvas.drawCircle(cx + r * 1.15f, cy + r * 0.2f, r * 0.8f, paint)
        rect.set(cx - r * 1.6f, cy, cx + r * 1.7f, cy + r * 0.9f)
        canvas.drawRoundRect(rect, r * 0.5f, r * 0.5f, paint)
    }

    /** Лист: вытянутый овал, повёрнутый на [deg] от вертикали вокруг основания. */
    private fun leaf(canvas: Canvas, x: Float, y: Float, deg: Float, len: Float, color: Int) {
        val c = canvas.save()
        canvas.rotate(deg, x, y)
        paint.color = color
        rect.set(x - len * 0.22f, y - len, x + len * 0.22f, y)
        canvas.drawOval(rect, paint)
        canvas.restoreToCount(c)
    }

    companion object {
        /** Линия пола (ступни питомца) в долях высоты сцены. */
        const val FLOOR = 0.84f
    }
}
