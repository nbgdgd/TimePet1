package com.timeoverlay.pet.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.widget.FrameLayout
import com.timeoverlay.pet.ui.PetSpriteView
import kotlin.math.abs

/**
 * Отдельное окно питомца: только спрайт, без плашки. Питомец гуляет
 * сам по себе (окно двигает [PetBehavior]), таймер при этом стоит.
 *
 * Жесты: тап — трюк и реплика; двойной тап — меню «Не беспокоить»;
 * долгое нажатие — перетащить питомца (в режиме «только питомец» это
 * перенос домашней точки, иначе питомец потом сам вернётся к таймеру).
 */
@SuppressLint("ViewConstructor")
class PetHolderView(context: Context, private val listener: Listener) : FrameLayout(context) {

    interface Listener {
        fun onPetTap()
        fun onPetDoubleTap()
        fun onPetDragStart()
        fun onPetDragTo(rawX: Float, rawY: Float, downX: Float, downY: Float)
        fun onPetDragEnd()
    }

    val pet = PetSpriteView(context)
    private var dragging = false
    private var downRawX = 0f
    private var downRawY = 0f
    private var lastDx = 0f

    private val detector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            listener.onPetTap()
            return true
        }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            listener.onPetDoubleTap()
            return true
        }
        override fun onLongPress(e: MotionEvent) {
            dragging = true
            lastDx = 0f
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            listener.onPetDragStart()
        }
    })

    init {
        clipChildren = false
        clipToPadding = false
        pet.setBreathing(true)
        pet.autoIdle = false
        addView(pet, LayoutParams(dp(60), dp(65)))
        // Запас сверху под сердечки и прыжок, чтобы окно их не обрезало.
        setPadding(dp(2), dp(14), dp(2), dp(2))
    }

    /** Размер питомца (dp); в свёрнутом виде меньше. */
    fun applySize(sizeDp: Int, collapsed: Boolean) {
        val s = if (collapsed) (sizeDp * 0.62f).toInt() else sizeDp
        val lp = pet.layoutParams as LayoutParams
        lp.width = dp(s)
        lp.height = dp((s * 208f / 192f).toInt())
        pet.layoutParams = lp
        requestLayout()
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = true

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        detector.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downRawX = ev.rawX
                downRawY = ev.rawY
            }
            MotionEvent.ACTION_MOVE -> if (dragging) {
                val dx = ev.rawX - downRawX
                if (abs(dx - lastDx) > dp(2)) {
                    pet.walk(dx - lastDx)
                    lastDx = dx
                }
                listener.onPetDragTo(ev.rawX, ev.rawY, downRawX, downRawY)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (dragging) {
                dragging = false
                pet.stopWalking()
                listener.onPetDragEnd()
            }
        }
        return true
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
}
