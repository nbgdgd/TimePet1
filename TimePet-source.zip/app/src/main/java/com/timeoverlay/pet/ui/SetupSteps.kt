package com.timeoverlay.pet.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.TextView
import androidx.activity.result.ActivityResultLauncher
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.material.button.MaterialButton
import com.timeoverlay.pet.R
import com.timeoverlay.pet.data.PermissionHelper

/**
 * Четыре шага настройки (доступ к статистике, поверх приложений,
 * уведомления, батарея) — одна логика для приветственного экрана и
 * карточки на главном. Каждый шаг: подпись, объяснение, кнопка «Разрешить»,
 * после выдачи — «Готово».
 */
class SetupSteps private constructor(
    private val context: Context,
    root: View,
    private val start: (Intent) -> Unit,
    private val notifLauncher: ActivityResultLauncher<String>?,
    private val onChanged: () -> Unit
) {
    private val usage = root.findViewById<View>(R.id.stepUsage)
    private val overlay = root.findViewById<View>(R.id.stepOverlay)
    private val notif = root.findViewById<View>(R.id.stepNotif)
    private val battery = root.findViewById<View>(R.id.stepBattery)

    init {
        bind(usage, R.string.setup_usage, R.string.setup_usage_desc) {
            start(PermissionHelper.usageAccessIntent())
        }
        bind(overlay, R.string.setup_overlay, R.string.setup_overlay_desc) {
            start(PermissionHelper.overlayPermissionIntent(context))
        }
        bind(notif, R.string.setup_notif, R.string.setup_notif_desc) {
            if (Build.VERSION.SDK_INT >= 33) notifLauncher?.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        bind(battery, R.string.setup_battery, R.string.setup_battery_desc) {
            runCatching {
                start(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:${context.packageName}")
                    )
                )
            }.onFailure { runCatching { start(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } }
        }
        notif.visibility = if (Build.VERSION.SDK_INT >= 33) View.VISIBLE else View.GONE
    }

    private fun bind(row: View, title: Int, desc: Int, onClick: () -> Unit) {
        row.findViewById<TextView>(R.id.stepTitle).setText(title)
        row.findViewById<TextView>(R.id.stepDesc).setText(desc)
        row.findViewById<MaterialButton>(R.id.stepButton).setOnClickListener { onClick() }
    }

    fun hasNotif(): Boolean = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
        PackageManager.PERMISSION_GRANTED

    fun hasBattery(): Boolean =
        context.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(context.packageName)

    /** Обязательные разрешения (статистика + поверх приложений) выданы. */
    fun requiredDone(): Boolean = PermissionHelper.hasOverlayRequired(context)

    /** Обновить состояния кнопок; вернуть true, если выдано вообще всё. */
    fun refresh(): Boolean {
        val u = PermissionHelper.hasUsageAccess(context)
        val o = PermissionHelper.hasOverlayPermission(context)
        val n = hasNotif()
        val b = hasBattery()
        state(usage, u)
        state(overlay, o)
        state(notif, n)
        state(battery, b)
        return u && o && n && b
    }

    private fun state(row: View, done: Boolean) {
        val btn = row.findViewById<MaterialButton>(R.id.stepButton)
        btn.isEnabled = !done
        btn.setText(if (done) R.string.setup_done else R.string.setup_allow)
        btn.setIconResource(if (done) R.drawable.ic_check else 0)
    }

    companion object {
        /** Для фрагмента: лаунчер разрешения на уведомления — поле фрагмента (регистрируется до onCreate). */
        fun forFragment(
            fragment: Fragment, root: View,
            launcher: ActivityResultLauncher<String>, onChanged: () -> Unit
        ): SetupSteps = SetupSteps(fragment.requireContext(), root, { fragment.startActivity(it) }, launcher, onChanged)

        fun forActivity(
            activity: androidx.activity.ComponentActivity, root: View,
            launcher: ActivityResultLauncher<String>, onChanged: () -> Unit
        ): SetupSteps = SetupSteps(activity, root, { activity.startActivity(it) }, launcher, onChanged)
    }
}
