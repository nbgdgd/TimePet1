package com.timeoverlay.pet.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/**
 * Мини-превью темы как в Telegram: фон, два «пузыря» (карточка и акцент)
 * и кружок-радио. Для «как в системе» половина дневная, половина ночная.
 */
class ThemePreviewView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private var bg = 0xFFEDF2FF.toInt()
    private var card = 0xFFFFFFFF.toInt()
    private var accent = 0xFF2F6BFF.toInt()
    private var bg2: Int? = null
    private var card2: Int? = null
    private var selected = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()

    fun set(bg: Int, card: Int, accent: Int, bg2: Int? = null, card2: Int? = null) {
        this.bg = bg; this.card = card; this.accent = accent; this.bg2 = bg2; this.card2 = card2
        invalidate()
    }

    fun setChosen(chosen: Boolean) {
        selected = chosen
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val w = width.toFloat()
        val h = height.toFloat()
        val r = 14f * d
        rect.set(0f, 0f, w, h)
        paint.color = bg
        canvas.drawRoundRect(rect, r, r, paint)
        val b2 = bg2
        if (b2 != null) {
            // Правая половина - вторая палитра (ночь).
            canvas.save()
            canvas.clipRect(w / 2f, 0f, w, h)
            paint.color = b2
            canvas.drawRoundRect(rect, r, r, paint)
            canvas.restore()
        }
        // Пузыри: левый - карточка, правый - акцент.
        val bw = w * 0.42f
        val bh = h * 0.14f
        rect.set(w * 0.12f, h * 0.16f, w * 0.12f + bw, h * 0.16f + bh)
        paint.color = card
        canvas.drawRoundRect(rect, bh / 2, bh / 2, paint)
        rect.set(w * 0.46f, h * 0.40f, w * 0.46f + bw, h * 0.40f + bh)
        paint.color = card2 ?: card
        canvas.drawRoundRect(rect, bh / 2, bh / 2, paint)
        rect.set(w * 0.50f, h * 0.44f, w * 0.50f + bw * 0.6f, h * 0.44f + bh * 0.55f)
        paint.color = accent
        canvas.drawRoundRect(rect, bh / 2, bh / 2, paint)
        // Радио-кружок.
        val cx = w / 2f
        val cy = h * 0.78f
        val cr = 7f * d
        ring.strokeWidth = 2f * d
        ring.color = if (selected) accent else (card and 0x00FFFFFF or 0x99000000.toInt())
        canvas.drawCircle(cx, cy, cr, ring)
        if (selected) {
            paint.color = accent
            canvas.drawCircle(cx, cy, cr * 0.55f, paint)
        }
    }
}
