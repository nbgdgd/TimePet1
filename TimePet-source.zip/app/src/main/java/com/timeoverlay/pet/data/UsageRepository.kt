package com.timeoverlay.pet.data

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import java.util.Calendar

/**
 * Настоящий учёт времени через UsageStatsManager.
 *
 * Сегодняшний день считается свёрткой событий (см. [DayLedger]) — это тот же
 * алгоритм, что крутится в оверлее, поэтому таймер поверх приложений,
 * главный экран и аналитика показывают одни цифры. Прошлые дни берутся из
 * посуточных корзин системы (totalTimeInForeground): там уже нет «живого»
 * интервала, и корзины хранятся дольше, чем сырые события.
 *
 * Без разрешения возвращается пустой результат, а не выдуманные цифры.
 */
class UsageRepository(private val context: Context) {

    data class AppUsage(
        val packageName: String,
        val label: String,
        val icon: Drawable?,
        val millis: Long
    )

    data class UsageSnapshot(
        val apps: List<AppUsage>,
        val totalMillis: Long
    )

    data class DayTotal(val dayStartMs: Long, val totalMillis: Long)

    private val usageStats: UsageStatsManager? =
        context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager

    /** События за [beginMs, endMs) в порядке времени. */
    fun events(beginMs: Long, endMs: Long): List<DayLedger.Event> {
        val mgr = usageStats ?: return emptyList()
        if (beginMs >= endMs) return emptyList()
        val out = ArrayList<DayLedger.Event>()
        val q = runCatching { mgr.queryEvents(beginMs, endMs) }.getOrNull() ?: return out
        val e = UsageEvents.Event()
        while (q.hasNextEvent()) {
            q.getNextEvent(e)
            out.add(DayLedger.Event(e.eventType, e.packageName, e.timeStamp, e.className))
        }
        return out
    }

    /**
     * Какой пакет сейчас на экране по последним событиям (за последние
     * [windowMs]): последний RESUMED, за которым не было PAUSED/STOPPED того
     * же пакета. Нужен после разблокировки, когда свёртка закрыла интервал,
     * а новое RESUMED не пришло.
     */
    fun currentForeground(nowMs: Long, windowMs: Long = 10 * 60_000L): String? {
        var resumed: String? = null
        for (e in events(nowMs - windowMs, nowMs + 1_000L)) {
            when (e.type) {
                DayLedger.ACTIVITY_RESUMED -> resumed = e.packageName
                DayLedger.ACTIVITY_PAUSED, DayLedger.ACTIVITY_STOPPED ->
                    if (e.packageName == resumed) resumed = null
                DayLedger.SCREEN_NON_INTERACTIVE, DayLedger.KEYGUARD_SHOWN, DayLedger.DEVICE_SHUTDOWN -> Unit
            }
        }
        return resumed
    }

    /**
     * Экранное время сегодня по часам (24 корзины) — та же свёртка событий,
     * интервал режется по границам часов.
     */
    fun hourlyToday(nowMs: Long = System.currentTimeMillis()): LongArray {
        val out = LongArray(24)
        val start = startOfDay(nowMs)
        var openSince = -1L
        var openPkg: String? = null
        val open = HashSet<String>()
        fun add(from: Long, to: Long) {
            var a = from.coerceAtLeast(start)
            val b = to.coerceAtMost(nowMs)
            while (a < b) {
                val h = ((a - start) / 3_600_000L).toInt().coerceIn(0, 23)
                val hourEnd = start + (h + 1) * 3_600_000L
                val seg = minOf(b, hourEnd) - a
                out[h] += seg
                a += seg
            }
        }
        for (e in events(start, nowMs)) {
            when (e.type) {
                DayLedger.ACTIVITY_RESUMED -> {
                    val pkg = e.packageName ?: continue
                    if (openPkg == pkg) { open.add(e.className ?: pkg); continue }
                    if (openPkg != null) add(openSince, e.timestamp)
                    openPkg = pkg; openSince = e.timestamp; open.clear(); open.add(e.className ?: pkg)
                }
                DayLedger.ACTIVITY_PAUSED, DayLedger.ACTIVITY_STOPPED -> if (e.packageName == openPkg) {
                    open.remove(e.className ?: e.packageName)
                    if (open.isEmpty()) { add(openSince, e.timestamp); openPkg = null }
                }
                DayLedger.SCREEN_NON_INTERACTIVE, DayLedger.KEYGUARD_SHOWN, DayLedger.DEVICE_SHUTDOWN ->
                    if (openPkg != null) { add(openSince, e.timestamp); openPkg = null }
            }
        }
        if (openPkg != null) add(openSince, nowMs)
        return out
    }

    /** Полная свёртка сегодняшнего дня с полуночи до [nowMs]. */
    fun ledgerForToday(nowMs: Long = System.currentTimeMillis()): DayLedger {
        val start = startOfDay(nowMs)
        val ledger = DayLedger(start)
        ledger.applyAll(events(start, nowMs))
        return ledger
    }

    /** Сегодня по пакетам (живой интервал учтён) — итог за день. */
    fun queryToday(nowMs: Long = System.currentTimeMillis()): UsageSnapshot =
        toSnapshot(ledgerForToday(nowMs).snapshot(nowMs))

    /**
     * Итоги за произвольный интервал [beginMs, endMs): прошлые дни — из
     * посуточных корзин, сегодняшний хвост — из свёртки событий.
     */
    fun queryRange(beginMs: Long, endMs: Long): UsageSnapshot {
        val mgr = usageStats ?: return UsageSnapshot(emptyList(), 0L)
        if (beginMs >= endMs) return UsageSnapshot(emptyList(), 0L)
        val todayStart = startOfDay(endMs)
        val perPackage = HashMap<String, Long>()

        var dayStart = beginMs
        while (dayStart < minOf(endMs, todayStart)) {
            val dayEnd = minOf(endOfDay(dayStart), endMs)
            val stats = runCatching {
                mgr.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, dayStart, dayEnd)
            }.getOrNull().orEmpty()
            for (s in stats) {
                val t = s.totalTimeInForeground
                if (t > 0) perPackage[s.packageName] = (perPackage[s.packageName] ?: 0L) + t
            }
            dayStart = dayEnd
        }
        if (endMs > todayStart) {
            val from = maxOf(beginMs, todayStart)
            val ledger = DayLedger(from)
            ledger.applyAll(events(from, endMs))
            for ((pkg, ms) in ledger.snapshot(endMs)) {
                perPackage[pkg] = (perPackage[pkg] ?: 0L) + ms
            }
        }
        return toSnapshot(perPackage)
    }

    /** Ряд посуточных итогов (для графика и динамики), от старых к новым. */
    fun queryDailySeries(days: Int, nowMs: Long = System.currentTimeMillis()): List<DayTotal> {
        if (days <= 0) return emptyList()
        val out = ArrayList<DayTotal>(days)
        for (i in days - 1 downTo 0) {
            val dayMs = shiftDays(nowMs, -i)
            val begin = startOfDay(dayMs)
            val end = if (i == 0) nowMs else endOfDay(dayMs)
            out.add(DayTotal(begin, queryRange(begin, end).totalMillis))
        }
        return out
    }

    /** Дневная динамика одного пакета за [days] дней, от старых к новым. */
    fun queryPackageSeries(packageName: String, days: Int, nowMs: Long = System.currentTimeMillis()): List<Long> =
        (days - 1 downTo 0).map { back ->
            val dayMs = shiftDays(nowMs, -back)
            val begin = startOfDay(dayMs)
            val end = if (back == 0) nowMs else endOfDay(dayMs)
            queryRange(begin, end).apps.firstOrNull { it.packageName == packageName }?.millis ?: 0L
        }

    private fun toSnapshot(perPackage: Map<String, Long>): UsageSnapshot {
        val pm = context.packageManager
        val total = perPackage.values.sum()
        val apps = perPackage.entries
            .sortedByDescending { it.value }
            .mapNotNull { (pkg, millis) -> toAppUsage(pm, pkg, millis) }
        return UsageSnapshot(apps, total)
    }

    private fun toAppUsage(pm: PackageManager, pkg: String, millis: Long): AppUsage? {
        // Без launch-intent — системные/служебные пакеты: в список не показываем.
        if (pm.getLaunchIntentForPackage(pkg) == null) return null
        if (millis < MIN_VISIBLE_MILLIS) return null
        val info = runCatching { pm.getApplicationInfo(pkg, 0) }.getOrNull() ?: return null
        val label = runCatching { pm.getApplicationLabel(info).toString() }.getOrDefault(pkg)
        val icon = runCatching { pm.getApplicationIcon(info) }.getOrNull()
        return AppUsage(pkg, label, icon, millis)
    }

    companion object {
        /** Порог видимости в списке: 10 секунд (в итог входит всё). */
        const val MIN_VISIBLE_MILLIS = 10_000L

        fun startOfDay(ms: Long): Long {
            val c = Calendar.getInstance()
            c.timeInMillis = ms
            c.set(Calendar.HOUR_OF_DAY, 0)
            c.set(Calendar.MINUTE, 0)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            return c.timeInMillis
        }

        fun endOfDay(ms: Long): Long {
            val c = Calendar.getInstance()
            c.timeInMillis = startOfDay(ms)
            c.add(Calendar.DAY_OF_YEAR, 1)
            return c.timeInMillis
        }

        /** Сдвиг на дни через календарь — корректно при переводе часов. */
        fun shiftDays(ms: Long, days: Int): Long {
            val c = Calendar.getInstance()
            c.timeInMillis = ms
            c.add(Calendar.DAY_OF_YEAR, days)
            return c.timeInMillis
        }
    }
}
