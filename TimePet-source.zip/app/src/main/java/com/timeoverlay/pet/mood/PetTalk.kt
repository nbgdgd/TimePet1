package com.timeoverlay.pet.mood

import android.content.Context
import com.timeoverlay.pet.R
import com.timeoverlay.pet.ui.PetSpriteView

/** Реплики питомца на касание: по настроению, случайная из набора. */
object PetTalk {
    fun onTap(context: Context, state: MoodEngine.State, tap: PetSpriteView.Tap): String {
        val res = when (tap) {
            PetSpriteView.Tap.ANNOYED -> R.array.tap_annoyed
            PetSpriteView.Tap.SLEEPY -> R.array.tap_sleep
            PetSpriteView.Tap.TRICK -> when (state) {
                MoodEngine.State.HAPPY -> R.array.tap_happy
                MoodEngine.State.CONTENT -> R.array.tap_content
                MoodEngine.State.TIRED -> R.array.tap_tired
                MoodEngine.State.SAD, MoodEngine.State.EXHAUSTED -> R.array.tap_sad
                MoodEngine.State.SLEEP -> R.array.tap_sleep
            }
        }
        return context.resources.getStringArray(res).random()
    }

    /** Короткая реплика в пузыре по настроению (без тапа). */
    fun say(context: Context, state: MoodEngine.State): String = context.getString(
        when (state) {
            MoodEngine.State.HAPPY -> R.string.pet_say_happy
            MoodEngine.State.CONTENT -> R.string.pet_say_content
            MoodEngine.State.TIRED -> R.string.pet_say_tired
            MoodEngine.State.SAD -> R.string.pet_say_sad
            MoodEngine.State.EXHAUSTED -> R.string.pet_say_exhausted
            MoodEngine.State.SLEEP -> R.string.pet_say_sleep
        }
    )
}
