package com.timeoverlay.pet.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/**
 * Крестик внизу экрана, появляется на время перетаскивания питомца.
 * Отпустить питомца над ним — убрать с экрана.
 */
class DismissTargetView(context: Context) : View(context) {

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC1B2030.toInt() }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * resources.displayMetrics.density
        color = 0xAAFFFFFF.toInt()
    }
    private val cross = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * resources.displayMetrics.density
        strokeCap = Paint.Cap.ROUND
        color = 0xFFFFFFFF.toInt()
    }
    private var hot = false

    /** Подсветить: питомец над крестиком. */
    fun setHot(value: Boolean) {
        if (hot == value) return
        hot = value
        bg.color = if (value) 0xE6C0392B.toInt() else 0xCC1B2030.toInt()
        animate().scaleX(if (value) 1.2f else 1f).scaleY(if (value) 1.2f else 1f).setDuration(120).start()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(cx, cy) - ring.strokeWidth
        canvas.drawCircle(cx, cy, r, bg)
        canvas.drawCircle(cx, cy, r, ring)
        val a = r * 0.38f
        canvas.drawLine(cx - a, cy - a, cx + a, cy + a, cross)
        canvas.drawLine(cx + a, cy - a, cx - a, cy + a, cross)
    }
}
