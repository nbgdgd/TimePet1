package com.timeoverlay.pet.data

/**
 * Встроенная база: стартовое распределение известных пакетов по категориям.
 *
 * Порядок приоритетов (см. [AppCategoryStore.categoryOf]):
 * 1) ручной выбор пользователя; 2) эта база; 3) системная категория
 * приложения (ApplicationInfo.category — игры); 4) «Нейтральное».
 *
 * Принципы:
 * - «Развлечения»: бесконечные ленты, короткие видео, соцсети, игры,
 *   стриминг развлекательного видео.
 * - «Продуктивность»: учёба, языки, книги, заметки, документы, планировщики,
 *   программирование, офис, рабочие чаты.
 * - «Нейтральное»: мессенджеры, браузеры, карты, банки, магазины, музыка,
 *   камера, звонки, системные инструменты — там можно и работать, и
 *   отдыхать, поэтому решает пользователь. YouTube тоже нейтральный.
 * Всё меняется в один тап в карточке приложения.
 */
object DefaultCategories {

    private val lazy = setOf(
        // Короткие видео и ленты
        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.ss.android.ugc.aweme",
        "com.instagram.android", "com.instagram.lite",
        "com.facebook.katana", "com.facebook.lite", "com.facebook.orca",
        "com.twitter.android", "com.threads.android",
        "com.vkontakte.android", "com.vk.vkvideo", "com.vk.clips",
        "com.pinterest", "com.reddit.frontpage", "com.tumblr",
        "com.snapchat.android", "com.likee.video", "com.triller.droid",
        "ru.ok.android", "com.imgur.mobile", "com.ninegag.android.app",
        "com.lemon.lvoverseas", "com.bigo.live", "sg.bigo.live",
        // Стримы и развлекательное видео
        "com.twitch.tv", "com.kick.mobile", "tv.trovo.android",
        "com.netflix.mediaclient", "com.disney.disneyplus", "com.hbo.hbonow", "com.wbd.stream",
        "com.amazon.avod.thirdpartyclient", "com.hulu.plus", "com.peacocktv.peacockandroid",
        "ru.ivi.client", "ru.kinopoisk", "ru.more.play", "com.wink.android", "ru.rutube.app",
        "tv.crunchyroll.crunchyroid", "com.viki.android", "com.google.android.youtube.tv",
        // Игры (популярные; остальные ловит системная категория GAME)
        "com.kiloo.subwaysurfers", "com.king.candycrushsaga", "com.king.candycrushsodasaga",
        "com.supercell.clashofclans", "com.supercell.clashroyale", "com.supercell.brawlstars",
        "com.supercell.hayday", "com.supercell.squad",
        "com.roblox.client", "com.mojang.minecraftpe", "com.miniclip.eightballpool",
        "com.pubg.imobile", "com.tencent.ig", "com.pubg.krmobile", "com.pubg.newstate",
        "com.garena.game.codm", "com.activision.callofduty.shooter", "com.activision.callofduty.warzone",
        "com.miHoYo.GenshinImpact", "com.hoyoverse.hkrpgoversea", "com.miHoYo.bh3oversea",
        "com.hoyoverse.nap", "com.mobile.legends", "com.dts.freefireth", "com.dts.freefiremax",
        "com.ea.gp.fifamobile", "com.ea.game.pvzfree_row", "com.ea.gp.apexlegendsmobilefps",
        "com.riotgames.league.wildrift", "com.riotgames.league.teamfighttactics", "com.riotgames.legendsofruneterra",
        "com.epicgames.fortnite", "com.innersloth.spacemafia", "com.playrix.gardenscapes",
        "com.playrix.homescapes", "com.playrix.fishdomdd.gplay", "com.playrix.township",
        "com.nianticlabs.pokemongo", "com.gameloft.android.ANMP.GloftA9HM", "com.rovio.baba",
        "com.outfit7.mytalkingtomfree", "com.dreamgames.royalmatch", "com.peak.toonblast",
        "com.blizzard.wtcg.hearthstone", "com.blizzard.diablo.immortal", "com.valvesoftware.underlords",
        "com.zeptolab.ctr.ads", "com.halfbrick.fruitninjafree", "com.imangi.templerun2",
        "com.kabam.marvelbattle", "com.nexon.bluearchive", "com.YoStarEN.Arknights",
        "com.wemade.nightcrows", "com.netmarble.sololv", "com.HoYoverse.hkrpgoversea",
        "com.axlebolt.standoff2", "com.gaijin.wtmobile", "com.wargaming.wot.blitz",
        "net.wargaming.wot.blitz", "com.igg.android.lordsmobile", "com.lilithgame.roc.gp",
        "com.lilithgames.hgame.gp", "com.farlightgames.igame.gp", "com.funplus.kingofavalon",
        "com.plarium.raidlegends", "com.scopely.monopolygo", "com.matteljv.uno", "com.ludo.king",
        "com.zynga.words3", "com.mobilityware.solitaire", "com.tripledot.woodoku",
        "com.easybrain.sudoku.android", "com.block.juggle", "com.crazylabs.cat.escape",
        "com.hypehouse.brainpuzzle", "io.supercent.linkedcubic", "com.superplaystudios.dicedreams",
        "com.pixel.gun3d", "com.nekki.shadowfight3", "com.nekki.shadowfightarena",
        "com.tencent.tmgp.pubgmhd", "com.tencent.tmgp.sgame", "com.levelinfinite.sgameGlobal",
        "com.sega.sonicdash", "com.nintendo.zaka", "com.nintendo.zara", "com.square_enix.android_googleplay.FFBEWW",
        "com.bandainamcoent.dblegends_ww", "com.aniplex.fategrandorder.en", "com.cygames.umamusume",
        "com.mihoyo.hyperion", "com.kurogame.wutheringwaves.global", "com.kurogame.punishing.grayraven.en"
    )

    private val productive = setOf(
        // Учёба и языки
        "com.ichi2.anki", "com.duolingo", "com.duolingo.math", "com.babbel.mobile.android.en",
        "com.memrise.android.memrisecompanion", "com.busuu.android.enc", "com.lingq.android",
        "com.mango.android", "com.drops.language", "com.hellotalk", "com.lingodeer",
        "org.coursera.android", "com.udemy.android", "org.khanacademy.android", "org.edx.mobile",
        "org.stepic.droid", "com.sololearn", "com.mimo", "com.brilliant.android",
        "com.skillshare.Skillshare", "com.linkedin.android.learning", "com.datacamp",
        "com.quizlet.quizletandroid", "com.photomath", "com.microblink.photomath",
        "com.google.android.apps.classroom", "com.instructure.candroid", "com.mathway.android",
        "ru.yandex.uchebnik", "com.skyeng.vimbox", "ru.sberbank.uchebnik", "com.foxford.mobile",
        "com.wolfram.android.alpha", "org.wikipedia", "com.ted.android", "com.chegg",
        "com.grammarly.android.keyboard", "com.elevate.elevateapp", "com.lumoslabs.lumosity",
        // Книги и чтение
        "com.amazon.kindle", "com.flyersoft.moonreader", "com.flyersoft.moonreaderp",
        "org.readera", "org.readera.premium", "com.prestigio.ereader", "org.koreader.launcher",
        "com.google.android.apps.books", "com.audible.application", "com.storytel.android",
        "ru.litres.android", "com.litres.android", "com.bookmate", "ru.mybook", "com.scribd.app.reader0",
        "org.geometerplus.zlibrary.ui.android", "com.kobobooks.android", "com.blinkslabs.blinkist.android",
        "com.pocket.android", "com.ideashower.readitlater.pro", "com.instapaper.android",
        "com.medium.reader", "com.google.android.apps.magazines", "com.substack.app",
        "io.legado.app", "com.faultexception.reader", "com.foobnix.pro.pdf.reader",
        // Заметки, документы, планирование
        "md.obsidian", "notion.id", "com.evernote", "com.google.android.keep",
        "com.microsoft.office.onenote", "com.simplenote", "com.standardnotes",
        "com.joplin", "net.cozic.joplin", "com.bear.notes", "com.zoho.notebook", "com.notionlabs.notebook",
        "com.google.android.apps.docs", "com.google.android.apps.docs.editors.docs",
        "com.google.android.apps.docs.editors.sheets", "com.google.android.apps.docs.editors.slides",
        "com.microsoft.office.word", "com.microsoft.office.excel", "com.microsoft.office.powerpoint",
        "com.microsoft.office.officehubrow", "com.adobe.reader", "com.wps.moffice_eng",
        "cn.wps.moffice_eng", "org.documentfoundation.libreoffice", "com.mobisystems.office",
        "com.google.android.apps.tasks", "com.todoist", "com.ticktick.task", "com.anydo",
        "com.trello", "com.asana.app", "com.monday.monday", "com.clickup.app", "com.linear.app",
        "com.atlassian.android.jira.core", "com.atlassian.confluence.server", "com.basecamp.bc3",
        "com.microsoft.todos", "com.habitrpg.android.habitica", "com.northcube.sleepcycle",
        "com.forestapp", "cc.forestapp", "com.flipd.app", "com.pomodoro", "com.superelement.pomodoro",
        "com.google.android.calendar", "com.microsoft.office.outlook", "com.samsung.android.calendar",
        "com.airbnb.android.calendar", "com.calengoo.android", "com.anod.calendar",
        "com.google.android.gm", "com.microsoft.office.outlook", "me.proton.android.mail",
        "com.fastmail.app", "ch.protonmail.android", "com.yandex.mail", "ru.mail.mailapp",
        "com.mindmeister.android", "com.xmind.mobile", "net.xmind.doughnut", "com.miro.miro",
        "com.figma.mirror", "com.canva.editor", "com.adobe.lrmobile", "com.adobe.psmobile",
        // Программирование и инструменты разработчика
        "com.termux", "com.github.android", "com.gitlab.app", "com.foxdebug.acodefree",
        "com.foxdebug.acode", "com.aide.ui", "org.jetbrains.fleet", "com.replit.app",
        "com.microsoft.azure", "com.amazon.aws.console.mobile", "com.google.cloud.console",
        "com.stackexchange.marvin", "com.stackoverflow.android", "dev.to", "com.termius",
        "com.server.auditor.ssh.client", "org.connectbot", "com.sonelli.juicessh",
        "io.github.rosemoe.editor", "com.rk.xededitor", "com.kaspersky.app.dev",
        "com.leetcode", "com.codeforces.app", "org.hackerrank.mobile", "com.exercism.app",
        "com.openai.chatgpt", "com.anthropic.claude", "com.google.android.apps.bard",
        "com.microsoft.copilot", "ai.perplexity.app.android", "com.deepseek.chat",
        // Рабочие чаты и созвоны
        "com.Slack", "com.microsoft.teams", "us.zoom.videomeetings", "com.google.android.apps.meetings",
        "com.google.android.apps.tachyon", "com.cisco.webex.meetings", "com.discord.business",
        "com.mattermost.rn", "im.zulip.zulip", "ru.yandex.telemost", "com.vk.calls",
        // Финансы и учёт (личная бухгалтерия — работа над собой)
        "com.ynab", "com.monefy.app.lite", "ru.zenmoney.androidsub", "com.coinkeeper.android",
        "com.dropbox.android", "com.google.android.apps.nbu.files", "com.nextcloud.client",
        // Здоровье и привычки
        "com.fitbit.FitbitMobile", "com.google.android.apps.fitness", "com.strava",
        "com.myfitnesspal.android", "com.headspace.android", "com.calm.android",
        "com.getsomeheadspace.android", "ru.yandex.med", "com.sec.android.app.shealth",
        "com.nike.ntc", "com.runtastic.runtastic", "com.fiton.android", "com.freeletics.lite",
        "com.wahoofitness.fitness", "com.northcube.sleepcycle", "com.mindbodyonline.connect"
    )

    /** Известные нейтральные: явно, чтобы не сработала чужая системная категория. */
    private val neutral = setOf(
        // Мессенджеры
        "org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram",
        "com.whatsapp", "com.whatsapp.w4b", "org.thoughtcrime.securesms", "com.viber.voip",
        "com.discord", "com.skype.raider", "com.imo.android.imoim", "jp.naver.line.android",
        "com.kakao.talk", "com.tencent.mm", "ru.mail.agent", "com.icq.mobile.client",
        "org.matrix.android", "im.vector.app", "com.wire", "com.google.android.apps.messaging",
        "com.samsung.android.messaging", "com.android.mms", "com.google.android.talk",
        "com.microsoft.skydrive", "com.beeper.android", "chat.delta", "ru.tinkoff.messenger",
        // Браузеры
        "com.android.chrome", "com.chrome.beta", "com.chrome.dev", "com.chrome.canary",
        "org.mozilla.firefox", "org.mozilla.firefox_beta", "org.mozilla.fenix",
        "com.brave.browser", "com.opera.browser", "com.opera.mini.native", "com.opera.gx",
        "com.microsoft.emmx", "com.sec.android.app.sbrowser", "com.duckduckgo.mobile.android",
        "com.vivaldi.browser", "com.kiwibrowser.browser", "org.chromium.chrome", "com.yandex.browser",
        "com.mi.globalbrowser", "com.huawei.browser", "com.UCMobile.intl", "org.torproject.torbrowser",
        "app.vanadium.browser", "com.cloudmosa.puffinFree", "org.bromite.bromite", "com.ecosia.android",
        // Видео и музыка общего назначения
        "com.google.android.youtube", "com.google.android.apps.youtube.music", "com.spotify.music",
        "com.apple.android.music", "com.amazon.mp3", "deezer.android.app", "com.soundcloud.android",
        "ru.yandex.music", "com.vk.music", "com.zvooq.openplay", "com.aspiro.tidal", "com.shazam.android",
        "com.mxtech.videoplayer.ad", "org.videolan.vlc", "com.plexapp.android", "com.google.android.videos",
        "com.audiomack", "fm.castbox.audiobook.radio.podcast", "com.google.android.apps.podcasts",
        "au.com.shiftyjelly.pocketcasts", "com.podcastaddict", "com.spotify.lite",
        // Карты, транспорт, такси
        "com.google.android.apps.maps", "ru.yandex.yandexmaps", "ru.yandex.yandexnavi",
        "com.waze", "com.here.app.maps", "net.osmand", "net.osmand.plus", "com.mapbox.maps",
        "com.ubercab", "ru.yandex.taxi", "com.citymapper.app.release", "ru.yandex.yandexbus",
        "com.google.android.apps.tachyon", "ru.dublgis.dgismobile", "com.sygic.aura",
        "com.moovit", "com.grabtaxi.passenger", "com.gojek.app", "ru.mts.mtstravel",
        "com.aeroflot", "ru.rzd.pass", "com.aviasales", "ru.tutu.etrains", "ru.yandex.travel",
        // Банки и финансы
        "ru.sberbankmobile", "com.idamob.tinkoff.android", "ru.tinkoff.investing", "ru.vtb24.mobilebanking.android",
        "ru.alfabank.mobile.android", "ru.raiffeisennews", "ru.gazprombank.android.mobilebank.app",
        "com.openbank", "ru.rosbank.android", "ru.sovcombank.halva", "ru.mkb.mobile",
        "com.chase.sig.android", "com.bankofamerica.digitalwallet", "com.wf.wellsfargomobile",
        "com.citi.citimobile", "com.usaa.mobile.android.usaa", "com.capitalone.mobile.android",
        "com.revolut.revolut", "com.paypal.android.p2pmobile", "com.venmo", "com.squareup.cash",
        "com.google.android.apps.walletnfcrel", "com.coinbase.android", "com.binance.dev",
        "com.robinhood.android", "com.wise.android", "com.transferwise.android", "com.monzo.android",
        "com.starlingbank.android", "com.n26.android", "de.number26.android", "ru.yoo.money",
        "ru.mts.money", "com.ozon.bank", "ru.ftc.faktura.sovcombank", "ru.kaspi.mobile", "kz.kaspi.mobile",
        // Магазины и доставка
        "com.amazon.mShop.android.shopping", "com.ebay.mobile", "com.alibaba.aliexpresshd",
        "ru.ozon.app.android", "com.wildberries.ru", "ru.yandex.market", "ru.avito.android",
        "com.walmart.android", "com.target.ui", "com.etsy.android", "com.shopify.arrive",
        "com.zzkko", "com.temu", "com.einnovation.temu", "ru.beru.android", "ru.dodopizza.app",
        "com.mcdonalds.app", "ru.samokat", "ru.yandex.eda", "ru.deliveryclub", "com.ubercab.eats",
        "com.dd.doordash", "com.grubhub.android", "com.instacart.client", "ru.sportmaster.app",
        "ru.perekrestok.app", "ru.pyaterochka.app", "com.magnit.express", "ru.lenta.lentochka",
        // Системное и утилиты
        "com.android.settings", "com.android.vending", "com.google.android.gms", "com.android.camera",
        "com.android.camera2", "com.google.android.GoogleCamera", "com.sec.android.app.camera",
        "com.android.gallery3d", "com.google.android.apps.photos", "com.sec.android.gallery3d",
        "com.miui.gallery", "com.android.dialer", "com.google.android.dialer", "com.android.contacts",
        "com.google.android.contacts", "com.android.deskclock", "com.google.android.deskclock",
        "com.sec.android.app.clockpackage", "com.android.calculator2", "com.google.android.calculator",
        "com.miui.calculator", "com.google.android.apps.nbu.files", "com.android.documentsui",
        "com.mi.android.globalFileexplorer", "com.sec.android.app.myfiles", "com.google.android.apps.authenticator2",
        "com.authy.authy", "com.google.android.apps.translate", "ru.yandex.translate", "com.deepl.mobiletranslator",
        "com.google.android.googlequicksearchbox", "com.google.android.apps.weather", "ru.yandex.weatherplugin",
        "com.accuweather.android", "com.google.android.apps.chromecast.app", "com.xiaomi.smarthome",
        "com.samsung.android.oneconnect", "com.google.android.apps.wellbeing", "com.android.systemui",
        "com.google.android.apps.fitness", "com.samsung.android.app.notes", "com.miui.notes",
        "com.google.android.apps.recorder", "com.samsung.android.app.spage", "com.miui.securitycenter",
        "com.android.packageinstaller", "com.google.android.packageinstaller", "com.google.android.apps.subscriptions.red",
        "com.teamviewer.teamviewer.market.mobile", "com.anydesk.anydeskandroid", "com.google.android.apps.messaging",
        "com.bitwarden.mobile", "com.x8bit.bitwarden", "com.lastpass.lpandroid", "com.agilebits.onepassword",
        "com.onepassword.android", "com.keepassdx", "com.nordvpn.android", "com.expressvpn.vpn",
        "ch.protonvpn.android", "com.wireguard.android", "org.torproject.android", "com.google.android.apps.adm",
        // Гос. и сервисы
        "ru.rostel", "ru.gosuslugi.mobile", "ru.mos.app", "ru.pochta.app", "com.cdek.app", "ru.rt.video.app",
        "ru.mts.mymts", "ru.beeline.services", "ru.megafon.mlk", "ru.tele2.mytele2", "ru.yota.android",
        "com.google.android.apps.healthdata", "com.samsung.android.spay", "com.mts.mtspay"
    )

    private val lazyLc = lazy.mapTo(HashSet()) { it.lowercase() }
    private val productiveLc = productive.mapTo(HashSet()) { it.lowercase() }
    private val neutralLc = neutral.mapTo(HashSet()) { it.lowercase() }

    /** Категория из базы или null, если пакет неизвестен. */
    fun lookup(packageName: String): Category? {
        val p = packageName.lowercase()
        if (p in lazyLc) return Category.LAZY
        if (p in productiveLc) return Category.PRODUCTIVE
        if (p in neutralLc) return Category.NEUTRAL
        return null
    }

    fun guess(packageName: String): Category = lookup(packageName) ?: Category.NEUTRAL
}
