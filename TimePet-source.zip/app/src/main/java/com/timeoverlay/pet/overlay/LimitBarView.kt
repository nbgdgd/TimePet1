package com.timeoverlay.pet.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/** Тонкая скруглённая полоска прогресса (лимит развлечений или настроение). */
class LimitBarView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private var fraction = 0f
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE05A5A.toInt() }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x33FFFFFF }
    private val rect = RectF()

    fun set(fraction: Float, color: Int) {
        this.fraction = fraction.coerceIn(0f, 1f)
        fill.color = color
        invalidate()
    }

    fun setTrackColor(color: Int) {
        track.color = color
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val r = height / 2f
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        canvas.drawRoundRect(rect, r, r, track)
        val w = width * fraction
        if (w > 0f) {
            rect.right = w.coerceAtLeast(height.toFloat())
            canvas.drawRoundRect(rect, r, r, fill)
        }
    }
}
