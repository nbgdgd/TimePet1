package com.timeoverlay.pet.overlay

import android.content.Context
import android.content.SharedPreferences

/**
 * Настройки плавающего питомца. Всё локально, SharedPreferences "overlay".
 *
 * Позиция хранится в долях экрана (0..1) отдельно для портрета и ландшафта,
 * поэтому переживает поворот и смену размера; при включённом [perAppPosition]
 * — отдельно для каждого пакета, иначе одна общая. Вместе с позицией таймера
 * (домашней точкой) запоминается и последнее смещение питомца от неё.
 */
class OverlayPrefs(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = prefs.getBoolean(KEY_ENABLED, false)
        set(v) = prefs.edit().putBoolean(KEY_ENABLED, v).apply()

    /** Размер питомца в dp, 40..100. */
    var sizeDp: Int
        get() = prefs.getInt(KEY_SIZE, DEFAULT_SIZE).coerceIn(40, 120)
        set(v) = prefs.edit().putInt(KEY_SIZE, v.coerceIn(40, 120)).apply()

    /** Что показывать: питомец с таймером, только таймер, только питомец. */
    enum class Mode { BOTH, TIMER, PET }

    var mode: Mode
        get() {
            val m = prefs.getString(KEY_MODE, null)
            if (m != null) return runCatching { Mode.valueOf(m) }.getOrDefault(Mode.BOTH)
            // Старая настройка «показывать таймер».
            return if (prefs.getBoolean(KEY_TIMER, true)) Mode.BOTH else Mode.PET
        }
        set(v) = prefs.edit().putString(KEY_MODE, v.name).putBoolean(KEY_TIMER, v != Mode.PET).apply()

    val showTimer: Boolean get() = mode != Mode.PET
    val showPet: Boolean get() = mode != Mode.TIMER

    /** Простой вид: только питомец и цифры таймера, без названия и статуса. */
    var simple: Boolean
        get() = prefs.getBoolean(KEY_SIMPLE, false)
        set(v) = prefs.edit().putBoolean(KEY_SIMPLE, v).apply()

    /** Строка с иконкой и названием приложения. */
    var showAppName: Boolean
        get() = prefs.getBoolean(KEY_APP_NAME, true)
        set(v) = prefs.edit().putBoolean(KEY_APP_NAME, v).apply()

    /** Непрозрачность в процентах, 30..100. */
    var opacityPercent: Int
        get() = prefs.getInt(KEY_OPACITY, 100).coerceIn(30, 100)
        set(v) = prefs.edit().putInt(KEY_OPACITY, v.coerceIn(30, 100)).apply()

    var perAppPosition: Boolean
        get() = prefs.getBoolean(KEY_PER_APP, false)
        set(v) = prefs.edit().putBoolean(KEY_PER_APP, v).apply()

    var showOnLauncher: Boolean
        get() = prefs.getBoolean(KEY_LAUNCHER, false)
        set(v) = prefs.edit().putBoolean(KEY_LAUNCHER, v).apply()

    /** Выбранный питомец (id из PetDef.ALL). */
    var petId: String
        get() = prefs.getString(KEY_PET, "mimi") ?: "mimi"
        set(v) = prefs.edit().putString(KEY_PET, v).apply()

    /** Самостоятельные действия поверх приложений (прогулки, прыжки и т.п.). */
    var behavior: Boolean
        get() = prefs.getBoolean(KEY_BEHAVIOR, true)
        set(v) = prefs.edit().putBoolean(KEY_BEHAVIOR, v).apply()

    /** Уровень активности: 0 спокойный, 1 обычный, 2 активный. */
    var activity: Int
        get() = prefs.getInt(KEY_ACTIVITY, 1).coerceIn(0, 2)
        set(v) = prefs.edit().putInt(KEY_ACTIVITY, v.coerceIn(0, 2)).apply()

    /**
     * «Не беспокоить»: до какого момента (мс), 0 — выключено,
     * [DND_FOREVER] — до ручного отключения.
     */
    var dndUntil: Long
        get() = prefs.getLong(KEY_DND_UNTIL, 0L)
        set(v) = prefs.edit().putLong(KEY_DND_UNTIL, v).apply()

    fun isDnd(nowMs: Long = System.currentTimeMillis()): Boolean = nowMs < dndUntil

    /** Включить на [minutes] минут; 0 — до ручного отключения; отрицательное — выключить. */
    fun setDnd(minutes: Int, nowMs: Long = System.currentTimeMillis()) {
        dndUntil = when {
            minutes < 0 -> 0L
            minutes == 0 -> DND_FOREVER
            else -> nowMs + minutes * 60_000L
        }
    }

    /** Почему сервис остановился сам (нет разрешения и т.п.); null — всё в порядке. */
    var stopReason: String?
        get() = prefs.getString(KEY_STOP_REASON, null)
        set(v) = prefs.edit().putString(KEY_STOP_REASON, v).apply()

    /** Свёрнут в маленькую голову с временем. */
    var collapsed: Boolean
        get() = prefs.getBoolean(KEY_COLLAPSED, false)
        set(v) = prefs.edit().putBoolean(KEY_COLLAPSED, v).apply()

    /** Пакеты, над которыми питомца не показывать (учёт времени при этом идёт). */
    var hiddenApps: Set<String>
        get() = prefs.getStringSet(KEY_HIDDEN, emptySet())?.toSet() ?: emptySet()
        set(v) = prefs.edit().putStringSet(KEY_HIDDEN, v.toSet()).apply()

    fun isHidden(packageName: String) = hiddenApps.contains(packageName)

    fun setHidden(packageName: String, hidden: Boolean) {
        val s = hiddenApps.toMutableSet()
        if (hidden) s.add(packageName) else s.remove(packageName)
        hiddenApps = s
    }

    data class Pos(val xFrac: Float, val yFrac: Float)

    /** Позиция таймера (домашняя точка) для пакета и ориентации; null — ещё не задана. */
    fun position(packageName: String?, landscape: Boolean): Pos? {
        val key = posKey(packageName, landscape)
        if (!prefs.contains("${key}_x")) {
            // Для нового приложения — общая позиция этой ориентации; для новой
            // ориентации — позиция другой (доли экрана переносимы).
            val shared = posKey(null, landscape)
            if (key != shared && prefs.contains("${shared}_x")) return position(null, landscape)
            val other = posKey(null, !landscape)
            if (prefs.contains("${other}_x")) {
                return Pos(prefs.getFloat("${other}_x", 0f), prefs.getFloat("${other}_y", 0.15f))
            }
            return null
        }
        return Pos(prefs.getFloat("${key}_x", 0f), prefs.getFloat("${key}_y", 0.15f))
    }

    fun savePosition(packageName: String?, landscape: Boolean, pos: Pos) {
        val key = posKey(packageName, landscape)
        val shared = posKey(null, landscape)
        val e = prefs.edit().putFloat("${key}_x", pos.xFrac).putFloat("${key}_y", pos.yFrac)
        // Общая позиция обновляется всегда — она же стартовая для новых приложений.
        if (key != shared) e.putFloat("${shared}_x", pos.xFrac).putFloat("${shared}_y", pos.yFrac)
        e.apply()
    }

    /** Последнее смещение питомца от домашней точки (доля ширины экрана, со знаком). */
    fun petOffset(landscape: Boolean): Float = prefs.getFloat(offKey(landscape), 0f)

    fun savePetOffset(landscape: Boolean, frac: Float) {
        prefs.edit().putFloat(offKey(landscape), frac.coerceIn(-1f, 1f)).apply()
    }

    private fun posKey(packageName: String?, landscape: Boolean): String {
        val base = if (perAppPosition && packageName != null) "pos_$packageName" else KEY_POS
        return if (landscape) "${base}_land" else base
    }

    private fun offKey(landscape: Boolean) = if (landscape) "pet_off_land" else "pet_off"

    fun registerListener(l: SharedPreferences.OnSharedPreferenceChangeListener) =
        prefs.registerOnSharedPreferenceChangeListener(l)

    fun unregisterListener(l: SharedPreferences.OnSharedPreferenceChangeListener) =
        prefs.unregisterOnSharedPreferenceChangeListener(l)

    companion object {
        private const val PREFS = "overlay"
        const val DEFAULT_SIZE = 52
        const val DND_FOREVER = Long.MAX_VALUE
        const val KEY_ENABLED = "enabled"
        const val KEY_SIZE = "size_dp"
        const val KEY_TIMER = "show_timer"
        const val KEY_MODE = "mode"
        const val KEY_SIMPLE = "simple"
        const val KEY_APP_NAME = "show_app_name"
        const val KEY_OPACITY = "opacity"
        const val KEY_PER_APP = "per_app_pos"
        const val KEY_LAUNCHER = "show_on_launcher"
        const val KEY_COLLAPSED = "collapsed"
        const val KEY_HIDDEN = "hidden_apps"
        private const val KEY_POS = "pos"
        const val KEY_STOP_REASON = "stop_reason"
        const val KEY_PET = "pet"
        const val KEY_BEHAVIOR = "behavior"
        const val KEY_ACTIVITY = "activity"
        const val KEY_DND_UNTIL = "dnd_until"
    }
}
