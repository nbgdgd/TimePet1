package com.timeoverlay.pet.ui

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import com.timeoverlay.pet.R
import com.timeoverlay.pet.data.Category
import com.timeoverlay.pet.mood.MoodEngine
import com.timeoverlay.pet.overlay.OverlayPrefs
import com.timeoverlay.pet.overlay.OverlayView
import com.timeoverlay.pet.pet.PetDef

/**
 * Живой предпросмотр виджета в настройках и на приветствии: тот же
 * [OverlayView] (плашка) и [PetSpriteView], что поверх приложений, с
 * примерным содержимым. Размер, вид и режим применяются сразу.
 */
class OverlayPreview(context: Context) : FrameLayout(context) {

    private val row = LinearLayout(context)
    val pet = PetSpriteView(context)
    private val panel = OverlayView(context, object : OverlayView.Listener {
        override fun onDragStart() = Unit
        override fun onDragTo(rawX: Float, rawY: Float, downX: Float, downY: Float) = Unit
        override fun onDragEnd() = Unit
        override fun onToggleCollapse() = Unit
        override fun onOpenApp() = Unit
    })

    init {
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.clipChildren = false
        pet.autoIdle = false
        pet.setMood(MoodEngine.State.CONTENT)
        pet.setOnClickListener { pet.tap() }
        row.addView(pet, LinearLayout.LayoutParams(dp(52), dp(56)))
        row.addView(panel, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            marginStart = -dp(6)
        })
        // Жесты плашки в предпросмотре не нужны.
        panel.setOnTouchListener { _, _ -> true }
        panel.setApp(context.applicationInfo.loadIcon(context.packageManager), context.getString(R.string.overlay_preview_app))
        panel.setCategory(Category.PRODUCTIVE)
        panel.timer.text = context.getString(R.string.overlay_preview_timer)
        panel.setStatus(context.getString(R.string.overlay_preview_status))
        panel.setMood(MoodEngine.State.CONTENT, 72)
        clipChildren = false
        addView(row, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER))
    }

    fun setPet(def: PetDef) = pet.setPet(def)

    fun apply(prefs: OverlayPrefs) = apply(prefs.sizeDp, prefs.mode, prefs.simple, prefs.showAppName)

    fun apply(sizeDp: Int, mode: OverlayPrefs.Mode, simple: Boolean, showAppName: Boolean) {
        val lp = pet.layoutParams as LinearLayout.LayoutParams
        lp.width = dp(sizeDp)
        lp.height = dp((sizeDp * 208f / 192f).toInt())
        pet.layoutParams = lp
        panel.applyStyle(sizeDp, collapsed = false, simple = simple, showAppName = showAppName)
        (panel.layoutParams as LinearLayout.LayoutParams).width = panel.preferredWidth
        pet.visibility = if (mode == OverlayPrefs.Mode.TIMER) View.GONE else View.VISIBLE
        panel.visibility = if (mode == OverlayPrefs.Mode.PET) View.GONE else View.VISIBLE
        row.requestLayout()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
}
