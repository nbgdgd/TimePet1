package com.timeoverlay.pet.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.timeoverlay.pet.R

/** Настройки открываются с главного экрана по шестерёнке. */
class SettingsActivity : AppCompatActivity() {
    private var themeVersion = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.apply(this)
        themeVersion = ThemeManager.version
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.container, SettingsFragment())
                .commit()
        }
    }

    override fun onResume() {
        super.onResume()
        if (themeVersion != ThemeManager.version) recreate()
    }
}
