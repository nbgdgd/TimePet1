package com.timeoverlay.pet.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch
import com.timeoverlay.pet.R
import com.timeoverlay.pet.data.AppCategoryStore
import com.timeoverlay.pet.data.HistoryStore
import com.timeoverlay.pet.data.PermissionHelper
import com.timeoverlay.pet.data.PerksStore
import com.timeoverlay.pet.data.TimeFormat
import com.timeoverlay.pet.data.UsageRepository
import com.timeoverlay.pet.mood.DayMood
import com.timeoverlay.pet.mood.MoodEngine
import com.timeoverlay.pet.mood.MoodText
import com.timeoverlay.pet.mood.PetTalk
import com.timeoverlay.pet.overlay.OverlayPrefs
import com.timeoverlay.pet.overlay.PetOverlayService
import com.timeoverlay.pet.pet.PetDef
import java.util.concurrent.Executors

/**
 * Главный экран: питомец с репликой и причиной настроения, три строки
 * (настроение, состояние, продуктивность), приложения за сегодня,
 * переключатель оверлея, кольцо распределения и подсказка. Цифры — та же
 * свёртка событий, что у оверлея.
 */
class HomeFragment : Fragment(), AppDetailDialog.Listener {

    private val io = Executors.newSingleThreadExecutor()
    private var requested = 0
    private lateinit var overlayPrefs: OverlayPrefs
    private lateinit var adapter: AppUsageAdapter
    private lateinit var setup: SetupSteps
    private var bubbleText: CharSequence? = null
    private val restoreBubble = Runnable {
        val t = bubbleText ?: return@Runnable
        bubbleText = null
        view?.findViewById<TextView>(R.id.bubble)?.text = t
    }
    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { refreshSetup() }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_home, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        overlayPrefs = OverlayPrefs(requireContext())
        val pet = view.findViewById<PetSpriteView>(R.id.petView)
        val bubble = view.findViewById<TextView>(R.id.bubble)
        pet.setOnClickListener {
            // Трюк + реплика в пузыре на пару секунд, затем обычная причина настроения.
            val tap = pet.tap()
            if (bubbleText == null) bubbleText = bubble.text
            bubble.text = PetTalk.onTap(requireContext(), pet.moodState, tap)
            bubble.removeCallbacks(restoreBubble)
            bubble.postDelayed(restoreBubble, 2500)
        }

        view.findViewById<View>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(requireContext(), SettingsActivity::class.java))
        }
        view.findViewById<View>(R.id.pointsButton).setOnClickListener {
            ShopSheet().show(childFragmentManager, "shop")
        }
        view.findViewById<MaterialSwitch>(R.id.overlaySwitch)
            .setOnCheckedChangeListener { _, checked -> onSwitch(checked) }

        setup = SetupSteps.forFragment(this, view.findViewById(R.id.setupCard), notifLauncher) { refreshSetup() }

        adapter = AppUsageAdapter(AppCategoryStore(requireContext())) { app ->
            AppDetailDialog.new(app, 1).show(childFragmentManager, "detail")
        }
        val list: RecyclerView = view.findViewById(R.id.list)
        list.layoutManager = LinearLayoutManager(requireContext())
        list.adapter = adapter
        view.findViewById<View>(R.id.seeAll).setOnClickListener {
            (activity as? MainActivity)?.openTab(R.id.tab_stats)
        }

        splitRow(view.findViewById(R.id.splitLazy), R.string.cat_lazy, R.drawable.dot_lazy)
        splitRow(view.findViewById(R.id.splitNeut), R.string.cat_neutral, R.drawable.dot_neutral)
        splitRow(view.findViewById(R.id.splitProd), R.string.cat_productive, R.drawable.dot_productive)
    }

    private fun splitRow(row: View, name: Int, dot: Int) {
        row.findViewById<TextView>(R.id.splitName).setText(name)
        row.findViewById<View>(R.id.splitDot).setBackgroundResource(dot)
    }

    override fun onResume() {
        super.onResume()
        refreshSetup()
        reload()
        // Разрешения выдали, свитч включён, а сервис не поднят — поднять.
        if (overlayPrefs.enabled && PermissionHelper.hasOverlayRequired(requireContext()) &&
            !PetOverlayService.running
        ) {
            overlayPrefs.stopReason = null
            PetOverlayService.start(requireContext())
            view?.postDelayed({ refreshSetup() }, 400)
        }
    }

    /** Питомец ставится на пол сцены так, чтобы не залезать под пузырь реплики. */
    private fun placePetBelowBubble(v: View, pet: PetSpriteView, def: PetDef, sizeRes: Int) {
        val scene = v.findViewById<SceneView>(R.id.scene)
        val bubble = v.findViewById<TextView>(R.id.bubble)
        val base = resources.getDimensionPixelSize(sizeRes)
        val gap = (8 * resources.displayMetrics.density).toInt()
        scene.placePet(pet, def, base, if (bubble.height > 0) bubble.bottom + gap else 0)
        bubble.post { if (isAdded) scene.placePet(pet, def, base, bubble.bottom + gap) }
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }

    override fun onCategoryChanged() = reload()

    /** Покупка в магазине: пересчитать настроение и баланс. */
    fun onPerksChanged() = reload()

    private fun refreshSetup() {
        val v = view ?: return
        val ctx = requireContext()
        val allDone = setup.refresh()
        v.findViewById<View>(R.id.setupCard).visibility =
            if (!allDone && (overlayPrefs.enabled || !PermissionHelper.hasUsageAccess(ctx))) View.VISIBLE
            else View.GONE

        val sw = v.findViewById<MaterialSwitch>(R.id.overlaySwitch)
        val on = overlayPrefs.enabled && PetOverlayService.running
        if (sw.isChecked != on) {
            // Не дёргать слушатель при программной синхронизации.
            sw.setOnCheckedChangeListener(null)
            sw.isChecked = on
            sw.jumpDrawablesToCurrentState()
            sw.setOnCheckedChangeListener { _, checked -> onSwitch(checked) }
        }
        v.findViewById<TextView>(R.id.overlayStatus).text =
            getString(if (on) R.string.overlay_status_on else R.string.overlay_status_off)
        val reason = overlayPrefs.stopReason
        val reasonView = v.findViewById<TextView>(R.id.overlayStopReason)
        reasonView.visibility = if (reason != null && !on) View.VISIBLE else View.GONE
        reasonView.text = reason
    }

    private fun onSwitch(checked: Boolean) {
        val v = view ?: return
        if (checked) {
            overlayPrefs.enabled = true
            if (PermissionHelper.hasOverlayRequired(requireContext())) {
                overlayPrefs.stopReason = null
                PetOverlayService.start(requireContext())
                v.postDelayed({ refreshSetup() }, 400)
            }
        } else {
            overlayPrefs.enabled = false
            PetOverlayService.stop(requireContext())
        }
        refreshSetup()
    }

    private fun reload() {
        val v = view ?: return
        val pet = v.findViewById<PetSpriteView>(R.id.petView)
        val def = PetDef.byId(overlayPrefs.petId)
        pet.setPet(def)
        placePetBelowBubble(v, pet, def, R.dimen.pet_home_size)
        val ctx = requireContext().applicationContext
        val store = AppCategoryStore(ctx)

        val perks = PerksStore(ctx)
        v.findViewById<TextView>(R.id.pointsButton).text = getString(R.string.points_label, perks.balance)
        if (!PermissionHelper.hasUsageAccess(ctx)) {
            // Честное состояние без данных: питомец спокоен, цифры по нулям.
            val state = if (DayMood.isNight() && !perks.isAwake()) MoodEngine.State.SLEEP else MoodEngine.State.CONTENT
            pet.setMood(state)
            bubbleText = null
            v.findViewById<TextView>(R.id.bubble).text = PetTalk.say(requireContext(), state)
            v.findViewById<TextView>(R.id.reasonText).text = getString(R.string.no_permission_bubble)
            showReasonBar(v, DayMood.Totals(0, 0, 0, 0), null)
            showTotals(v, DayMood.Totals(0, 0, 0, 0), emptyList())
            showInsight(v, getString(R.string.no_permission_text), ctx.themeColor(R.attr.tp_seed))
            return
        }

        val myRequest = ++requested
        io.execute {
            val now = System.currentTimeMillis()
            val snap = UsageRepository(ctx).queryToday(now)
            val perPackage = snap.apps.associate { it.packageName to it.millis }
            val totals = DayMood.totals(perPackage, store).copy(totalMs = snap.totalMillis)
            perks.credit(HistoryStore(ctx).todayKey(), totals.productiveMs)
            val result = DayMood.compute(totals, store, now, perks)
            val score = MoodEngine.productivityScore(
                totals.productiveMs, totals.lazyMs, totals.neutralMs, store.funAllowanceMinutes
            )
            activity?.runOnUiThread {
                if (!isAdded || myRequest != requested) return@runOnUiThread
                v.findViewById<TextView>(R.id.pointsButton).text = getString(R.string.points_label, perks.balance)
                pet.setMood(result.state)
                bubbleText = null
                v.findViewById<TextView>(R.id.bubble).text = PetTalk.say(requireContext(), result.state)
                v.findViewById<TextView>(R.id.reasonText).text = MoodText.reasonTitle(requireContext(), result)
                showReasonBar(v, totals, result)
                showTotals(v, totals, snap.apps.take(5), snap.totalMillis)
                showInsight(
                    v, MoodText.insight(requireContext(), result),
                    ContextCompat.getColor(requireContext(), MoodText.colorRes(result.state))
                )
            }
        }
    }

    /** Подсказка внизу: первая фраза жирным в цвете состояния, остальное обычным. */
    private fun showInsight(v: View, text: String, color: Int) {
        val cut = text.indexOf(". ")
        val title = if (cut > 0) text.substring(0, cut + 1) else text
        val rest = if (cut > 0) text.substring(cut + 2) else ""
        v.findViewById<TextView>(R.id.insightTitle).apply { this.text = title; setTextColor(color) }
        v.findViewById<TextView>(R.id.insightText).apply {
            this.text = rest
            visibility = if (rest.isEmpty()) View.GONE else View.VISIBLE
        }
        v.findViewById<View>(R.id.insight).setOnClickListener {
            (activity as? MainActivity)?.openTab(R.id.tab_stats)
        }
    }

    /** Полоска дня под причиной: полезное / развлечения / нейтральное, с минутами под ней. */
    private fun showReasonBar(v: View, t: DayMood.Totals, r: MoodEngine.Result?) {
        val ctx = requireContext()
        v.findViewById<SplitBarView>(R.id.reasonBar).setValues(t.productiveMs, t.lazyMs, t.neutralMs)
        val prodMin = (t.productiveMs / 60_000L).toInt()
        val lazyMin = (t.lazyMs / 60_000L).toInt()
        val limit = r?.allowanceMin ?: AppCategoryStore(ctx).funAllowanceMinutes
        v.findViewById<TextView>(R.id.reasonProd).text =
            getString(R.string.reason_prod_caption, MoodText.minutesText(ctx, prodMin))
        v.findViewById<TextView>(R.id.reasonLazy).text =
            if (limit > 0) getString(R.string.reason_lazy_caption_limit, lazyMin, limit)
            else getString(R.string.reason_lazy_caption, MoodText.minutesText(ctx, lazyMin))
    }

    private fun showTotals(v: View, t: DayMood.Totals, apps: List<UsageRepository.AppUsage>, totalMs: Long = t.totalMs) {
        val ctx = requireContext()
        v.findViewById<TextView>(R.id.totalValue).text = TimeFormat.long(ctx, totalMs)
        adapter.submit(apps)
        v.findViewById<View>(R.id.emptyState).visibility = if (apps.isEmpty()) View.VISIBLE else View.GONE
        v.findViewById<View>(R.id.seeAll).visibility = if (apps.isEmpty()) View.GONE else View.VISIBLE
        // «Другие»: всё, что не вошло в первые пять.
        val others = totalMs - apps.sumOf { it.millis }
        v.findViewById<View>(R.id.othersRow).visibility = if (apps.isNotEmpty() && others > 0) View.VISIBLE else View.GONE
        v.findViewById<TextView>(R.id.othersTime).text = TimeFormat.long(ctx, others)

        v.findViewById<DonutView>(R.id.donut).set(
            t.lazyMs, t.neutralMs, t.productiveMs,
            TimeFormat.long(ctx, t.totalMs), getString(R.string.home_total_label)
        )
        val denom = (t.lazyMs + t.neutralMs + t.productiveMs).coerceAtLeast(1L)
        fun row(id: Int, ms: Long) {
            val r = v.findViewById<View>(id)
            r.findViewById<TextView>(R.id.splitPercent).text = "${(ms * 100 / denom)}%"
            r.findViewById<TextView>(R.id.splitTime).text = TimeFormat.long(ctx, ms)
        }
        row(R.id.splitLazy, t.lazyMs)
        row(R.id.splitNeut, t.neutralMs)
        row(R.id.splitProd, t.productiveMs)
    }
}
