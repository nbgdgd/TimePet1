package com.timeoverlay.pet.ui

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.os.SystemClock
import android.provider.Settings
import android.util.AttributeSet
import android.view.View
import com.timeoverlay.pet.R
import com.timeoverlay.pet.data.AppPrefs
import com.timeoverlay.pet.mood.MoodEngine
import com.timeoverlay.pet.pet.PetAtlas
import com.timeoverlay.pet.pet.PetAction
import com.timeoverlay.pet.pet.PetClip
import com.timeoverlay.pet.pet.PetDef
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Питомец: покадровая анимация из общего атласа ([PetAtlas]), один и тот же
 * View на главном экране, в карточках выбора и в оверлее.
 *
 * - Базовый клип задаётся настроением ([setMood]); поверх него можно
 *   проиграть одноразовую реакцию ([react], [play]).
 * - Смена базового клипа не рвёт движение: текущий цикл доигрывается,
 *   между «лежачими» и «стоячими» позами вставляется цикл idle,
 *   кадры на стыке смешиваются кроссфейдом 220 мс.
 * - Дыхание — лёгкое масштабирование от нижней точки; моргание уже есть
 *   в кадрах idle. В счастливом настроении питомец иногда подпрыгивает,
 *   в спокойном — оглядывается ([autoIdle]; в оверлее этим занимается
 *   [com.timeoverlay.pet.overlay.PetBehavior]).
 * - Анимация идёт только пока View реально виден ([setAnimating] выключает
 *   её при погашенном экране). Статичный режим — один кадр текущего
 *   состояния без дыхания и кроссфейда: при системном
 *   ANIMATOR_DURATION_SCALE = 0 или выключенной настройке «Анимация питомца».
 */
class PetSpriteView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private var def: PetDef = PetDef.MIMI
    private var atlas: Bitmap? = null
    private val src = Rect()
    private val fadeSrc = Rect()
    private val dst = RectF()
    /** Сглаживание при масштабировании (общая настройка «Сглаживание питомцев»). */
    private val paint = Paint()
    private val zzzPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF4A6FA5.toInt()
        isFakeBoldText = true
    }
    private val appPrefs = AppPrefs(context)
    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            AppPrefs.KEY_ANIMATIONS -> refreshStatic()
            AppPrefs.KEY_SMOOTH -> refreshSmoothing()
        }
    }

    /** Базовое действие от настроения. */
    private var base: PetAction = PetAction.IDLE
    /** Что играет сейчас (база, переход или реакция). */
    private var currentAction: PetAction = PetAction.IDLE
    private var current: PetClip = def.clip(PetAction.IDLE)
    private var frameIndex = 0
    private var frameStarted = 0L
    /** Очередь: действия, которые нужно проиграть по одному разу до возврата к базе. */
    private val queue = ArrayDeque<PetAction>()
    private var pendingBase: PetAction? = null

    private var fadeRow = -1
    private var fadeCol = 0
    private var fadeMirror = false
    private var fadeStart = 0L

    private var sleeping = false
    private var breathing = true
    private var calm = false
    private var animating = false
    private var wantAnimating = true
    private var nextIdleReaction = 0L
    private var mood: MoodEngine.State = MoodEngine.State.CONTENT

    // Касания: быстрые повторные тапы надоедают питомцу; сердечки летят вверх.
    private var tapCount = 0
    private var lastTapAt = 0L
    private val hearts = ArrayList<Heart>()
    private val heartPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF6B8A.toInt() }
    private val heartPath = Path()

    private class Heart(var x: Float, var y: Float, val vx: Float, val vy: Float, val size: Float, val born: Long)

    /** Уменьшенный атлас для карточек выбора (задать до [setPet]). */
    var preview = false

    /** Редкие самостоятельные движения на месте (прыжок, оглядеться). */
    var autoIdle = true

    /** Вызывается по завершении одноразовой реакции (например, чтобы вернуть таймер). */
    var onReactionEnd: (() -> Unit)? = null

    private val ticker = object : Runnable {
        override fun run() {
            if (!animating) return
            step()
            invalidate()
            val now = SystemClock.uptimeMillis()
            val frameLeft = (frameStarted + current.durations[frameIndex] - now).coerceAtLeast(1L)
            val delay = if (breathing && !calm) min(frameLeft, BREATH_TICK_MS) else frameLeft
            postDelayed(this, delay)
        }
    }

    init {
        contentDescription = context.getString(R.string.pet_content_desc)
        calm = readStatic()
        refreshSmoothing()
        setPet(PetDef.MIMI)
    }

    /**
     * Сглаживание: билинейная фильтрация смягчает края при масштабировании.
     * Кадры рисуются из одного атласа через src-прямоугольник; пиксели по
     * краям ячейки прозрачные, поэтому соседние кадры не подмешиваются.
     * Выключено — ближайший пиксель, исходный резкий вид.
     */
    fun refreshSmoothing() {
        paint.isFilterBitmap = appPrefs.smoothing
        paint.isAntiAlias = appPrefs.smoothing
        invalidate()
    }

    // ---- публичное API ----

    /** Сменить питомца (атлас и раскладку действий). */
    fun setPet(newDef: PetDef) {
        if (newDef.id == def.id && atlas != null) return
        def = newDef
        atlas = PetAtlas.get(context, newDef, preview)
        current = def.clip(currentAction)
        frameIndex = if (calm) current.still else 0
        fadeRow = -1
        requestLayout()
        invalidate()
    }

    val pet: PetDef get() = def

    fun setMood(state: MoodEngine.State) {
        mood = state
        sleeping = state == MoodEngine.State.SLEEP
        val action = when (state) {
            MoodEngine.State.HAPPY -> PetAction.HAPPY
            MoodEngine.State.CONTENT -> PetAction.IDLE
            MoodEngine.State.TIRED -> PetAction.TIRED
            MoodEngine.State.SAD -> PetAction.SAD
            MoodEngine.State.EXHAUSTED -> PetAction.EXHAUSTED
            MoodEngine.State.SLEEP -> PetAction.SLEEP
        }
        setBase(action)
    }

    val moodState: MoodEngine.State get() = mood

    /** Цвет акцента текущего питомца (для плашки). */
    val accentColor: Int get() = def.accentColor

    /** Что вышло из касания — чтобы экран подобрал реплику. */
    enum class Tap { TRICK, ANNOYED, SLEEPY }

    /**
     * Касание: питомец показывает случайный трюк по настроению, вверх летят
     * сердечки; третий быстрый тап подряд — надоело (сердитый взгляд, без
     * сердечек); спящего не будим — только шевелится.
     */
    fun tap(): Tap {
        val now = SystemClock.uptimeMillis()
        if (now - lastTapAt > TAP_WINDOW_MS) tapCount = 0
        tapCount++
        lastTapAt = now
        if (sleeping) {
            play(PetAction.REVIEW)
            return Tap.SLEEPY
        }
        if (tapCount >= 3) {
            tapCount = 0
            play(PetAction.ANNOYED)
            return Tap.ANNOYED
        }
        // Трюк уже идёт — не перезапускать (иначе от частых тапов питомец дёргается),
        // только сердечки; тап всё равно считается для «надоело».
        if (isBusy && !isMoving) {
            burstHearts()
            return Tap.TRICK
        }
        val tricks = when (mood) {
            MoodEngine.State.HAPPY -> listOf(PetAction.CELEBRATE, PetAction.JUMP, PetAction.WAVE, PetAction.WOBBLE)
            MoodEngine.State.CONTENT -> listOf(PetAction.WAVE, PetAction.JUMP, PetAction.LOOK_AROUND, PetAction.STRETCH, PetAction.WOBBLE)
            MoodEngine.State.TIRED -> listOf(PetAction.WAVE, PetAction.LOOK_AROUND, PetAction.SIT)
            MoodEngine.State.SAD, MoodEngine.State.EXHAUSTED -> listOf(PetAction.REVIEW, PetAction.LOOK_AROUND)
            MoodEngine.State.SLEEP -> listOf(PetAction.REVIEW)
        }.filter { def.has(it) }.ifEmpty { listOf(PetAction.WAVE) }
        play(tricks.random())
        burstHearts()
        return Tap.TRICK
    }

    /** Совместимость: простая реакция без учёта тапов. */
    fun react() { tap() }

    private fun burstHearts() {
        if (calm) return
        val now = SystemClock.uptimeMillis()
        val cx = width / 2f
        val top = height * 0.25f
        repeat(6) {
            hearts.add(
                Heart(
                    cx + (Random.nextFloat() - 0.5f) * width * 0.5f, top + Random.nextFloat() * height * 0.15f,
                    (Random.nextFloat() - 0.5f) * 0.03f, -(0.05f + Random.nextFloat() * 0.04f),
                    height * (0.11f + Random.nextFloat() * 0.07f), now + Random.nextLong(250)
                )
            )
        }
        invalidate()
    }

    private fun drawHearts(canvas: Canvas, now: Long) {
        if (hearts.isEmpty()) return
        val it = hearts.iterator()
        while (it.hasNext()) {
            val h = it.next()
            val age = now - h.born
            if (age < 0) continue
            if (age > HEART_LIFE_MS) { it.remove(); continue }
            val t = age / HEART_LIFE_MS.toFloat()
            val x = h.x + h.vx * age
            val y = h.y + h.vy * age
            val s = h.size * (0.6f + 0.4f * (1f - t))
            heartPaint.alpha = ((1f - t) * 230).toInt()
            heartPath.reset()
            // Сердечко: два круга сверху и треугольник вниз.
            heartPath.moveTo(x, y + s * 0.55f)
            heartPath.lineTo(x - s * 0.5f, y)
            heartPath.arcTo(x - s * 0.5f, y - s * 0.3f, x, y + s * 0.2f, 180f, 180f, false)
            heartPath.arcTo(x, y - s * 0.3f, x + s * 0.5f, y + s * 0.2f, 180f, 180f, false)
            heartPath.close()
            canvas.drawPath(heartPath, heartPaint)
        }
        if (hearts.isNotEmpty()) postInvalidateDelayed(24)
    }

    /** Проиграть действие один раз поверх базового состояния. */
    fun play(action: PetAction) {
        if (calm) return
        queue.clear()
        // Реакция начинается сразу, но через кроссфейд — не рывком.
        switchTo(action, crossfade = true)
    }

    /** Проиграть зацикленный клип (например, грусть) не дольше [maxMs], затем вернуться к базе. */
    fun playOnce(action: PetAction, maxMs: Long) {
        play(action)
        postDelayed({
            if (currentAction == action && action != base) {
                onReactionEnd?.invoke()
                switchTo(base, crossfade = true)
            }
        }, maxMs)
    }

    /** Идёт ли сейчас одноразовое действие (не база). */
    val isBusy: Boolean get() = currentAction != base || queue.isNotEmpty()

    /** Ходьба при перетаскивании и при самостоятельном движении: направление по знаку dx. */
    fun walk(dx: Float, run: Boolean = false) {
        if (calm || sleeping) return
        val action = if (run) {
            if (dx < 0) PetAction.RUN_LEFT else PetAction.RUN_RIGHT
        } else {
            if (dx < 0) PetAction.WALK_LEFT else PetAction.WALK_RIGHT
        }
        if (currentAction != action) {
            queue.clear()
            switchTo(action, crossfade = true)
        }
    }

    /** Движение закончилось — вернуться к базовому состоянию. */
    fun stopWalking() {
        if (isMoving) {
            queue.clear()
            switchTo(base, crossfade = true)
        }
    }

    val isMoving: Boolean
        get() = currentAction == PetAction.WALK_LEFT || currentAction == PetAction.WALK_RIGHT ||
            currentAction == PetAction.RUN_LEFT || currentAction == PetAction.RUN_RIGHT

    /** Дыхание можно выключить в оверлее ради батареи. */
    fun setBreathing(enabled: Boolean) {
        breathing = enabled
    }

    /** Останавливает анимации (экран погас) или возобновляет. */
    fun setAnimating(enabled: Boolean) {
        wantAnimating = enabled
        updateRunning()
    }

    val isSleeping: Boolean get() = sleeping

    /** Статичный режим (настройка или системное отключение анимаций). */
    val isStatic: Boolean get() = calm

    // ---- внутреннее ----

    private fun setBase(action: PetAction) {
        if (action == base && pendingBase == null) return
        base = action
        if (calm) {
            showStill(action)
            return
        }
        // Доиграть текущий цикл, затем перейти (при смене позы — через idle).
        pendingBase = action
    }

    private fun showStill(action: PetAction) {
        queue.clear()
        pendingBase = null
        currentAction = action
        current = def.clip(action)
        frameIndex = current.still
        fadeRow = -1
        invalidate()
    }

    private fun postureOf(a: PetAction): Int = when (a) {
        PetAction.SAD, PetAction.EXHAUSTED, PetAction.SLEEP, PetAction.LIE -> 1
        else -> 0
    }

    private fun switchTo(action: PetAction, crossfade: Boolean) {
        if (crossfade && !calm) {
            fadeRow = current.rowAt(frameIndex.coerceIn(0, current.frames.size - 1))
            fadeCol = current.frames[frameIndex.coerceIn(0, current.frames.size - 1)]
            fadeMirror = current.mirror
            fadeStart = SystemClock.uptimeMillis()
        } else {
            fadeRow = -1
        }
        currentAction = action
        current = def.clip(action)
        frameIndex = 0
        frameStarted = SystemClock.uptimeMillis()
        invalidate()
    }

    private fun step() {
        val now = SystemClock.uptimeMillis()
        if (now - frameStarted < current.durations[frameIndex]) return
        frameStarted = now
        frameIndex++
        if (frameIndex < current.frames.size) return
        // Цикл закончился — решить, что дальше.
        frameIndex = 0
        // Ходьба и бег крутятся, пока движение не остановят ([stopWalking]):
        // это не одноразовая реакция, кадры должны идти всё время пути.
        if (isMoving) return
        val next = queue.removeFirstOrNull()
        if (next != null) {
            switchTo(next, crossfade = true)
            return
        }
        if (!current.loop || currentAction != base) {
            // Реакция или переходный клип отыграл: вернуться к базе.
            onReactionEnd?.invoke()
        }
        val pb = pendingBase
        if (pb != null) {
            pendingBase = null
            if (postureOf(pb) != postureOf(currentAction) && currentAction != PetAction.IDLE && pb != PetAction.IDLE) {
                // Смена позы через промежуточное движение.
                queue.addLast(pb)
                switchTo(PetAction.IDLE, crossfade = true)
            } else {
                switchTo(pb, crossfade = true)
            }
            return
        }
        if (currentAction != base) {
            switchTo(base, crossfade = true)
            return
        }
        // База зациклена: иногда — маленькое «живое» движение.
        if (autoIdle && now >= nextIdleReaction) {
            scheduleIdleReaction(now)
            when (mood) {
                MoodEngine.State.HAPPY -> {
                    queue.addLast(base)
                    switchTo(PetAction.JUMP, crossfade = true)
                }
                MoodEngine.State.CONTENT -> switchTo(PetAction.LOOK_AROUND, crossfade = true)
                else -> Unit
            }
        }
    }

    private fun scheduleIdleReaction(now: Long) {
        // Редкие «живые» движения: питомец не должен дёргаться постоянно.
        val (lo, hi) = when (mood) {
            MoodEngine.State.HAPPY -> 20_000L to 40_000L
            else -> 45_000L to 90_000L
        }
        nextIdleReaction = now + lo + Random.nextLong(hi - lo)
    }

    private fun readStatic(): Boolean {
        if (!appPrefs.animations) return true
        return runCatching {
            Settings.Global.getFloat(
                context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f
            ) == 0f
        }.getOrDefault(false)
    }

    /** Перечитать настройку анимации; в статичном режиме — показать кадр состояния. */
    fun refreshStatic() {
        val was = calm
        calm = readStatic()
        if (calm) {
            showStill(base)
        } else if (was) {
            frameStarted = SystemClock.uptimeMillis()
            frameIndex = 0
        }
        updateRunning()
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        appPrefs.registerListener(prefsListener)
        refreshStatic()
        refreshSmoothing()
        scheduleIdleReaction(SystemClock.uptimeMillis())
        updateRunning()
    }

    override fun onDetachedFromWindow() {
        appPrefs.unregisterListener(prefsListener)
        animating = false
        removeCallbacks(ticker)
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        updateRunning()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        updateRunning()
    }

    private fun updateRunning() {
        val want = wantAnimating && !calm && isAttachedToWindow &&
            visibility == VISIBLE && windowVisibility == VISIBLE
        if (want && !animating) {
            animating = true
            frameStarted = SystemClock.uptimeMillis()
            removeCallbacks(ticker)
            post(ticker)
        } else if (!want && animating) {
            animating = false
            removeCallbacks(ticker)
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val bmp = atlas
        if (bmp == null) {
            super.onMeasure(widthMeasureSpec, heightMeasureSpec)
            return
        }
        val ratio = PetAtlas.cellHeight(bmp).toFloat() / PetAtlas.cellWidth(bmp)
        val wMode = MeasureSpec.getMode(widthMeasureSpec)
        val hMode = MeasureSpec.getMode(heightMeasureSpec)
        val wSize = MeasureSpec.getSize(widthMeasureSpec)
        val hSize = MeasureSpec.getSize(heightMeasureSpec)
        val w: Int
        val h: Int
        if (wMode == MeasureSpec.EXACTLY && hMode != MeasureSpec.EXACTLY) {
            w = wSize; h = (w * ratio).toInt()
        } else if (hMode == MeasureSpec.EXACTLY && wMode != MeasureSpec.EXACTLY) {
            h = hSize; w = (h / ratio).toInt()
        } else {
            w = wSize; h = hSize
        }
        setMeasuredDimension(resolveSize(w, widthMeasureSpec), resolveSize(h, heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bmp = atlas ?: return
        val cw = PetAtlas.cellWidth(bmp)
        val ch = PetAtlas.cellHeight(bmp)
        val scale = min(width / cw.toFloat(), height / ch.toFloat())
        val dw = cw * scale
        val dh = ch * scale
        val left = (width - dw) / 2f
        val top = (height - dh) / 2f
        dst.set(left, top, left + dw, top + dh)

        val now = SystemClock.uptimeMillis()
        val saved = canvas.save()
        if (breathing && animating && !calm) {
            // Дыхание: ±1.5 % по высоте от нижней точки, спящий дышит медленнее.
            val period = if (sleeping) 3200.0 else 2000.0
            val s = 1f + 0.015f * sin(now / period * 2 * Math.PI).toFloat()
            canvas.scale(1f + (s - 1f) * 0.4f, s, width / 2f, top + dh)
        }

        val i = frameIndex.coerceIn(0, current.frames.size - 1)
        PetAtlas.src(bmp, current.rowAt(i), current.frames[i], src)
        // Новый кадр всегда непрозрачный, старый растворяется поверх: без
        // «просвечивания» на стыке, из-за которого питомец мигал.
        drawFrame(canvas, bmp, src, current.mirror)
        if (fadeRow >= 0 && !calm) {
            val t = ((now - fadeStart) / FADE_MS.toFloat()).coerceIn(0f, 1f)
            PetAtlas.src(bmp, fadeRow, fadeCol, fadeSrc)
            paint.alpha = ((1f - t) * 255).toInt()
            drawFrame(canvas, bmp, fadeSrc, fadeMirror)
            paint.alpha = 255
            if (t >= 1f) fadeRow = -1 else postInvalidateDelayed(16)
        }
        canvas.restoreToCount(saved)
        drawHearts(canvas, now)

        if (sleeping && def.drawZzz) drawZzz(canvas, now, left, top, dw, dh)
    }

    /** Кадр из атласа, при [mirror] — отражённый по горизонтали (бег влево). */
    private fun drawFrame(canvas: Canvas, bmp: Bitmap, from: Rect, mirror: Boolean) {
        if (!mirror) {
            canvas.drawBitmap(bmp, from, dst, paint)
            return
        }
        val c = canvas.save()
        canvas.scale(-1f, 1f, dst.centerX(), dst.centerY())
        canvas.drawBitmap(bmp, from, dst, paint)
        canvas.restoreToCount(c)
    }

    private fun drawZzz(canvas: Canvas, now: Long, left: Float, top: Float, dw: Float, dh: Float) {
        // Три «z» всплывают по очереди; в статичном режиме — неподвижно.
        val phase = if (calm) 0.5f else ((now % 2400L) / 2400f)
        val base = dh * 0.30f
        for (i in 0 until 3) {
            val p = ((phase + i * 0.33f) % 1f)
            val size = base * (0.45f + 0.25f * i)
            zzzPaint.textSize = size
            zzzPaint.alpha = ((1f - p) * 220).toInt().coerceIn(0, 255)
            val x = left + dw * (0.68f + 0.10f * i) + dw * 0.06f * sin(p * Math.PI).toFloat()
            val y = top + dh * (0.34f - 0.10f * i) - dh * 0.18f * p
            canvas.drawText("z", x, y, zzzPaint)
        }
        if (!calm && animating) postInvalidateDelayed(80)
    }

    companion object {
        private const val FADE_MS = 160L
        private const val BREATH_TICK_MS = 70L
        private const val TAP_WINDOW_MS = 2_000L
        private const val HEART_LIFE_MS = 900L
    }
}
