package com.timeoverlay.pet.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.slider.Slider
import com.timeoverlay.pet.R
import com.timeoverlay.pet.data.AppPrefs
import com.timeoverlay.pet.mood.MoodEngine
import com.timeoverlay.pet.overlay.OverlayPrefs
import com.timeoverlay.pet.overlay.PetOverlayService
import com.timeoverlay.pet.pet.PetAction
import com.timeoverlay.pet.pet.PetDef
import java.util.Locale

/**
 * Приветствие при первом запуске, по шагам: 1) знакомство, демонстрация
 * настоящего бега, язык; 2) что показывать поверх приложений и размер с
 * живым предпросмотром; 3) уровень активности; 4) разрешения (обязательны
 * статистика и «поверх приложений»). Кнопки «Назад» / «Далее» / «Готово»,
 * пропуска нет. После «Готово» флаг сохраняется и экран больше не
 * показывается. Все настройки — те же, что во вкладке «Питомец».
 */
class OnboardingActivity : AppCompatActivity() {

    private lateinit var steps: SetupSteps
    private lateinit var prefs: AppPrefs
    private lateinit var overlayPrefs: OverlayPrefs
    private lateinit var pet: PetSpriteView
    private lateinit var preview: OverlayPreview
    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { refresh() }

    private var themeVersion = -1
    private var page = 0
    private var demoRunning = false
    private val demo = Runnable { runDemo() }
    private val pages = intArrayOf(R.id.page0, R.id.page1, R.id.page2, R.id.page3)

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.apply(this)
        themeVersion = ThemeManager.version
        super.onCreate(savedInstanceState)
        prefs = AppPrefs(this)
        if (prefs.onboarded) {
            openMain()
            return
        }
        setContentView(R.layout.activity_onboarding)
        overlayPrefs = OverlayPrefs(this)
        val def = PetDef.byId(overlayPrefs.petId)

        pet = findViewById(R.id.petView)
        pet.setPet(def)
        pet.setMood(MoodEngine.State.CONTENT)
        pet.autoIdle = false
        pet.setOnClickListener { pet.tap() }
        findViewById<SceneView>(R.id.scene).placePet(pet, def, resources.getDimensionPixelSize(R.dimen.onboard_pet_size))
        findViewById<TextView>(R.id.onboardTitle).text = getString(R.string.onboard_title, def.displayName)

        setupLanguage()
        setupMode()
        setupSize(def)
        setupActivity()
        steps = SetupSteps.forActivity(this, findViewById(R.id.stepsRoot), notifLauncher) { refresh() }

        findViewById<MaterialButton>(R.id.backButton).setOnClickListener { showPage(page - 1) }
        findViewById<MaterialButton>(R.id.nextButton).setOnClickListener {
            if (page < pages.size - 1) showPage(page + 1) else finishOnboarding()
        }
        page = savedInstanceState?.getInt("page", 0) ?: 0
        showPage(page)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("page", page)
    }

    private fun showPage(index: Int) {
        page = index.coerceIn(0, pages.size - 1)
        for ((i, id) in pages.withIndex()) findViewById<View>(id).visibility = if (i == page) View.VISIBLE else View.GONE
        findViewById<TextView>(R.id.stepLabel).text = getString(R.string.onboard_step, page + 1, pages.size)
        findViewById<MaterialButton>(R.id.backButton).visibility = if (page == 0) View.INVISIBLE else View.VISIBLE
        val next = findViewById<MaterialButton>(R.id.nextButton)
        next.setText(if (page == pages.size - 1) R.string.onboard_done else R.string.onboard_next)
        findViewById<ScrollView>(R.id.scroll).scrollTo(0, 0)
        refresh()
        // Демонстрация бега только на первом шаге.
        pet.removeCallbacks(demo)
        if (page == 0) pet.postDelayed(demo, 900L) else stopDemo()
    }

    private fun finishOnboarding() {
        if (!steps.requiredDone()) { refresh(); return }
        prefs.onboarded = true
        overlayPrefs.enabled = true
        PetOverlayService.start(this)
        openMain()
    }

    private fun setupLanguage() {
        val group: MaterialButtonToggleGroup = findViewById(R.id.langGroup)
        val current = prefs.language.ifEmpty { Locale.getDefault().language }
        group.check(when (current) { "ru" -> R.id.langRu; "de" -> R.id.langDe; else -> R.id.langEn })
        group.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            val tag = when (id) { R.id.langRu -> "ru"; R.id.langDe -> "de"; else -> "en" }
            if (tag != prefs.language) {
                prefs.language = tag
                prefs.applyLanguage()
            }
        }
    }

    private fun setupMode() {
        val list = OptionList(
            findViewById(R.id.modeList),
            listOf(getString(R.string.mode_both), getString(R.string.mode_timer), getString(R.string.mode_pet))
        ) { i ->
            overlayPrefs.mode = OverlayPrefs.Mode.values()[i]
            preview.apply(overlayPrefs)
        }
        list.select(overlayPrefs.mode.ordinal)
    }

    private fun setupSize(def: PetDef) {
        preview = OverlayPreview(this)
        preview.setPet(def)
        findViewById<FrameLayout>(R.id.sizePreview).addView(
            preview, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        preview.apply(overlayPrefs)
        val slider: Slider = findViewById(R.id.sizeSlider)
        val value: TextView = findViewById(R.id.sizeValue)
        slider.value = overlayPrefs.sizeDp.coerceIn(40, 100).toFloat()
        value.text = getString(R.string.overlay_size_value, overlayPrefs.sizeDp)
        slider.addOnChangeListener { _, v, _ ->
            overlayPrefs.sizeDp = v.toInt()
            value.text = getString(R.string.overlay_size_value, v.toInt())
            preview.apply(overlayPrefs)
        }
    }

    /**
     * Демонстрация бега: питомец пробегает сцену слева направо теми же кадрами
     * и с той же скоростью, что поверх приложений (120 dp/с), возвращается шагом.
     */
    private fun runDemo() {
        if (demoRunning || isFinishing || page != 0) return
        val scene = findViewById<View>(R.id.demoScene)
        val half = (scene.width - pet.width) / 2f
        if (half <= 0f) { pet.postDelayed(demo, 500); return }
        demoRunning = true
        val d = resources.displayMetrics.density
        val ms = (half * 2 / (120f * d) * 1000f).toLong().coerceIn(600L, 4_000L)
        // Старт с центра: сначала бег влево к краю, затем через всю сцену вправо, потом шагом домой.
        pet.walk(-1f, run = true)
        pet.animate().translationX(-half).setDuration(ms / 2).setInterpolator(LinearInterpolator()).withEndAction {
            pet.walk(1f, run = true)
            pet.animate().translationX(half).setDuration(ms).setInterpolator(LinearInterpolator()).withEndAction {
                pet.stopWalking()
                pet.play(PetAction.LOOK_AROUND)
                pet.postDelayed({
                    if (isFinishing) return@postDelayed
                    pet.walk(-1f, run = false)
                    pet.animate().translationX(0f).setDuration(ms * 3 / 2).setInterpolator(LinearInterpolator()).withEndAction {
                        pet.stopWalking()
                        demoRunning = false
                        pet.play(PetAction.WAVE)
                        pet.postDelayed(demo, 7_000L)
                    }.start()
                }, 1_800L)
            }.start()
        }.start()
    }

    private fun stopDemo() {
        pet.removeCallbacks(demo)
        pet.animate().cancel()
        pet.translationX = 0f
        if (demoRunning) pet.stopWalking()
        demoRunning = false
    }

    /** Коротко: как питомец ведёт себя поверх приложений (можно поменять во вкладке «Питомец»). */
    private fun setupActivity() {
        val group: MaterialButtonToggleGroup = findViewById(R.id.activityGroup)
        val hint: TextView = findViewById(R.id.activityHint)
        fun show() {
            hint.setText(
                when {
                    !overlayPrefs.behavior -> R.string.level_off_hint
                    overlayPrefs.activity == 0 -> R.string.level_calm_hint
                    overlayPrefs.activity == 2 -> R.string.level_active_hint
                    else -> R.string.level_normal_hint
                }
            )
        }
        group.check(
            when {
                !overlayPrefs.behavior -> R.id.activityOff
                overlayPrefs.activity == 0 -> R.id.activityCalm
                overlayPrefs.activity == 2 -> R.id.activityActive
                else -> R.id.activityNormal
            }
        )
        show()
        group.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            when (id) {
                R.id.activityOff -> overlayPrefs.behavior = false
                R.id.activityCalm -> { overlayPrefs.behavior = true; overlayPrefs.activity = 0 }
                R.id.activityActive -> { overlayPrefs.behavior = true; overlayPrefs.activity = 2 }
                else -> { overlayPrefs.behavior = true; overlayPrefs.activity = 1 }
            }
            show()
        }
    }

    override fun onResume() {
        super.onResume()
        if (themeVersion != ThemeManager.version) { recreate(); return }
        if (::steps.isInitialized) refresh()
        if (::pet.isInitialized && page == 0) { pet.removeCallbacks(demo); pet.postDelayed(demo, 900L) }
    }

    override fun onPause() {
        super.onPause()
        if (::pet.isInitialized) stopDemo()
    }

    private fun refresh() {
        if (!::steps.isInitialized) return
        steps.refresh()
        val ready = steps.requiredDone()
        val last = page == pages.size - 1
        findViewById<MaterialButton>(R.id.nextButton).isEnabled = !last || ready
        findViewById<TextView>(R.id.onboardHint).visibility = if (ready) View.GONE else View.VISIBLE
    }

    private fun openMain() {
        // Экстры (в т.ч. отладочные) пробрасываются на главный.
        startActivity(Intent(this, MainActivity::class.java).apply { intent?.extras?.let { putExtras(it) } })
        finish()
    }
}
