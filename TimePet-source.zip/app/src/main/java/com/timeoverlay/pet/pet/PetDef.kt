package com.timeoverlay.pet.pet

/**
 * Описание питомца: где лежит атлас, цвет акцента, какие кадры
 * соответствуют действиям и что он умеет делать сам.
 *
 * Все питомцы — атласы стандарта Codex-pet 8×9 (ячейка 192×208), ряды:
 * 0 idle, 1 run-right, 2 run-left, 3 waving, 4 jumping, 5 failed,
 * 6 waiting, 7 running, 8 review. Смысл кадров у авторов разный, поэтому
 * раскладка действий задаётся для каждого питомца отдельно.
 *
 * Idle намеренно медленный: основной кадр держится 2–3 секунды, моргание —
 * короткое. Живость даёт дыхание (масштаб) в [com.timeoverlay.pet.ui.PetSpriteView],
 * а не частая смена кадров.
 */
class PetDef(
    val id: String,
    val displayName: String,
    val assetDir: String,
    /** Цвет акцента (рамка плашки, подсветка выбранной карточки). */
    val accentColor: Int,
    /** Рисовать «Zzz» поверх спящего (если в кадрах их нет). */
    val drawZzz: Boolean,
    /** Самостоятельные действия, которые этому питомцу к лицу. */
    val moves: Set<PetMove>,
    private val clips: Map<PetAction, PetClip>,
    /** Характер: частота и длина прогулок, скорость, любимые действия. */
    val temper: Temper = Temper.NORMAL,
    /** Условие открытия; null — доступен сразу. */
    val unlock: Unlock? = null,
    /** Как персонаж стоит на сцене: масштаб, где у него ступни, ширина тени. */
    val stance: Stance = Stance()
) {
    /** Клип действия; если его нет — ближайший по смыслу, чтобы не показать явно неверное состояние. */
    fun clip(action: PetAction): PetClip {
        clips[action]?.let { return it }
        val fallback = when (action) {
            PetAction.RUN_RIGHT -> PetAction.WALK_RIGHT
            PetAction.RUN_LEFT -> PetAction.WALK_LEFT
            PetAction.CELEBRATE -> PetAction.JUMP
            PetAction.EXHAUSTED, PetAction.LIE, PetAction.ANNOYED -> PetAction.SAD
            PetAction.SLEEP -> PetAction.EXHAUSTED
            PetAction.REVIEW -> PetAction.WAVE
            else -> PetAction.IDLE
        }
        return clips[fallback] ?: clips.getValue(PetAction.IDLE)
    }

    fun has(action: PetAction): Boolean = clips.containsKey(action)

    val spritesheetPath: String get() = "pet/$assetDir/spritesheet.webp"

    /**
     * Характер питомца. Все множители относительно «обычного»:
     * [walkRate] — интервал между прогулками (меньше — чаще),
     * [speed] — скорость ходьбы/бега, [runChance] — доля бега в перемещениях,
     * [jumpChance] — шанс подпрыгнуть по пути, [restChance] — вместо прогулки
     * отдохнуть на месте, [sleepChance] — задремать во время отдыха,
     * [walkLength] — длина маршрута.
     */
    class Temper(
        val walkRate: Float,
        val speed: Float,
        val runChance: Float,
        val jumpChance: Float,
        val restChance: Float,
        val sleepChance: Float,
        val walkLength: Float
    ) {
        companion object {
            val ACTIVE = Temper(0.65f, 1.2f, 0.45f, 0.35f, 0.15f, 0.05f, 1.3f)
            val NORMAL = Temper(1f, 1f, 0.25f, 0.2f, 0.3f, 0.1f, 1f)
            val CALM = Temper(1.5f, 0.8f, 0.05f, 0.08f, 0.5f, 0.25f, 0.7f)
        }
    }

    /** Открывается за [minutes] продуктивных минут суммарно или за [days] разных дней с TimePet. */
    class Unlock(val minutes: Int, val days: Int)

    /**
     * Посадка на сцене: [scale] — множитель размера относительно общего,
     * [foot] — доля высоты ячейки, где у персонажа ступни (по idle-кадру),
     * [shadow] — ширина тени в долях ширины персонажа.
     */
    class Stance(val scale: Float = 1f, val foot: Float = 0.976f, val shadow: Float = 0.8f)

    companion object {
        private fun run(row: Int) = PetClip(
            row, intArrayOf(0, 1, 2, 3, 4, 5, 6, 7),
            longArrayOf(120, 120, 120, 120, 120, 120, 120, 220)
        )

        private fun wave(row: Int) = PetClip(
            row, intArrayOf(0, 1, 2, 3, 2, 1, 0),
            longArrayOf(160, 160, 160, 320, 160, 160, 220), loop = false
        )

        private fun jump(row: Int) = PetClip(
            row, intArrayOf(0, 1, 2, 3, 4), longArrayOf(150, 150, 150, 150, 320)
        )

        private fun celebrate(row: Int) = PetClip(
            row, intArrayOf(0, 1, 2, 3, 4, 0, 1, 2, 3, 4),
            longArrayOf(130, 130, 130, 130, 220, 130, 130, 130, 130, 360), loop = false
        )

        /**
         * Mimi — серый котёнок, автор Jerry (github.com/Spacebody), MIT.
         * idle: 2–3 полуприкрытые/закрытые глаза (моргание);
         * jumping: 4 довольный с лапой; failed: 0–1 грусть, 2–3 грусть
         * с закрытыми глазами, 4 лежит, 5 лежит и плачет, 6–7 грусть;
         * waiting: 2 довольные закрытые глаза, 4–5 смотрит по сторонам;
         * running: бег; review: 1 сердится, 2 лапа у подбородка, 3 довольный, 4 наклон головы.
         */
        val MIMI = PetDef(
            id = "mimi", displayName = "Mimi", assetDir = "mimi",
            accentColor = 0xFFE0A458.toInt(), drawZzz = true,
            moves = setOf(
                PetMove.WALK, PetMove.RUN, PetMove.JUMP, PetMove.SIT, PetMove.LIE,
                PetMove.LOOK_AROUND, PetMove.WAVE, PetMove.PEEK
            ),
            clips = mapOf(
                PetAction.IDLE to PetClip(
                    0, intArrayOf(0, 1, 2, 3, 2, 0, 4, 5),
                    longArrayOf(2600, 180, 110, 140, 110, 2200, 220, 220)
                ),
                PetAction.HAPPY to PetClip(
                    0, intArrayOf(0, 3, 4, 4, 0, 3, 3, 0),
                    longArrayOf(1800, 400, 1600, 1600, 600, 2200, 2200, 120),
                    rows = intArrayOf(0, 0, 4, 4, 0, 8, 8, 0), still = 2
                ),
                PetAction.WALK_RIGHT to run(1),
                PetAction.WALK_LEFT to run(2),
                PetAction.RUN_RIGHT to PetClip(7, intArrayOf(0, 1, 2, 3, 4, 5), longArrayOf(90, 90, 90, 90, 90, 90)),
                PetAction.RUN_LEFT to PetClip(7, intArrayOf(0, 1, 2, 3, 4, 5), longArrayOf(90, 90, 90, 90, 90, 90), mirror = true),
                PetAction.WAVE to wave(3),
                PetAction.JUMP to jump(4),
                PetAction.CELEBRATE to celebrate(4),
                PetAction.SAD to PetClip(
                    5, intArrayOf(0, 1, 1, 0, 6, 7, 7, 6),
                    longArrayOf(900, 1100, 1100, 900, 900, 1100, 1100, 900)
                ),
                PetAction.EXHAUSTED to PetClip(
                    5, intArrayOf(2, 3, 4, 5, 5, 4, 3, 2),
                    longArrayOf(800, 900, 1200, 1400, 1400, 1200, 900, 800)
                ),
                PetAction.SLEEP to PetClip(5, intArrayOf(4, 4), longArrayOf(3000, 3000)),
                PetAction.TIRED to PetClip(
                    0, intArrayOf(2, 3, 2, 0, 2, 3),
                    longArrayOf(1100, 900, 1100, 1600, 1100, 1300)
                ),
                PetAction.WORK to PetClip(7, intArrayOf(0, 1, 2, 3, 4, 5), longArrayOf(130, 130, 130, 130, 130, 240)),
                PetAction.REVIEW to PetClip(
                    8, intArrayOf(0, 4, 4, 2, 3, 0), longArrayOf(300, 500, 500, 400, 600, 300), loop = false
                ),
                PetAction.ANNOYED to PetClip(
                    8, intArrayOf(1, 1, 4, 1, 0), longArrayOf(900, 700, 500, 800, 300), loop = false
                ),
                PetAction.LOOK_AROUND to PetClip(
                    6, intArrayOf(0, 4, 4, 0, 5, 5, 1, 0),
                    longArrayOf(400, 900, 900, 500, 900, 900, 700, 400), loop = false
                ),
                PetAction.SIT to PetClip(
                    6, intArrayOf(3, 2, 2, 2, 2, 3), longArrayOf(500, 2000, 2000, 2000, 2000, 500), loop = false
                ),
                PetAction.LIE to PetClip(
                    5, intArrayOf(2, 4, 4, 4, 4, 2), longArrayOf(500, 2500, 2500, 2500, 2500, 500), loop = false
                )
            ),
            temper = Temper.ACTIVE,
            stance = Stance(scale = 1f, foot = 0.976f, shadow = 0.85f)
        )

        /**
         * Eigenblob (codex-pet.com, лицензия не указана — см. CREDITS.md).
         * idle: 2 сплющен с закрытыми глазами (моргание), 3 вытянут; waving:
         * 0 и 2 наклон влево/вправо; jumping: 0 присел, 1–2 вытянут;
         * failed: 0–2 грусть, 3–5 лежит с закрытыми глазами, 6–7 грусть;
         * waiting: 2 растёкся, 3 круглые глаза, 4 довольные закрытые глаза;
         * review: 1–2, 4 хмурится, 3 подмигивает.
         */
        val EIGENBLOB = PetDef(
            id = "eigenblob", displayName = "Eigenblob", assetDir = "eigenblob",
            accentColor = 0xFF4DA3FF.toInt(), drawZzz = true,
            moves = setOf(
                PetMove.SLIDE, PetMove.JUMP, PetMove.WOBBLE, PetMove.STRETCH, PetMove.SIT,
                PetMove.LOOK_AROUND, PetMove.WAVE, PetMove.PEEK
            ),
            clips = mapOf(
                PetAction.IDLE to PetClip(
                    0, intArrayOf(0, 1, 2, 3, 0, 4, 5),
                    longArrayOf(2600, 160, 120, 160, 2200, 220, 220)
                ),
                PetAction.HAPPY to PetClip(
                    0, intArrayOf(4, 4, 0, 1, 3, 0, 2, 0),
                    longArrayOf(1800, 1600, 600, 300, 400, 2000, 120, 800),
                    rows = intArrayOf(6, 6, 0, 4, 4, 0, 0, 0)
                ),
                // Слайд: наклон в сторону движения, а не ходьба.
                PetAction.WALK_RIGHT to PetClip(3, intArrayOf(2, 1), longArrayOf(260, 200)),
                PetAction.WALK_LEFT to PetClip(3, intArrayOf(0, 1), longArrayOf(260, 200)),
                PetAction.WAVE to PetClip(
                    3, intArrayOf(1, 3, 1, 3, 1), longArrayOf(200, 320, 200, 320, 240), loop = false
                ),
                PetAction.JUMP to jump(4),
                PetAction.CELEBRATE to celebrate(4),
                PetAction.SAD to PetClip(
                    5, intArrayOf(0, 1, 1, 0, 7, 6, 6, 7),
                    longArrayOf(900, 1100, 1100, 900, 900, 1100, 1100, 900)
                ),
                PetAction.EXHAUSTED to PetClip(
                    5, intArrayOf(2, 3, 4, 5, 5, 4, 3, 2),
                    longArrayOf(800, 900, 1200, 1400, 1400, 1200, 900, 800)
                ),
                PetAction.SLEEP to PetClip(5, intArrayOf(3, 4, 5, 4), longArrayOf(2200, 2200, 2200, 2200)),
                PetAction.TIRED to PetClip(
                    6, intArrayOf(0, 2, 2, 4, 4, 2, 0, 5),
                    longArrayOf(1000, 1200, 1200, 1400, 1400, 1200, 1000, 1400), still = 3
                ),
                PetAction.WORK to PetClip(7, intArrayOf(0, 1, 2, 3, 4, 5), longArrayOf(130, 130, 130, 130, 130, 240)),
                PetAction.REVIEW to PetClip(
                    8, intArrayOf(0, 3, 3, 4, 5, 0), longArrayOf(300, 500, 500, 400, 500, 300), loop = false
                ),
                PetAction.ANNOYED to PetClip(
                    8, intArrayOf(1, 2, 2, 1, 0), longArrayOf(800, 700, 700, 600, 300), loop = false
                ),
                PetAction.LOOK_AROUND to PetClip(
                    0, intArrayOf(0, 0, 2, 3, 0, 1, 0),
                    longArrayOf(300, 900, 900, 900, 400, 900, 300), loop = false,
                    rows = intArrayOf(3, 3, 3, 6, 0, 0, 0)
                ),
                PetAction.SIT to PetClip(
                    6, intArrayOf(0, 4, 4, 4, 4, 0), longArrayOf(500, 2000, 2000, 2000, 2000, 500), loop = false
                ),
                PetAction.LIE to PetClip(
                    6, intArrayOf(0, 2, 2, 2, 2, 0), longArrayOf(500, 2500, 2500, 2500, 2500, 500), loop = false
                ),
                PetAction.STRETCH to PetClip(
                    4, intArrayOf(0, 1, 2, 2, 3, 0, 0), longArrayOf(300, 500, 900, 900, 400, 200, 100),
                    loop = false, rows = intArrayOf(4, 4, 4, 4, 4, 0, 0)
                ),
                PetAction.WOBBLE to PetClip(
                    3, intArrayOf(0, 1, 2, 1, 0, 1, 2, 1), longArrayOf(220, 160, 220, 160, 220, 160, 220, 240),
                    loop = false
                )
            ),
            temper = Temper.CALM,
            stance = Stance(scale = 0.96f, foot = 0.976f, shadow = 0.9f)
        )

        /**
         * Panda — Jason Bai (github.com/Jason-Bai/pet), MIT.
         * idle: 2 моргание; failed: 0–1 грусть, 2–3 плачет, 4 лежит, 5 лежит грустный,
         * 6–7 грусть; waiting: 1 смотрит в сторону, 2 и 5 довольные закрытые глаза;
         * review: 1 довольный, 2 думает, 3 подмигивает, 4 смеётся.
         */
        val PANDA = PetDef(
            id = "panda", displayName = "Panda", assetDir = "panda",
            accentColor = 0xFF6FBF73.toInt(), drawZzz = true,
            moves = setOf(
                PetMove.WALK, PetMove.RUN, PetMove.JUMP, PetMove.SIT, PetMove.LIE,
                PetMove.LOOK_AROUND, PetMove.WAVE, PetMove.PEEK
            ),
            clips = mapOf(
                PetAction.IDLE to PetClip(
                    0, intArrayOf(0, 1, 2, 3, 0, 4, 5),
                    longArrayOf(2600, 160, 120, 160, 2200, 220, 220)
                ),
                PetAction.HAPPY to PetClip(
                    0, intArrayOf(1, 3, 0, 2, 3, 0, 2),
                    longArrayOf(1800, 1600, 600, 400, 400, 2000, 120),
                    rows = intArrayOf(8, 8, 0, 4, 4, 0, 0)
                ),
                PetAction.WALK_RIGHT to run(1),
                PetAction.WALK_LEFT to run(2),
                PetAction.RUN_RIGHT to PetClip(7, intArrayOf(0, 1, 2, 3, 4, 5), longArrayOf(90, 90, 90, 90, 90, 90)),
                PetAction.RUN_LEFT to PetClip(7, intArrayOf(0, 1, 2, 3, 4, 5), longArrayOf(90, 90, 90, 90, 90, 90), mirror = true),
                PetAction.WAVE to wave(3),
                PetAction.JUMP to jump(4),
                PetAction.CELEBRATE to celebrate(4),
                PetAction.SAD to PetClip(
                    5, intArrayOf(0, 1, 1, 0, 6, 7, 7, 6),
                    longArrayOf(900, 1100, 1100, 900, 900, 1100, 1100, 900)
                ),
                PetAction.EXHAUSTED to PetClip(
                    5, intArrayOf(2, 3, 4, 5, 5, 4, 3, 2),
                    longArrayOf(800, 900, 1200, 1400, 1400, 1200, 900, 800)
                ),
                PetAction.SLEEP to PetClip(5, intArrayOf(4, 4), longArrayOf(3000, 3000)),
                PetAction.TIRED to PetClip(
                    6, intArrayOf(0, 3, 3, 0, 2, 3),
                    longArrayOf(1200, 1400, 1400, 1000, 1200, 1500),
                    rows = intArrayOf(6, 5, 5, 6, 6, 5), still = 1
                ),
                PetAction.WORK to PetClip(7, intArrayOf(0, 1, 2, 3, 4, 5), longArrayOf(130, 130, 130, 130, 130, 240)),
                PetAction.REVIEW to PetClip(
                    8, intArrayOf(0, 2, 2, 3, 0), longArrayOf(300, 600, 600, 500, 300), loop = false
                ),
                PetAction.ANNOYED to PetClip(
                    5, intArrayOf(0, 0, 2, 0), longArrayOf(900, 700, 900, 300), loop = false,
                    rows = intArrayOf(5, 5, 8, 0)
                ),
                PetAction.LOOK_AROUND to PetClip(
                    6, intArrayOf(0, 1, 1, 0, 3, 4, 0),
                    longArrayOf(400, 900, 900, 500, 900, 900, 400), loop = false
                ),
                PetAction.SIT to PetClip(
                    6, intArrayOf(3, 2, 2, 2, 2, 3), longArrayOf(500, 2000, 2000, 2000, 2000, 500), loop = false
                ),
                PetAction.LIE to PetClip(
                    5, intArrayOf(4, 4, 4, 4), longArrayOf(2500, 2500, 2500, 2500), loop = false
                )
            ),
            temper = Temper(1.3f, 0.85f, 0.1f, 0.1f, 0.45f, 0.35f, 0.8f),
            stance = Stance(scale = 1f, foot = 0.976f, shadow = 0.7f)
        )

        /**
         * Frankie — такса, Aygun Varol (github.com/AygunVarol/Codex-Pet-Frankie), MIT.
         * idle: 2 моргание; failed: 0–1 уши вниз, 2–4 плачет, 5–7 лежит грустный;
         * waiting: 2 язык наружу; review: 2 смотрит вниз, 4 довольные закрытые глаза.
         */
        val FRANKIE = PetDef(
            id = "frankie", displayName = "Frankie", assetDir = "frankie",
            accentColor = 0xFFC8813A.toInt(), drawZzz = true,
            moves = setOf(
                PetMove.WALK, PetMove.RUN, PetMove.JUMP, PetMove.SIT, PetMove.LIE,
                PetMove.LOOK_AROUND, PetMove.WAVE, PetMove.PEEK
            ),
            clips = mapOf(
                PetAction.IDLE to PetClip(
                    0, intArrayOf(0, 1, 2, 3, 0, 4, 5),
                    longArrayOf(2600, 160, 120, 160, 2200, 220, 220)
                ),
                PetAction.HAPPY to PetClip(
                    0, intArrayOf(2, 0, 1, 3, 0, 4, 2),
                    longArrayOf(1800, 500, 350, 350, 1800, 1600, 120),
                    rows = intArrayOf(6, 0, 4, 4, 0, 8, 0)
                ),
                PetAction.WALK_RIGHT to run(1),
                PetAction.WALK_LEFT to run(2),
                PetAction.RUN_RIGHT to PetClip(7, intArrayOf(0, 1, 2, 3, 4, 5), longArrayOf(90, 90, 90, 90, 90, 90)),
                PetAction.RUN_LEFT to PetClip(7, intArrayOf(0, 1, 2, 3, 4, 5), longArrayOf(90, 90, 90, 90, 90, 90), mirror = true),
                PetAction.WAVE to wave(3),
                PetAction.JUMP to jump(4),
                PetAction.CELEBRATE to celebrate(4),
                PetAction.SAD to PetClip(
                    5, intArrayOf(0, 1, 1, 0, 3, 3, 0, 1),
                    longArrayOf(900, 1100, 1100, 900, 900, 1100, 1100, 900)
                ),
                PetAction.EXHAUSTED to PetClip(
                    5, intArrayOf(5, 6, 7, 6, 6, 7, 6, 5),
                    longArrayOf(800, 900, 1200, 1400, 1400, 1200, 900, 800)
                ),
                PetAction.SLEEP to PetClip(5, intArrayOf(6, 6), longArrayOf(3000, 3000)),
                PetAction.TIRED to PetClip(
                    8, intArrayOf(2, 0, 2, 2, 2, 0),
                    longArrayOf(1400, 900, 1200, 1400, 1400, 1000),
                    rows = intArrayOf(8, 0, 0, 8, 8, 0)
                ),
                PetAction.WORK to PetClip(7, intArrayOf(0, 1, 2, 3, 4, 5), longArrayOf(130, 130, 130, 130, 130, 240)),
                PetAction.REVIEW to PetClip(
                    8, intArrayOf(0, 2, 2, 4, 0), longArrayOf(300, 600, 600, 500, 300), loop = false
                ),
                PetAction.ANNOYED to PetClip(
                    5, intArrayOf(0, 0, 2, 0), longArrayOf(900, 700, 900, 300), loop = false,
                    rows = intArrayOf(5, 5, 8, 0)
                ),
                PetAction.LOOK_AROUND to PetClip(
                    8, intArrayOf(0, 2, 2, 0, 1, 1, 0),
                    longArrayOf(400, 900, 900, 500, 900, 900, 400), loop = false
                ),
                PetAction.SIT to PetClip(
                    8, intArrayOf(0, 4, 4, 4, 4, 0), longArrayOf(500, 2000, 2000, 2000, 2000, 500), loop = false
                ),
                PetAction.LIE to PetClip(
                    5, intArrayOf(6, 6, 6, 6), longArrayOf(2500, 2500, 2500, 2500), loop = false
                )
            ),
            temper = Temper(0.75f, 1.15f, 0.5f, 0.2f, 0.2f, 0.15f, 1.4f),
            unlock = Unlock(180, 5),
            // Такса: низкая и широкая, ступни выше низа ячейки.
            stance = Stance(scale = 1.05f, foot = 0.837f, shadow = 0.95f)
        )

        /**
         * Wally — белый талисман-капля, Wally Pet Contributors (github.com/wally025/wally-codex-pet), MIT.
         * idle: 3 довольные закрытые глаза; failed: 0–1 грусть, 2 закрытые глаза, 3 голова
         * опущена, 5 поник, 6–7 грусть; waiting: 3 довольный; review: 0 хмурится, 1 думает,
         * 2 смотрит в сторону, 3 довольный.
         */
        val WALLY = PetDef(
            id = "wally", displayName = "Wally", assetDir = "wally",
            accentColor = 0xFF9B8CFF.toInt(), drawZzz = true,
            moves = setOf(
                PetMove.WALK, PetMove.RUN, PetMove.JUMP, PetMove.SIT, PetMove.STRETCH,
                PetMove.LOOK_AROUND, PetMove.WAVE, PetMove.PEEK
            ),
            clips = mapOf(
                PetAction.IDLE to PetClip(
                    0, intArrayOf(2, 5, 3, 5, 2, 0),
                    longArrayOf(2600, 300, 140, 300, 2000, 1200)
                ),
                PetAction.HAPPY to PetClip(
                    0, intArrayOf(3, 2, 1, 2, 2, 3, 3),
                    longArrayOf(1800, 500, 350, 350, 1800, 1600, 200),
                    rows = intArrayOf(6, 0, 4, 4, 0, 8, 0)
                ),
                PetAction.WALK_RIGHT to run(1),
                PetAction.WALK_LEFT to run(2),
                PetAction.RUN_RIGHT to PetClip(7, intArrayOf(0, 1, 2, 3, 4, 5), longArrayOf(90, 90, 90, 90, 90, 90)),
                PetAction.RUN_LEFT to PetClip(7, intArrayOf(0, 1, 2, 3, 4, 5), longArrayOf(90, 90, 90, 90, 90, 90), mirror = true),
                PetAction.WAVE to wave(3),
                PetAction.JUMP to jump(4),
                PetAction.CELEBRATE to celebrate(4),
                PetAction.SAD to PetClip(
                    5, intArrayOf(0, 1, 1, 0, 6, 7, 7, 6),
                    longArrayOf(900, 1100, 1100, 900, 900, 1100, 1100, 900)
                ),
                PetAction.EXHAUSTED to PetClip(
                    5, intArrayOf(2, 3, 5, 5, 3, 2),
                    longArrayOf(900, 1000, 1400, 1400, 1000, 900)
                ),
                PetAction.SLEEP to PetClip(5, intArrayOf(5, 5), longArrayOf(3000, 3000)),
                PetAction.TIRED to PetClip(
                    0, intArrayOf(2, 2, 2, 2, 3, 3),
                    longArrayOf(1200, 1400, 1400, 1000, 1200, 1500),
                    rows = intArrayOf(0, 5, 5, 0, 5, 5), still = 1
                ),
                PetAction.WORK to PetClip(7, intArrayOf(0, 1, 2, 3, 4, 5), longArrayOf(130, 130, 130, 130, 130, 240)),
                PetAction.REVIEW to PetClip(
                    8, intArrayOf(1, 1, 2, 3, 5), longArrayOf(500, 500, 500, 600, 300), loop = false
                ),
                PetAction.ANNOYED to PetClip(
                    8, intArrayOf(0, 0, 2, 0, 5), longArrayOf(900, 700, 500, 800, 300), loop = false
                ),
                PetAction.LOOK_AROUND to PetClip(
                    8, intArrayOf(5, 2, 2, 5, 1, 5),
                    longArrayOf(400, 900, 900, 500, 900, 400), loop = false
                ),
                PetAction.SIT to PetClip(
                    6, intArrayOf(0, 3, 3, 3, 3, 0), longArrayOf(500, 2000, 2000, 2000, 2000, 500), loop = false
                ),
                PetAction.STRETCH to PetClip(
                    4, intArrayOf(0, 1, 1, 2, 4), longArrayOf(300, 700, 700, 500, 300), loop = false
                )
            ),
            temper = Temper(0.9f, 1f, 0.2f, 0.4f, 0.3f, 0.1f, 1f),
            unlock = Unlock(360, 10),
            stance = Stance(scale = 0.98f, foot = 0.976f, shadow = 0.75f)
        )

        /**
         * Claude — оранжевый кубик, XiangWang (github.com/xiangking/Claude-style-Codex-pet), MIT.
         * idle: 3 закрытые глаза (моргание); waving: 1–2 рука поднята; jumping: 0–4;
         * failed: 0–3 плачет, 4 лежит плашмя, 5 плачет с пыхом, 6–7 плачет; waiting: 1 и 5
         * прищур, 3 наклон; running: 0–5; review: 1 и 5 прищур, 2 и 4 наклон головы.
         */
        val CLAUDE = PetDef(
            id = "claude", displayName = "Claude", assetDir = "claude",
            accentColor = 0xFFF2853A.toInt(), drawZzz = true,
            moves = setOf(
                PetMove.WALK, PetMove.RUN, PetMove.JUMP, PetMove.SIT, PetMove.LIE,
                PetMove.LOOK_AROUND, PetMove.WAVE, PetMove.WOBBLE, PetMove.PEEK
            ),
            clips = mapOf(
                PetAction.IDLE to PetClip(
                    0, intArrayOf(0, 1, 3, 2, 0, 4, 5),
                    longArrayOf(2600, 200, 120, 200, 2200, 220, 220)
                ),
                PetAction.HAPPY to PetClip(
                    0, intArrayOf(3, 3, 0, 1, 2, 0, 1, 0),
                    longArrayOf(1800, 1600, 600, 300, 400, 2000, 300, 800),
                    rows = intArrayOf(8, 8, 0, 4, 4, 0, 0, 0)
                ),
                PetAction.WALK_RIGHT to run(1),
                PetAction.WALK_LEFT to run(2),
                PetAction.RUN_RIGHT to PetClip(7, intArrayOf(0, 1, 2, 3, 4, 5), longArrayOf(90, 90, 90, 90, 90, 90)),
                PetAction.RUN_LEFT to PetClip(7, intArrayOf(0, 1, 2, 3, 4, 5), longArrayOf(90, 90, 90, 90, 90, 90), mirror = true),
                PetAction.WAVE to wave(3),
                PetAction.JUMP to jump(4),
                PetAction.CELEBRATE to celebrate(4),
                PetAction.SAD to PetClip(
                    5, intArrayOf(0, 1, 1, 0, 6, 7, 7, 6),
                    longArrayOf(900, 1100, 1100, 900, 900, 1100, 1100, 900)
                ),
                PetAction.EXHAUSTED to PetClip(
                    5, intArrayOf(2, 3, 4, 5, 5, 4, 3, 2),
                    longArrayOf(800, 900, 1200, 1400, 1400, 1200, 900, 800)
                ),
                PetAction.SLEEP to PetClip(5, intArrayOf(4, 4), longArrayOf(3000, 3000)),
                PetAction.TIRED to PetClip(
                    6, intArrayOf(1, 0, 1, 1, 5, 0),
                    longArrayOf(1200, 900, 1400, 1400, 1200, 1000), still = 0
                ),
                PetAction.WORK to PetClip(7, intArrayOf(0, 1, 2, 3, 4, 5), longArrayOf(130, 130, 130, 130, 130, 240)),
                PetAction.REVIEW to PetClip(
                    8, intArrayOf(0, 2, 2, 4, 4, 0), longArrayOf(300, 600, 600, 600, 500, 300), loop = false
                ),
                PetAction.ANNOYED to PetClip(
                    8, intArrayOf(1, 1, 5, 1, 0), longArrayOf(900, 700, 500, 800, 300), loop = false
                ),
                PetAction.LOOK_AROUND to PetClip(
                    6, intArrayOf(0, 3, 3, 0, 2, 4, 0),
                    longArrayOf(400, 900, 900, 500, 900, 900, 400), loop = false
                ),
                PetAction.SIT to PetClip(
                    6, intArrayOf(0, 5, 5, 5, 5, 0), longArrayOf(500, 2000, 2000, 2000, 2000, 500), loop = false
                ),
                PetAction.LIE to PetClip(
                    5, intArrayOf(3, 4, 4, 4, 4, 3), longArrayOf(500, 2500, 2500, 2500, 2500, 500), loop = false
                ),
                PetAction.WOBBLE to PetClip(
                    8, intArrayOf(0, 2, 0, 4, 0, 2, 0), longArrayOf(200, 260, 200, 260, 200, 260, 240), loop = false
                )
            ),
            temper = Temper(0.9f, 0.95f, 0.3f, 0.45f, 0.25f, 0.1f, 1f),
            unlock = Unlock(600, 15),
            // Кубик: ступни на 0.894 высоты ячейки, сам ниже остальных.
            stance = Stance(scale = 1.04f, foot = 0.894f, shadow = 0.9f)
        )

        /**
         * Frieren — эльфийка-маг, legeling (awesome-codex-pet), CC BY-NC 4.0, фан-арт.
         * idle: 2 и 4 закрытые глаза; waving: 2 рука поднята; jumping: 0–4;
         * failed: 0–1 грусть, 2 закрытые глаза, 3–4 поклон/сидит низко, 5 глаза закрыты,
         * 6–7 грусть; waiting: 1 и 4 смотрит в сторону, 3 закрытые глаза;
         * running: 0–5 бег с посохом; review: 1 и 4 наклон головы, 3 закрытые глаза.
         */
        val FRIEREN = PetDef(
            id = "frieren", displayName = "Frieren", assetDir = "frieren",
            accentColor = 0xFFB89BD9.toInt(), drawZzz = true,
            moves = setOf(
                PetMove.WALK, PetMove.RUN, PetMove.JUMP, PetMove.SIT, PetMove.LIE,
                PetMove.LOOK_AROUND, PetMove.WAVE, PetMove.PEEK
            ),
            clips = mapOf(
                PetAction.IDLE to PetClip(
                    0, intArrayOf(0, 1, 2, 3, 0, 4, 5),
                    longArrayOf(2600, 200, 140, 200, 2200, 260, 260)
                ),
                PetAction.HAPPY to PetClip(
                    0, intArrayOf(0, 3, 1, 2, 3, 0, 2),
                    longArrayOf(1800, 1600, 400, 400, 400, 2000, 300),
                    rows = intArrayOf(8, 8, 4, 4, 4, 0, 8), still = 1
                ),
                PetAction.WALK_RIGHT to run(1),
                PetAction.WALK_LEFT to run(2),
                PetAction.RUN_RIGHT to PetClip(7, intArrayOf(0, 1, 2, 3, 4, 5), longArrayOf(95, 95, 95, 95, 95, 95)),
                PetAction.RUN_LEFT to PetClip(7, intArrayOf(0, 1, 2, 3, 4, 5), longArrayOf(95, 95, 95, 95, 95, 95), mirror = true),
                PetAction.WAVE to wave(3),
                PetAction.JUMP to jump(4),
                PetAction.CELEBRATE to celebrate(4),
                PetAction.SAD to PetClip(
                    5, intArrayOf(0, 1, 1, 0, 6, 7, 7, 6),
                    longArrayOf(900, 1100, 1100, 900, 900, 1100, 1100, 900)
                ),
                PetAction.EXHAUSTED to PetClip(
                    5, intArrayOf(2, 3, 4, 4, 3, 2),
                    longArrayOf(900, 1000, 1400, 1400, 1000, 900)
                ),
                PetAction.SLEEP to PetClip(5, intArrayOf(4, 4), longArrayOf(3000, 3000)),
                PetAction.TIRED to PetClip(
                    6, intArrayOf(0, 3, 3, 0, 1, 3),
                    longArrayOf(1200, 1400, 1400, 1000, 1200, 1500), still = 1
                ),
                PetAction.WORK to PetClip(7, intArrayOf(0, 1, 2, 3, 4, 5), longArrayOf(130, 130, 130, 130, 130, 240)),
                PetAction.REVIEW to PetClip(
                    8, intArrayOf(0, 1, 1, 4, 3, 0), longArrayOf(300, 600, 600, 600, 500, 300), loop = false
                ),
                PetAction.ANNOYED to PetClip(
                    5, intArrayOf(0, 0, 3, 0), longArrayOf(900, 700, 900, 300), loop = false,
                    rows = intArrayOf(5, 5, 8, 0)
                ),
                PetAction.LOOK_AROUND to PetClip(
                    6, intArrayOf(0, 1, 1, 0, 4, 4, 0),
                    longArrayOf(400, 900, 900, 500, 900, 900, 400), loop = false
                ),
                PetAction.SIT to PetClip(
                    5, intArrayOf(3, 3, 3, 3, 3, 0), longArrayOf(500, 2000, 2000, 2000, 2000, 400), loop = false,
                    rows = intArrayOf(5, 5, 5, 5, 5, 0)
                ),
                PetAction.LIE to PetClip(
                    5, intArrayOf(3, 4, 4, 4, 4, 3), longArrayOf(500, 2500, 2500, 2500, 2500, 500), loop = false
                )
            ),
            temper = Temper(1.4f, 0.8f, 0.1f, 0.05f, 0.5f, 0.3f, 0.75f),
            unlock = Unlock(900, 20),
            stance = Stance(scale = 1.02f, foot = 0.976f, shadow = 0.6f)
        )

        val ALL: List<PetDef> = listOf(MIMI, EIGENBLOB, PANDA, FRANKIE, WALLY, CLAUDE, FRIEREN)

        fun byId(id: String?): PetDef = ALL.firstOrNull { it.id == id } ?: MIMI
    }
}
