package com.timeoverlay.pet.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import com.timeoverlay.pet.R

/**
 * Одна полоска, поделённая на три сегмента: продуктивность / лень / нейтральные.
 * Пустые данные — серая дорожка.
 */
class SplitBarView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private var parts = floatArrayOf(0f, 0f, 0f)
    private val paints = intArrayOf(R.color.productive, R.color.lazy, R.color.neutral).map {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ContextCompat.getColor(context, it) }
    }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = context.themeColor(R.attr.tp_track)
    }
    private val rect = RectF()

    fun setValues(productive: Long, lazy: Long, neutral: Long) {
        val total = (productive + lazy + neutral).toFloat()
        parts = if (total <= 0f) floatArrayOf(0f, 0f, 0f)
        else floatArrayOf(productive / total, lazy / total, neutral / total)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val r = height / 2f
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        canvas.drawRoundRect(rect, r, r, track)
        val gap = 2f * resources.displayMetrics.density
        var x = 0f
        for (i in parts.indices) {
            val w = width * parts[i]
            if (w <= 0f) continue
            rect.set(x, 0f, (x + w - gap).coerceAtLeast(x + 1f), height.toFloat())
            canvas.drawRoundRect(rect, r, r, paints[i])
            x += w
        }
    }
}
