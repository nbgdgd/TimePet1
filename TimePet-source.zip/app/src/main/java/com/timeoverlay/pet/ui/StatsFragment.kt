package com.timeoverlay.pet.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.tabs.TabLayout
import com.timeoverlay.pet.R
import com.timeoverlay.pet.data.AppCategoryStore
import com.timeoverlay.pet.data.PermissionHelper
import com.timeoverlay.pet.data.PerksStore
import com.timeoverlay.pet.data.TimeFormat
import com.timeoverlay.pet.data.UsageRepository
import com.timeoverlay.pet.mood.DayMood
import com.timeoverlay.pet.mood.MoodEngine
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Аналитика за день / неделю / месяц: общее время, распределение по
 * категориям, график (по часам за день, по дням за период), список
 * приложений по убыванию времени.
 */
class StatsFragment : Fragment(), AppDetailDialog.Listener {

    private enum class Period(val days: Int) { TODAY(1), WEEK(7), MONTH(30) }

    private var period = Period.TODAY
    private val io = Executors.newSingleThreadExecutor()
    private var requested = 0
    private lateinit var adapter: AppUsageAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_stats, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        adapter = AppUsageAdapter(AppCategoryStore(requireContext())) { app ->
            AppDetailDialog.new(app, period.days).show(childFragmentManager, "detail")
        }
        val list: RecyclerView = view.findViewById(R.id.list)
        list.layoutManager = LinearLayoutManager(requireContext())
        list.adapter = adapter

        val tabs: TabLayout = view.findViewById(R.id.periodTabs)
        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                period = when (tab.position) {
                    1 -> Period.WEEK
                    2 -> Period.MONTH
                    else -> Period.TODAY
                }
                reload()
            }
            override fun onTabUnselected(tab: TabLayout.Tab) = Unit
            override fun onTabReselected(tab: TabLayout.Tab) = Unit
        })
        view.findViewById<MaterialButton>(R.id.permissionButton).setOnClickListener {
            startActivity(PermissionHelper.usageAccessIntent())
        }
        MoodRows.labels(view)
        legend(view.findViewById(R.id.legLazy), R.string.cat_lazy, R.drawable.dot_lazy)
        legend(view.findViewById(R.id.legNeut), R.string.cat_neutral, R.drawable.dot_neutral)
        legend(view.findViewById(R.id.legProd), R.string.cat_productive, R.drawable.dot_productive)
    }

    private fun legend(row: View, name: Int, dot: Int) {
        row.findViewById<TextView>(R.id.splitName).setText(name)
        row.findViewById<View>(R.id.splitDot).setBackgroundResource(dot)
    }

    private fun legendValue(row: View, ms: Long, denom: Long) {
        row.findViewById<TextView>(R.id.splitPercent).text = "${ms * 100 / denom.coerceAtLeast(1L)}%"
        row.findViewById<TextView>(R.id.splitTime).text = TimeFormat.long(requireContext(), ms)
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }

    override fun onCategoryChanged() = reload()

    private fun dayLabel(dayStartMs: Long, days: Int): String {
        val fmt = if (days > 10) SimpleDateFormat("d.MM", Locale.getDefault())
        else SimpleDateFormat("EE", Locale.getDefault())
        return fmt.format(Date(dayStartMs)).trimEnd('.')
    }

    private fun reload() {
        val v = view ?: return
        if (!PermissionHelper.hasUsageAccess(requireContext())) {
            v.findViewById<View>(R.id.permissionState).visibility = View.VISIBLE
            v.findViewById<View>(R.id.emptyState).visibility = View.GONE
            v.findViewById<RecyclerView>(R.id.list).visibility = View.GONE
            v.findViewById<TextView>(R.id.totalValue).text = TimeFormat.long(requireContext(), 0)
            v.findViewById<View>(R.id.chartCard).visibility = View.GONE
            v.findViewById<View>(R.id.moodBlock).visibility = View.GONE
            return
        }
        v.findViewById<View>(R.id.permissionState).visibility = View.GONE

        val myRequest = ++requested
        val days = period.days
        io.execute {
            val ctx = requireContext().applicationContext
            val repo = UsageRepository(ctx)
            val store = AppCategoryStore(ctx)
            val now = System.currentTimeMillis()
            val begin = UsageRepository.startOfDay(UsageRepository.shiftDays(now, -(days - 1)))
            val snap = repo.queryRange(begin, now)
            val series: List<Long>
            val labels: List<String>
            if (days == 1) {
                series = repo.hourlyToday(now).toList()
                labels = (0 until 24).map { if (it % 6 == 0) String.format(Locale.US, "%02d", it) else "" }
            } else {
                val daily = repo.queryDailySeries(days, now)
                series = daily.map { it.totalMillis }
                labels = daily.map { dayLabel(it.dayStartMs, days) }
            }
            val totals = DayMood.totals(snap.apps.associate { it.packageName to it.millis }, store)
            val score = MoodEngine.productivityScore(
                totals.productiveMs, totals.lazyMs, totals.neutralMs, store.funAllowanceMinutes
            )
            val moodResult = if (days == 1) DayMood.compute(totals.copy(totalMs = snap.totalMillis), store, now, PerksStore(ctx)) else null
            activity?.runOnUiThread {
                if (!isAdded || myRequest != requested) return@runOnUiThread
                v.findViewById<TextView>(R.id.totalValue).text = TimeFormat.long(requireContext(), snap.totalMillis)
                v.findViewById<TextView>(R.id.totalLabel).setText(
                    when (days) {
                        1 -> R.string.period_label_today
                        7 -> R.string.period_label_week
                        else -> R.string.period_label_month
                    }
                )
                v.findViewById<TextView>(R.id.scoreLine).text =
                    if (score < 0) getString(R.string.stats_empty)
                    else getString(R.string.productivity_score_value, score)
                val moodBlock = v.findViewById<View>(R.id.moodBlock)
                if (moodResult != null) {
                    moodBlock.visibility = View.VISIBLE
                    MoodRows.bind(v, moodResult, moodResult.state, score, totals, store.funAllowanceMinutes)
                } else moodBlock.visibility = View.GONE
                v.findViewById<View>(R.id.chartCard).visibility = View.VISIBLE
                v.findViewById<TextView>(R.id.chartTitle).setText(if (days == 1) R.string.stats_by_hour else R.string.stats_by_day)
                v.findViewById<DayBarView>(R.id.dayChart).setValues(series, labels, highlightLast = days > 1)

                v.findViewById<SplitBarView>(R.id.splitBar)
                    .setValues(totals.productiveMs, totals.lazyMs, totals.neutralMs)
                val denom = totals.productiveMs + totals.lazyMs + totals.neutralMs
                legendValue(v.findViewById(R.id.legLazy), totals.lazyMs, denom)
                legendValue(v.findViewById(R.id.legNeut), totals.neutralMs, denom)
                legendValue(v.findViewById(R.id.legProd), totals.productiveMs, denom)

                val empty = snap.apps.isEmpty()
                v.findViewById<View>(R.id.emptyState).visibility = if (empty) View.VISIBLE else View.GONE
                v.findViewById<RecyclerView>(R.id.list).visibility = if (empty) View.GONE else View.VISIBLE
                adapter.submit(snap.apps)
            }
        }
    }
}
