package com.timeoverlay.pet.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import com.timeoverlay.pet.R

/**
 * Столбчатый график по дням без сторонних библиотек.
 * Подписи под столбцами необязательны (для месяца — только каждая 5-я).
 */
class DayBarView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private var values: List<Float> = emptyList()
    private var labels: List<String> = emptyList()
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = context.themeColor(R.attr.tp_seed)
    }
    private val todayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.productive)
    }
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = context.themeColor(R.attr.tp_track)
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = context.themeColor(R.attr.tp_text_muted)
        textAlign = Paint.Align.CENTER
        textSize = 11f * resources.displayMetrics.scaledDensity
    }
    private val rect = RectF()

    private var highlightLast = true

    /** [highlightLast] — последний столбец (сегодня) в цвете продуктивности. */
    fun setValues(millis: List<Long>, labels: List<String> = emptyList(), highlightLast: Boolean = true) {
        val max = millis.maxOrNull()?.coerceAtLeast(1L) ?: 1L
        values = millis.map { it / max.toFloat() }
        this.highlightLast = highlightLast
        this.labels = if (labels.size == millis.size) labels else emptyList()
        contentDescription = context.getString(
            if (millis.all { it == 0L }) R.string.chart_empty_desc else R.string.chart_desc
        )
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (values.isEmpty()) return
        val n = values.size
        val d = resources.displayMetrics.density
        val labelH = if (labels.isEmpty()) 0f else 16f * d
        val chartH = height - labelH
        val gap = (if (n > 10) 2.5f else 8f) * d
        val barW = (width - gap * (n - 1)) / n
        val radius = minOf(6f * d, barW / 2f)
        // Много столбцов (часы): вместо дорожек — тонкая линия основания.
        if (n >= 20) {
            rect.set(0f, chartH - 2f * d, width.toFloat(), chartH)
            canvas.drawRoundRect(rect, d, d, trackPaint)
        }
        for (i in values.indices) {
            val left = i * (barW + gap)
            if (n < 20) {
                rect.set(left, 0f, left + barW, chartH)
                canvas.drawRoundRect(rect, radius, radius, trackPaint)
            }
            val top = chartH * (1f - values[i].coerceIn(0f, 1f))
            if (values[i] > 0f) {
                rect.set(left, top, left + barW, chartH)
                canvas.drawRoundRect(rect, radius, radius, if (highlightLast && i == n - 1) todayPaint else barPaint)
            }
            if (labels.isNotEmpty() && labels[i].isNotEmpty() && (n <= 10 || n == 24 || i % 5 == 0 || i == n - 1)) {
                canvas.drawText(labels[i], left + barW / 2f, height - 3f * d, textPaint)
            }
        }
    }
}
