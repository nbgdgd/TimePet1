package com.timeoverlay.pet.pet

import com.timeoverlay.pet.R

/** Строки лицензии и описания характера для карточки питомца (подробности — CREDITS.md). */
object PetCredits {
    fun licenseRes(def: PetDef): Int = when (def.id) {
        PetDef.EIGENBLOB.id -> R.string.pet_license_eigenblob
        PetDef.PANDA.id -> R.string.pet_license_panda
        PetDef.FRANKIE.id -> R.string.pet_license_frankie
        PetDef.WALLY.id -> R.string.pet_license_wally
        PetDef.CLAUDE.id -> R.string.pet_license_claude
        PetDef.FRIEREN.id -> R.string.pet_license_frieren
        else -> R.string.pet_license_mimi
    }

    /** Короткое описание характера и поведения. */
    fun descRes(def: PetDef): Int = when (def.id) {
        PetDef.EIGENBLOB.id -> R.string.pet_desc_eigenblob
        PetDef.PANDA.id -> R.string.pet_desc_panda
        PetDef.FRANKIE.id -> R.string.pet_desc_frankie
        PetDef.WALLY.id -> R.string.pet_desc_wally
        PetDef.CLAUDE.id -> R.string.pet_desc_claude
        PetDef.FRIEREN.id -> R.string.pet_desc_frieren
        else -> R.string.pet_desc_mimi
    }
}
