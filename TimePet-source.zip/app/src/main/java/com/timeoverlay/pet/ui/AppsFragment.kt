package com.timeoverlay.pet.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.tabs.TabLayout
import com.google.android.material.textfield.TextInputEditText
import com.timeoverlay.pet.R
import com.timeoverlay.pet.data.AppCategoryStore
import com.timeoverlay.pet.data.Category
import com.timeoverlay.pet.data.PermissionHelper
import com.timeoverlay.pet.data.UsageRepository
import java.util.concurrent.Executors

/**
 * Экран приложений: все запускаемые (сначала используемые за сегодня),
 * фильтр по категории, поиск, смена категории через диалог подробностей.
 */
class AppsFragment : Fragment(), AppDetailDialog.Listener {

    private val io = Executors.newSingleThreadExecutor()
    private var requested = 0
    private lateinit var adapter: AppUsageAdapter
    private var all: List<UsageRepository.AppUsage> = emptyList()
    private var query = ""
    private var filter: Category? = null
    private lateinit var store: AppCategoryStore

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_apps, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        store = AppCategoryStore(requireContext())
        adapter = AppUsageAdapter(store) { app ->
            AppDetailDialog.new(app, 1).show(childFragmentManager, "detail")
        }
        val tabs: TabLayout = view.findViewById(R.id.filterTabs)
        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                filter = when (tab.position) {
                    1 -> Category.LAZY
                    2 -> Category.NEUTRAL
                    3 -> Category.PRODUCTIVE
                    else -> null
                }
                applyFilter()
            }
            override fun onTabUnselected(tab: TabLayout.Tab) = Unit
            override fun onTabReselected(tab: TabLayout.Tab) = Unit
        })
        val searchBox = view.findViewById<View>(R.id.searchBox)
        val search = view.findViewById<TextInputEditText>(R.id.search)
        view.findViewById<View>(R.id.searchButton).setOnClickListener {
            val show = searchBox.visibility != View.VISIBLE
            searchBox.visibility = if (show) View.VISIBLE else View.GONE
            if (show) search.requestFocus() else { search.setText(""); query = ""; applyFilter() }
        }
        val list: RecyclerView = view.findViewById(R.id.list)
        list.layoutManager = LinearLayoutManager(requireContext())
        list.adapter = adapter
        view.findViewById<MaterialButton>(R.id.permissionButton).setOnClickListener {
            startActivity(PermissionHelper.usageAccessIntent())
        }
        view.findViewById<TextInputEditText>(R.id.search)
            .addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(
                    s: CharSequence?, a: Int, b: Int, c: Int
                ) = Unit

                override fun onTextChanged(
                    s: CharSequence?, a: Int, b: Int, c: Int
                ) = Unit

                override fun afterTextChanged(s: Editable?) {
                    query = s?.toString()?.trim().orEmpty()
                    applyFilter()
                }
            })
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }

    override fun onCategoryChanged() {
        // Категория поменялась в диалоге — перечитать подписи и фильтр.
        adapter.notifyDataSetChanged()
        applyFilter()
    }

    private fun reload() {
        val v = view ?: return
        if (!PermissionHelper.hasUsageAccess(requireContext())) {
            v.findViewById<View>(R.id.permissionState).visibility = View.VISIBLE
            v.findViewById<View>(R.id.emptyState).visibility = View.GONE
            return
        }
        v.findViewById<View>(R.id.permissionState).visibility = View.GONE
        val myRequest = ++requested
        io.execute {
            val ctx = requireContext().applicationContext
            val pm = ctx.packageManager
            val repo = UsageRepository(ctx)
            val now = System.currentTimeMillis()
            // Время за сегодня (как в заголовке списка); неиспользованные — с нулём.
            val snap = repo.queryToday(now)
            val usedMs = snap.apps.associate { it.packageName to it.millis }
            // Все запускаемые приложения — даже те, что не использовались.
            val launchIntent = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
            val resolved = pm.queryIntentActivities(launchIntent, 0)
            val seen = HashSet<String>()
            val merged = ArrayList<UsageRepository.AppUsage>()
            for (a in snap.apps) {
                seen.add(a.packageName)
                merged.add(a)
            }
            for (r in resolved) {
                val pkg = r.activityInfo.packageName
                if (!seen.add(pkg) || pkg == ctx.packageName) continue
                val info = runCatching { pm.getApplicationInfo(pkg, 0) }.getOrNull()
                    ?: continue
                val label = runCatching { pm.getApplicationLabel(info).toString() }
                    .getOrDefault(pkg)
                val icon = runCatching { pm.getApplicationIcon(info) }.getOrNull()
                merged.add(
                    UsageRepository.AppUsage(
                        pkg, label, icon, usedMs[pkg] ?: 0L
                    )
                )
            }
            merged.sortWith(
                compareByDescending<UsageRepository.AppUsage> { it.millis }
                    .thenBy { it.label.lowercase() }
            )
            activity?.runOnUiThread {
                if (!isAdded || myRequest != requested) return@runOnUiThread
                all = merged
                applyFilter()
            }
        }
    }

    private fun applyFilter() {
        val v = view ?: return
        val q = query.lowercase()
        val f = filter
        val filtered = all.filter {
            (q.isEmpty() || it.label.lowercase().contains(q) || it.packageName.lowercase().contains(q)) &&
                (f == null || store.categoryOf(it.packageName) == f)
        }
        v.findViewById<View>(R.id.emptyState).visibility =
            if (filtered.isEmpty()) View.VISIBLE else View.GONE
        adapter.submit(filtered)
    }
}
