package com.timeoverlay.pet.mood

import android.content.Context
import com.timeoverlay.pet.data.AppCategoryStore
import com.timeoverlay.pet.data.Category
import com.timeoverlay.pet.data.PermissionHelper
import com.timeoverlay.pet.data.PerksStore
import com.timeoverlay.pet.data.UsageRepository
import java.util.Calendar

/**
 * Дневные итоги по категориям + настроение — одна функция для главного
 * экрана, аналитики и оверлея, чтобы цифры и состояние питомца совпадали.
 */
object DayMood {

    data class Totals(
        val productiveMs: Long,
        val lazyMs: Long,
        val neutralMs: Long,
        /** Всё экранное время, включая исключённые из оценки приложения. */
        val totalMs: Long
    )

    fun totals(perPackage: Map<String, Long>, store: AppCategoryStore): Totals {
        var prod = 0L
        var lazy = 0L
        var neut = 0L
        var total = 0L
        for ((pkg, ms) in perPackage) {
            total += ms
            when (store.categoryOf(pkg)) {
                Category.PRODUCTIVE -> prod += ms
                Category.LAZY -> lazy += ms
                Category.NEUTRAL -> neut += ms
                Category.EXCLUDED -> Unit
            }
        }
        return Totals(prod, lazy, neut, total)
    }

    /** [perks] — покупки из магазина: энергетик/выключенная ночь и прибавка к настроению. */
    fun compute(
        t: Totals, store: AppCategoryStore, nowMs: Long = System.currentTimeMillis(), perks: PerksStore? = null
    ): MoodEngine.Result =
        MoodEngine.compute(
            productiveMs = t.productiveMs,
            lazyMs = t.lazyMs,
            awakeMs = awakeMs(nowMs),
            screenMs = t.totalMs,
            funAllowanceMinutes = store.funAllowanceMinutes,
            isNight = isNight(nowMs) && !(perks?.isAwake(nowMs) ?: false),
            bonus = perks?.moodBonus(nowMs) ?: 0
        )

    /**
     * Текущее настроение за сегодня из UsageStats (блокирующий вызов — не с UI-потока).
     * Без доступа к статистике — спокойное состояние или сон по времени суток.
     */
    fun todayState(context: Context, nowMs: Long = System.currentTimeMillis()): MoodEngine.State {
        val ctx = context.applicationContext
        val perks = PerksStore(ctx)
        if (!PermissionHelper.hasUsageAccess(ctx)) {
            return if (isNight(nowMs) && !perks.isAwake(nowMs)) MoodEngine.State.SLEEP else MoodEngine.State.CONTENT
        }
        val store = AppCategoryStore(ctx)
        val snap = UsageRepository(ctx).queryToday(nowMs)
        val perPackage = snap.apps.associate { it.packageName to it.millis }
        val totals = totals(perPackage, store).copy(totalMs = snap.totalMillis)
        return compute(totals, store, nowMs, perks).state
    }

    /** Ночь для питомца: 23:00–07:00. */
    fun isNight(nowMs: Long = System.currentTimeMillis()): Boolean {
        val c = Calendar.getInstance()
        c.timeInMillis = nowMs
        val h = c.get(Calendar.HOUR_OF_DAY)
        return h >= NIGHT_START_HOUR || h < NIGHT_END_HOUR
    }

    /** Бодрствование считается с 07:00 — сон ночью не награждается как «отдых». */
    fun awakeMs(nowMs: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = UsageRepository.startOfDay(nowMs)
        c.set(Calendar.HOUR_OF_DAY, NIGHT_END_HOUR)
        return (nowMs - c.timeInMillis).coerceAtLeast(0L)
    }

    const val NIGHT_START_HOUR = 23
    const val NIGHT_END_HOUR = 7
}
