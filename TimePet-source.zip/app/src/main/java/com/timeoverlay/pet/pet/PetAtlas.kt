package com.timeoverlay.pet.pet

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect

/**
 * Спрайт-атласы питомцев. Каждый декодируется один раз на процесс:
 * главный экран и оверлей-сервис живут в одном процессе и делят копию.
 * Кадры не вырезаются в отдельные Bitmap — рисуем через src-прямоугольник.
 *
 * Полный атлас (1536×1872, ~11 МБ) держим только для активного питомца;
 * для карточек выбора — уменьшенный в 4 раза (~0,7 МБ на питомца).
 */
object PetAtlas {
    const val COLS = 8
    const val ROWS = 9

    private val full = HashMap<String, Bitmap>()
    private val small = HashMap<String, Bitmap>()

    fun get(context: Context, pet: PetDef, preview: Boolean = false): Bitmap? {
        val cache = if (preview) small else full
        synchronized(cache) {
            cache[pet.id]?.let { return it }
            val opts = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
                if (preview) inSampleSize = 4
            }
            val bmp = runCatching {
                context.applicationContext.assets.open(pet.spritesheetPath)
                    .use { BitmapFactory.decodeStream(it, null, opts) }
            }.getOrNull() ?: return null
            cache[pet.id] = bmp
            return bmp
        }
    }

    /** Отпустить полные атласы всех питомцев, кроме активного. */
    fun retainOnly(petId: String) {
        synchronized(full) {
            val gone = full.keys.filter { it != petId }
            // Без recycle(): view может ещё дорисовывать старый кадр, память вернёт GC.
            for (id in gone) full.remove(id)
        }
    }

    fun cellWidth(bmp: Bitmap): Int = bmp.width / COLS
    fun cellHeight(bmp: Bitmap): Int = bmp.height / ROWS

    fun src(bmp: Bitmap, row: Int, col: Int, out: Rect): Rect {
        val w = cellWidth(bmp)
        val h = cellHeight(bmp)
        out.set(col * w, row * h, col * w + w, row * h + h)
        return out
    }
}
