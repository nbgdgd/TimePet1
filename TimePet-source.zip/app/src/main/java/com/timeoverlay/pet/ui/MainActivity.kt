package com.timeoverlay.pet.ui

import android.content.res.ColorStateList
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.timeoverlay.pet.BuildConfig
import com.timeoverlay.pet.R
import com.timeoverlay.pet.data.PermissionHelper
import com.timeoverlay.pet.data.Reminders
import com.timeoverlay.pet.data.UnlockStore
import com.timeoverlay.pet.overlay.OverlayPrefs
import com.timeoverlay.pet.overlay.PetOverlayService

/** Хост с нижней навигацией: Сегодня / Аналитика / Приложения / Питомец. */
class MainActivity : AppCompatActivity(), AppDetailDialog.Listener {

    private lateinit var nav: BottomNavigationView

    private var themeVersion = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.apply(this)
        themeVersion = ThemeManager.version
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nav = findViewById(R.id.bottomNav)
        // Отладка движений: adb shell am start -n .../MainActivity --es debug_move RUN (только debug-сборка).
        if (BuildConfig.DEBUG) intent?.getStringExtra("debug_move")?.let { PetOverlayService.debugMove(this, it) }
        // Цвета пунктов - из атрибутов темы (селектор в res/color с ?attr здесь не инфлейтится).
        val navColors = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(themeColor(R.attr.tp_seed), themeColor(R.attr.tp_text_muted))
        )
        nav.itemIconTintList = navColors
        nav.itemTextColor = navColors
        nav.setOnItemSelectedListener { item ->
            show(
                when (item.itemId) {
                    R.id.tab_stats -> StatsFragment()
                    R.id.tab_apps -> AppsFragment()
                    R.id.tab_pet -> PetFragment()
                    else -> HomeFragment()
                }
            )
            true
        }
        if (savedInstanceState == null) {
            nav.selectedItemId = R.id.tab_home
            show(HomeFragment())
        }
    }

    fun openTab(id: Int) {
        nav.selectedItemId = id
    }

    private fun show(f: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.container, f)
            .commit()
    }

    override fun onCategoryChanged() {
        (supportFragmentManager.findFragmentById(R.id.container) as? AppDetailDialog.Listener)
            ?.onCategoryChanged()
    }

    override fun onResume() {
        super.onResume()
        if (themeVersion != ThemeManager.version) { recreate(); return }
        // Открыли приложение: день засчитан, цикл напоминаний заново.
        UnlockStore(this).markUsedToday()
        Reminders.onAppOpened(this)
        // Отладка напоминаний: --ez debug_reminder true — как будто не заходили 3 дня.
        if (BuildConfig.DEBUG && intent?.getBooleanExtra("debug_reminder", false) == true) {
            intent.removeExtra("debug_reminder")
            val prefs = com.timeoverlay.pet.data.AppPrefs(this)
            prefs.lastOpenAt = System.currentTimeMillis() - 3L * 24 * 60 * 60_000L
            android.util.Log.d("TimePet", "debug reminder sent=" + Reminders.check(this))
        }
        // Питомец включён, разрешения на месте, а сервис не жив (процесс перезапустили) — поднять.
        val overlay = OverlayPrefs(this)
        if (overlay.enabled && !PetOverlayService.running && PermissionHelper.hasOverlayRequired(this)) {
            overlay.stopReason = null
            PetOverlayService.start(this)
        }
    }
}
