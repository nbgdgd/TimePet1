package com.timeoverlay.pet.data

import android.content.Context
import com.timeoverlay.pet.R
import java.util.Locale

/** Форматы времени: короткий цифровой (таймер) и длинный с единицами (списки). */
object TimeFormat {

    fun short(millis: Long): String {
        val s = (millis / 1000).toInt().coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%d:%02d", m, sec)
    }

    /** «1 h 30 min» / «1 ч 30 мин» — единицы из ресурсов. */
    fun long(context: Context, millis: Long): String = long(
        millis,
        context.getString(R.string.unit_h),
        context.getString(R.string.unit_min),
        context.getString(R.string.unit_s)
    )

    fun long(millis: Long, h: String, min: String, s: String): String {
        val totalMin = (millis / 60_000).toInt().coerceAtLeast(0)
        if (totalMin == 0) return "${(millis / 1000).toInt().coerceAtLeast(0)} $s"
        val hours = totalMin / 60
        val m = totalMin % 60
        return when {
            hours == 0 -> "$m $min"
            m == 0 -> "$hours $h"
            else -> "$hours $h $m $min"
        }
    }
}
