package com.timeoverlay.pet.ui

import android.app.Dialog
import android.os.Bundle
import android.widget.ImageView
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.checkbox.MaterialCheckBox
import com.timeoverlay.pet.overlay.OverlayPrefs
import com.timeoverlay.pet.R
import com.timeoverlay.pet.data.AppCategoryStore
import com.timeoverlay.pet.data.Category
import com.timeoverlay.pet.data.TimeFormat
import com.timeoverlay.pet.data.UsageRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Подробности приложения: время за период, дневная динамика,
 * влияние на питомца и смена категории.
 */
class AppDetailDialog : DialogFragment() {

    interface Listener {
        fun onCategoryChanged()
    }

    companion object {
        private const val ARG_PKG = "pkg"
        private const val ARG_LABEL = "label"
        private const val ARG_MILLIS = "millis"
        private const val ARG_DAYS = "days"

        fun new(
            app: UsageRepository.AppUsage, days: Int
        ): AppDetailDialog {
            val d = AppDetailDialog()
            d.arguments = Bundle().apply {
                putString(ARG_PKG, app.packageName)
                putString(ARG_LABEL, app.label)
                putLong(ARG_MILLIS, app.millis)
                putInt(ARG_DAYS, days)
            }
            return d
        }
    }

    private var bindGroup: () -> Unit = {}

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val pkg = requireArguments().getString(ARG_PKG)!!
        val label = requireArguments().getString(ARG_LABEL)!!
        val millis = requireArguments().getLong(ARG_MILLIS)
        val days = requireArguments().getInt(ARG_DAYS).coerceIn(1, 30)

        val view = layoutInflater.inflate(R.layout.dialog_app_detail, null)
        val store = AppCategoryStore(requireContext())
        val repo = UsageRepository(requireContext())

        view.findViewById<TextView>(R.id.detailName).text = label
        view.findViewById<TextView>(R.id.detailTime).text = TimeFormat.long(requireContext(), millis)
        val pm = requireContext().packageManager
        val icon = runCatching {
            pm.getApplicationIcon(pkg)
        }.getOrNull()
        if (icon != null) view.findViewById<ImageView>(R.id.detailIcon)
            .setImageDrawable(icon)

        val group: RadioGroup = view.findViewById(R.id.categoryGroup)
        val effect: TextView = view.findViewById(R.id.detailEffect)
        val source: TextView = view.findViewById(R.id.detailSource)
        fun refreshEffect(c: Category) {
            effect.text = when (c) {
                Category.PRODUCTIVE -> getString(R.string.effect_productive)
                Category.LAZY -> getString(R.string.effect_lazy)
                Category.NEUTRAL -> getString(R.string.effect_neutral)
                Category.EXCLUDED -> getString(R.string.effect_excluded)
            }
            // Откуда категория: ручная важнее базы, база важнее системной.
            source.text = when (store.sourceOf(pkg)) {
                AppCategoryStore.Source.USER -> getString(R.string.cat_source_user)
                AppCategoryStore.Source.BUILTIN -> getString(R.string.cat_source_builtin)
                AppCategoryStore.Source.SYSTEM -> getString(R.string.cat_source_system)
                AppCategoryStore.Source.DEFAULT -> getString(R.string.cat_source_default)
            }
        }
        view.findViewById<TextView>(R.id.detailReset).setOnClickListener {
            store.clearCategory(pkg)
            val c = store.categoryOf(pkg)
            group.setOnCheckedChangeListener(null)
            group.check(
                when (c) {
                    Category.PRODUCTIVE -> R.id.catProductive
                    Category.LAZY -> R.id.catLazy
                    Category.EXCLUDED -> R.id.catExcluded
                    else -> R.id.catNeutral
                }
            )
            bindGroup()
            refreshEffect(c)
            (parentFragment as? Listener)?.onCategoryChanged()
            (activity as? Listener)?.onCategoryChanged()
        }
        when (store.categoryOf(pkg)) {
            Category.PRODUCTIVE -> group.check(R.id.catProductive)
            Category.LAZY -> group.check(R.id.catLazy)
            Category.NEUTRAL -> group.check(R.id.catNeutral)
            Category.EXCLUDED -> group.check(R.id.catExcluded)
        }
        refreshEffect(store.categoryOf(pkg))
        bindGroup()

        bindGroup = {
            group.setOnCheckedChangeListener { _, id ->
                val c = when (id) {
                    R.id.catProductive -> Category.PRODUCTIVE
                    R.id.catLazy -> Category.LAZY
                    R.id.catExcluded -> Category.EXCLUDED
                    else -> Category.NEUTRAL
                }
                store.setCategory(pkg, c)
                refreshEffect(c)
                (parentFragment as? Listener)?.onCategoryChanged()
                (activity as? Listener)?.onCategoryChanged()
            }
        }
        bindGroup()

        // Скрытие оверлея над приложением — отдельно от исключения из оценки.
        val overlay = OverlayPrefs(requireContext())
        view.findViewById<MaterialCheckBox>(R.id.hideOverlay).apply {
            isChecked = overlay.isHidden(pkg)
            setOnCheckedChangeListener { _, checked -> overlay.setHidden(pkg, checked) }
        }

        // Дневная динамика именно этого пакета.
        lifecycleScope.launch(Dispatchers.IO) {
            val perDay = repo.queryPackageSeries(pkg, days)
            withContext(Dispatchers.Main) {
                if (isAdded) {
                    view.findViewById<DayBarView>(R.id.detailChart)
                        .setValues(perDay)
                }
            }
        }

        return AlertDialog.Builder(requireContext())
            .setView(view)
            .setPositiveButton(android.R.string.ok, null)
            .create()
    }
}
