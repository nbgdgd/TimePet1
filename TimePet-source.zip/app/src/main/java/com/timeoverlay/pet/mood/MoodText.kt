package com.timeoverlay.pet.mood

import android.content.Context
import com.timeoverlay.pet.R
import com.timeoverlay.pet.data.TimeFormat

/** Локализованные подписи настроения и причины. */
object MoodText {

    fun title(context: Context, s: MoodEngine.State): String = context.getString(
        when (s) {
            MoodEngine.State.HAPPY -> R.string.mood_happy
            MoodEngine.State.CONTENT -> R.string.mood_content
            MoodEngine.State.TIRED -> R.string.mood_tired
            MoodEngine.State.SAD -> R.string.mood_sad
            MoodEngine.State.EXHAUSTED -> R.string.mood_exhausted
            MoodEngine.State.SLEEP -> R.string.mood_sleep
        }
    )

    /** Состояние одним словом для строки «Состояние»: сыт, устал, спит и т.п. */
    fun stateWord(context: Context, s: MoodEngine.State): String = context.getString(
        when (s) {
            MoodEngine.State.HAPPY -> R.string.state_word_happy
            MoodEngine.State.CONTENT -> R.string.state_word_content
            MoodEngine.State.TIRED -> R.string.state_word_tired
            MoodEngine.State.SAD -> R.string.state_word_sad
            MoodEngine.State.EXHAUSTED -> R.string.state_word_exhausted
            MoodEngine.State.SLEEP -> R.string.state_word_sleep
        }
    )

    fun reason(context: Context, r: MoodEngine.Result): String {
        val prod = minutes(context, r.productiveMin)
        val lazy = minutes(context, r.lazyMin)
        val limit = minutes(context, r.allowanceMin)
        return when (r.reason) {
            MoodEngine.Reason.HAPPY -> context.getString(R.string.reason_happy, prod)
            MoodEngine.Reason.CONTENT_BALANCED -> context.getString(R.string.reason_content_balanced, prod, lazy)
            MoodEngine.Reason.CONTENT_QUIET -> context.getString(R.string.reason_content_quiet)
            MoodEngine.Reason.TIRED_OVER_LIMIT -> context.getString(R.string.reason_tired_over, lazy, limit)
            MoodEngine.Reason.TIRED_GREY -> context.getString(R.string.reason_tired_grey)
            MoodEngine.Reason.SAD -> context.getString(R.string.reason_sad, lazy, limit)
            MoodEngine.Reason.EXHAUSTED -> context.getString(R.string.reason_exhausted)
            MoodEngine.Reason.SLEEP -> context.getString(R.string.reason_sleep)
        }
    }

    /** Силы питомца 0..5 по состоянию — для шкалы в строке «Состояние». */
    fun energyLevel(s: MoodEngine.State): Int = when (s) {
        MoodEngine.State.HAPPY -> 5
        MoodEngine.State.CONTENT -> 4
        MoodEngine.State.TIRED -> 3
        MoodEngine.State.SAD -> 2
        MoodEngine.State.EXHAUSTED -> 1
        MoodEngine.State.SLEEP -> 0
    }

    /** Короткий заголовок причины: цифры уходят в полоску и подписи под ней. */
    fun reasonTitle(context: Context, r: MoodEngine.Result): String = when (r.reason) {
        MoodEngine.Reason.HAPPY -> context.getString(R.string.reason_short_happy)
        MoodEngine.Reason.CONTENT_BALANCED -> context.getString(R.string.reason_short_balanced)
        MoodEngine.Reason.TIRED_OVER_LIMIT -> context.getString(R.string.reason_short_over)
        MoodEngine.Reason.SAD -> context.getString(R.string.reason_short_sad)
        else -> reason(context, r)
    }

    fun minutesText(context: Context, min: Int): String = minutes(context, min)

    /** Минуты словами: «0 min», «45 min», «1 h 20 min». */
    private fun minutes(context: Context, min: Int): String =
        if (min < 60) "$min ${context.getString(R.string.unit_min)}"
        else TimeFormat.long(context, min * 60_000L)

    /** Короткая подсказка-инсайт под графиком: что сделать, чтобы питомцу стало лучше. */
    fun insight(context: Context, r: MoodEngine.Result): String = context.getString(
        when (r.state) {
            MoodEngine.State.HAPPY -> R.string.insight_happy
            MoodEngine.State.CONTENT -> R.string.insight_content
            MoodEngine.State.TIRED -> R.string.insight_tired
            MoodEngine.State.SAD, MoodEngine.State.EXHAUSTED -> R.string.insight_sad
            MoodEngine.State.SLEEP -> R.string.insight_sleep
        }
    )

    /** Цвет состояния для иконок/плашек. */
    fun colorRes(s: MoodEngine.State): Int = when (s) {
        MoodEngine.State.HAPPY -> R.color.mood_good
        MoodEngine.State.CONTENT -> R.color.mood_ok
        MoodEngine.State.TIRED -> R.color.mood_mid
        MoodEngine.State.SAD, MoodEngine.State.EXHAUSTED -> R.color.mood_bad
        MoodEngine.State.SLEEP -> R.color.mood_sleep
    }

    fun faceRes(s: MoodEngine.State): Int = when (s) {
        MoodEngine.State.HAPPY -> R.drawable.ic_face_happy
        MoodEngine.State.CONTENT -> R.drawable.ic_face_content
        MoodEngine.State.TIRED -> R.drawable.ic_face_tired
        MoodEngine.State.SAD, MoodEngine.State.EXHAUSTED -> R.drawable.ic_face_sad
        MoodEngine.State.SLEEP -> R.drawable.ic_face_sleep
    }
}
