package com.timeoverlay.pet.data

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import java.util.Locale

/**
 * Общие настройки приложения: тема, язык, анимация и сглаживание питомца,
 * напоминания, флаг приветствия.
 */
class AppPrefs(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Тема: "system" (Дневная/Ночная по системе), "classic", "day", "tinted", "night", "amoled". */
    var themeId: String
        get() = prefs.getString(KEY_THEME_ID, null) ?: when (prefs.getInt(KEY_THEME, -1)) {
            1 -> "day"
            2 -> "night"
            0 -> "system"
            else -> DEFAULT_THEME
        }
        set(v) = prefs.edit().putString(KEY_THEME_ID, v).apply()

    /** Индекс цвета акцента (см. ThemeManager.ACCENT_PREVIEW); по умолчанию фиолетовый. */
    var accent: Int
        get() = prefs.getInt(KEY_ACCENT, DEFAULT_ACCENT)
        set(v) = prefs.edit().putInt(KEY_ACCENT, v).apply()

    /** "" — как в системе, иначе тег языка ("ru", "en"). */
    var language: String
        get() = prefs.getString(KEY_LANGUAGE, "") ?: ""
        set(v) = prefs.edit().putString(KEY_LANGUAGE, v).apply()

    /** Покадровая анимация питомца; выключено — один статичный кадр состояния. */
    var animations: Boolean
        get() = prefs.getBoolean(KEY_ANIMATIONS, true)
        set(v) = prefs.edit().putBoolean(KEY_ANIMATIONS, v).apply()

    /** Сглаживание питомцев при масштабировании (везде: экраны, карточки, оверлей). */
    var smoothing: Boolean
        get() = prefs.getBoolean(KEY_SMOOTH, true)
        set(v) = prefs.edit().putBoolean(KEY_SMOOTH, v).apply()

    /** Напоминания при отсутствии: 0 выкл, 1 редко, 2 обычно. */
    var reminders: Int
        get() = prefs.getInt(KEY_REMINDERS, 2).coerceIn(0, 2)
        set(v) = prefs.edit().putInt(KEY_REMINDERS, v.coerceIn(0, 2)).apply()

    /** Когда пользователь последний раз открывал TimePet. */
    var lastOpenAt: Long
        get() = prefs.getLong(KEY_LAST_OPEN, 0L)
        set(v) = prefs.edit().putLong(KEY_LAST_OPEN, v).apply()

    /** Когда ушло последнее напоминание и какое по счёту с момента ухода (0 — ещё не было). */
    var lastReminderAt: Long
        get() = prefs.getLong(KEY_LAST_REMINDER, 0L)
        set(v) = prefs.edit().putLong(KEY_LAST_REMINDER, v).apply()

    var reminderStage: Int
        get() = prefs.getInt(KEY_REMINDER_STAGE, 0)
        set(v) = prefs.edit().putInt(KEY_REMINDER_STAGE, v).apply()

    var onboarded: Boolean
        get() = prefs.getBoolean(KEY_ONBOARDED, false)
        set(v) = prefs.edit().putBoolean(KEY_ONBOARDED, v).apply()

    /** Ночной режим AppCompat всегда «как в системе»: палитру выбирает ThemeManager. */
    fun applyTheme() {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
    }

    /** Язык для Activity: AppCompat сам пересоздаёт экраны, статистика и настройки не трогаются. */
    fun applyLanguage() {
        val tag = language
        AppCompatDelegate.setApplicationLocales(
            if (tag.isEmpty()) LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(tag)
        )
    }

    /**
     * Контекст с выбранным языком для сервиса и уведомления: на Android 13+
     * система сама применяет язык приложения, ниже — переопределяем локаль вручную.
     */
    fun localized(base: Context): Context {
        val tag = language
        if (tag.isEmpty()) return base
        val conf = Configuration(base.resources.configuration)
        conf.setLocale(Locale.forLanguageTag(tag))
        return base.createConfigurationContext(conf)
    }

    fun registerListener(l: SharedPreferences.OnSharedPreferenceChangeListener) =
        prefs.registerOnSharedPreferenceChangeListener(l)

    fun unregisterListener(l: SharedPreferences.OnSharedPreferenceChangeListener) =
        prefs.unregisterOnSharedPreferenceChangeListener(l)

    companion object {
        private const val PREFS = "app"
        const val DEFAULT_THEME = "day"
        /** Индекс фиолетового в ThemeManager.ACCENT_PREVIEW. */
        const val DEFAULT_ACCENT = 5
        private const val KEY_THEME = "theme"
        private const val KEY_THEME_ID = "theme_id"
        private const val KEY_ACCENT = "accent"
        const val KEY_LANGUAGE = "language"
        const val KEY_ANIMATIONS = "animations"
        const val KEY_SMOOTH = "smoothing"
        const val KEY_REMINDERS = "reminders"
        private const val KEY_LAST_OPEN = "last_open_at"
        private const val KEY_LAST_REMINDER = "last_reminder_at"
        private const val KEY_REMINDER_STAGE = "reminder_stage"
        private const val KEY_ONBOARDED = "onboarded"
    }
}
