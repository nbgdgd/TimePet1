package com.timeoverlay.pet.data

/**
 * Категории приложений. Это ярлыки пользователя для оценки распределения
 * времени, а не объективная оценка пользы приложений.
 */
enum class Category {
    PRODUCTIVE,
    LAZY,
    NEUTRAL,
    EXCLUDED
}
