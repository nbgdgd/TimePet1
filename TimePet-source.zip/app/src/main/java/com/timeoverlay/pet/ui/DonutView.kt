package com.timeoverlay.pet.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import com.timeoverlay.pet.R

/**
 * Кольцевая диаграмма распределения времени: лень / нейтральные / продуктивность.
 * В центре — общее время и подпись. Пустые данные — серое кольцо.
 */
class DonutView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private var parts = floatArrayOf(0f, 0f, 0f)
    private var centerText = ""
    private var centerLabel = ""
    private val colors = intArrayOf(R.color.lazy, R.color.neutral, R.color.productive)
        .map { ContextCompat.getColor(context, it) }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.BUTT
    }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = context.themeColor(R.attr.tp_track)
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = context.themeColor(R.attr.tp_text_main)
        isFakeBoldText = true
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = context.themeColor(R.attr.tp_text_muted)
    }
    private val rect = RectF()

    fun set(lazy: Long, neutral: Long, productive: Long, center: String, label: String) {
        val total = (lazy + neutral + productive).toFloat()
        parts = if (total <= 0f) floatArrayOf(0f, 0f, 0f)
        else floatArrayOf(lazy / total, neutral / total, productive / total)
        centerText = center
        centerLabel = label
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        // Размер как множитель от базовых 104 dp: толщина кольца и текст растут вместе с ним.
        val k = (minOf(width, height) / (104f * d)).coerceIn(1f, 2.4f)
        val stroke = 14f * d * k
        arc.strokeWidth = stroke
        track.strokeWidth = stroke
        val r = minOf(width, height) / 2f - stroke / 2f - 2f * d
        val cx = width / 2f
        val cy = height / 2f
        rect.set(cx - r, cy - r, cx + r, cy + r)
        canvas.drawArc(rect, 0f, 360f, false, track)
        var start = -90f
        val gap = 2.5f
        for (i in parts.indices) {
            val sweep = 360f * parts[i]
            if (sweep <= 0f) continue
            arc.color = colors[i]
            canvas.drawArc(rect, start + gap / 2, (sweep - gap).coerceAtLeast(0.5f), false, arc)
            start += sweep
        }
        // Текст в центре не должен вылезать за отверстие: подгоняем размер под его ширину.
        val sd = resources.displayMetrics.scaledDensity
        val inner = 2f * (r - stroke / 2f) * 0.84f
        var size = 17f * sd * k
        textPaint.textSize = size
        while (size > 10f * sd && textPaint.measureText(centerText) > inner) {
            size -= 0.5f * sd
            textPaint.textSize = size
        }
        labelPaint.textSize = 11f * sd * k
        if (labelPaint.measureText(centerLabel) > inner) labelPaint.textSize = 9f * sd * k
        canvas.drawText(centerText, cx, cy + 2f * d * k, textPaint)
        canvas.drawText(centerLabel, cx, cy + 16f * d * k, labelPaint)
    }
}
