package com.timeoverlay.pet.overlay

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.timeoverlay.pet.data.PermissionHelper
import com.timeoverlay.pet.data.Reminders

/**
 * После перезагрузки или обновления приложения поднимает питомца, если он
 * был включён и разрешения на месте, и заново ставит будильник напоминаний.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED && intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val prefs = OverlayPrefs(context)
        if (prefs.enabled && PermissionHelper.hasOverlayRequired(context)) {
            runCatching { PetOverlayService.start(context) }
        }
        runCatching { Reminders.schedule(context) }
    }
}
