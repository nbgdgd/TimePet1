package com.timeoverlay.pet.mood

import kotlin.math.roundToInt

/**
 * Движок настроения питомца (чистая логика, без Android — покрыт тестами).
 *
 * Прозрачная формула (она же показана пользователю в приложении):
 * - Старт дня: 60.
 * - Продуктивность: +3 за каждые 10 минут, суммарно не больше +24.
 * - Лень в пределах лимита: −1 за каждые 10 минут (обычный отдых не наказывается).
 * - Лень сверх лимита: дополнительно −5 за каждые 10 минут сверх лимита,
 *   суммарный вклад лени не ниже −40.
 * - Нейтральные и исключённые: 0.
 * - Отдых без телефона (время бодрствования минус экранное время):
 *   +1 за каждый час, но итог отдыхом подтягивается не выше 72 —
 *   приложение не должно подталкивать сидеть в телефоне ради награды
 *   и не должно награждать за то, что телефон просто лежал ночью.
 * - Итог ограничен 0..100. Изменения постепенные: короткий запуск TikTok
 *   (5–10 минут внутри лимита) сдвигает счёт меньше чем на единицу.
 * - [bonus] — купленная в магазине «вкусняшка»: прибавка к счёту до конца дня.
 */
object MoodEngine {

    enum class State {
        HAPPY, CONTENT, TIRED, SAD, EXHAUSTED, SLEEP
    }

    /** Причина настроения — код для строковых ресурсов (текст локализуется в UI). */
    enum class Reason {
        HAPPY, CONTENT_BALANCED, CONTENT_QUIET, TIRED_OVER_LIMIT, TIRED_GREY,
        SAD, EXHAUSTED, SLEEP
    }

    data class Result(
        val score: Int,
        val state: State,
        val reason: Reason,
        /** Аргументы для текста причины: минуты продуктивности, лени и лимит. */
        val productiveMin: Int,
        val lazyMin: Int,
        val allowanceMin: Int
    )

    fun compute(
        productiveMs: Long,
        lazyMs: Long,
        awakeMs: Long,
        screenMs: Long,
        funAllowanceMinutes: Int,
        isNight: Boolean,
        bonus: Int = 0
    ): Result {
        val prodMin = (productiveMs / 60_000.0).coerceAtLeast(0.0)
        val lazyMin = (lazyMs / 60_000.0).coerceAtLeast(0.0)
        val allowance = funAllowanceMinutes.coerceIn(0, 480).toDouble()

        var score = 60.0
        val prodBonus = (prodMin / 10.0 * 3.0).coerceAtMost(24.0)
        score += prodBonus

        val lazyWithin = minOf(lazyMin, allowance)
        val lazyOver = (lazyMin - allowance).coerceAtLeast(0.0)
        val lazyPenalty = (lazyWithin / 10.0 * 1.0 + lazyOver / 10.0 * 5.0)
            .coerceAtMost(40.0)
        score -= lazyPenalty

        val restMin = ((awakeMs - screenMs) / 60_000.0).coerceAtLeast(0.0)
        val restBonus = (restMin / 60.0 * 1.0).coerceAtMost(8.0)
        score += restBonus
        // Отдых без телефона — только до довольного состояния, не до счастья.
        if (prodBonus < 6.0) score = score.coerceAtMost(72.0)

        score = (score + bonus).coerceIn(0.0, 100.0)
        val rounded = score.roundToInt()

        val state = when {
            isNight -> State.SLEEP
            rounded >= 75 -> State.HAPPY
            rounded >= 55 -> State.CONTENT
            rounded >= 40 -> State.TIRED
            rounded >= 25 -> State.SAD
            else -> State.EXHAUSTED
        }
        val reason = when (state) {
            State.HAPPY -> Reason.HAPPY
            State.CONTENT -> if (prodMin >= 20.0) Reason.CONTENT_BALANCED else Reason.CONTENT_QUIET
            State.TIRED -> if (lazyMin > allowance) Reason.TIRED_OVER_LIMIT else Reason.TIRED_GREY
            State.SAD -> Reason.SAD
            State.EXHAUSTED -> Reason.EXHAUSTED
            State.SLEEP -> Reason.SLEEP
        }
        return Result(
            rounded, state, reason,
            prodMin.roundToInt(), lazyMin.roundToInt(), allowance.roundToInt()
        )
    }

    /**
     * Оценка продуктивности 0–100 для экрана аналитики.
     * (продуктивные − ленивые сверх лимита) / все учтённые минуты.
     * Это оценка распределения времени по твоим категориям,
     * а не доказательство работы или лени.
     */
    fun productivityScore(
        productiveMs: Long, lazyMs: Long, neutralMs: Long,
        funAllowanceMinutes: Int
    ): Int {
        val total = productiveMs + lazyMs + neutralMs
        if (total <= 0) return -1 // нет данных — показываем пустое состояние
        val over = (lazyMs / 60_000.0 - funAllowanceMinutes).coerceAtLeast(0.0)
        val good = productiveMs / 60_000.0 - over
        return ((good / (total / 60_000.0)) * 100.0).roundToInt().coerceIn(0, 100)
    }
}
