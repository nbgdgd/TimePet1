package com.timeoverlay.pet.overlay

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.timeoverlay.pet.BuildConfig
import com.timeoverlay.pet.R
import com.timeoverlay.pet.data.AppCategoryStore
import com.timeoverlay.pet.data.AppPrefs
import com.timeoverlay.pet.data.Category
import com.timeoverlay.pet.data.DayLedger
import com.timeoverlay.pet.data.HistoryStore
import com.timeoverlay.pet.data.PermissionHelper
import com.timeoverlay.pet.data.PerksStore
import com.timeoverlay.pet.data.TimeFormat
import com.timeoverlay.pet.data.UnlockStore
import com.timeoverlay.pet.data.UsageRepository
import com.timeoverlay.pet.mood.DayMood
import com.timeoverlay.pet.mood.MoodEngine
import com.timeoverlay.pet.mood.MoodText
import com.timeoverlay.pet.mood.PetTalk
import com.timeoverlay.pet.pet.PetAction
import com.timeoverlay.pet.pet.PetAtlas
import com.timeoverlay.pet.pet.PetDef
import com.timeoverlay.pet.pet.PetMove
import com.timeoverlay.pet.ui.MainActivity
import com.timeoverlay.pet.ui.PetSpriteView
import java.text.DateFormat
import java.time.LocalDate
import java.util.Date
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * Foreground-сервис плавающего питомца.
 *
 * Два окна: плашка таймера ([OverlayView], домашняя точка) и питомец
 * ([PetHolderView]) рядом с ней. Питомец гуляет сам ([PetBehavior]),
 * таймер при этом стоит; перенос таймера переносит и дом.
 *
 * Раз в секунду: дочитывает новые события UsageStats в [DayLedger],
 * определяет приложение на экране, обновляет таймер и показывает/прячет
 * окна. Смена приложения подтверждается через ~0,7 с, чтобы короткие
 * системные окна не дёргали виджет и не запускали реакций; реакции идут
 * не чаще раза в 5–10 с и только на последнее подтверждённое приложение.
 *
 * Настроение — та же свёртка, что и на главном экране ([DayMood]).
 * Экран погас или заблокирован — окна убираются, анимации стоят.
 * После разблокировки, если событие RESUMED не пришло, текущее приложение
 * восстанавливается по последним событиям. Позиции хранятся в долях экрана
 * отдельно для портрета и ландшафта и переживают перезапуск процесса.
 *
 * «Не беспокоить» (на время или до отключения): прогулки и реакции стоят,
 * таймер виден; по истечении — обычное поведение само.
 */
class PetOverlayService : Service(), OverlayView.Listener, PetHolderView.Listener, PetBehavior.Host {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var prefs: OverlayPrefs
    private lateinit var appPrefs: AppPrefs
    private lateinit var store: AppCategoryStore
    private lateinit var repo: UsageRepository
    private lateinit var history: HistoryStore
    private lateinit var perks: PerksStore
    /** Контекст с выбранным языком — для всех строк сервиса. */
    private lateinit var loc: Context

    private var panel: OverlayView? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var panelAttached = false
    private var holder: PetHolderView? = null
    private var petLp: WindowManager.LayoutParams? = null
    private var petAttached = false
    private var shown = false
    private var dndMenu: DndMenuView? = null
    private val behavior = PetBehavior(handler, this)

    private var ledger: DayLedger = DayLedger(UsageRepository.startOfDay(System.currentTimeMillis()))
    private var lastQueryEnd = 0L
    private val seenEvents = HashMap<String, Long>()

    private var screenOn = true
    private var ticking = false
    private var currentPkg: String? = null
    private var pendingPkg: String? = null
    private var pendingSince = 0L
    private var launcherPkgs: Set<String> = emptySet()
    private var launcherCheckedAt = 0L
    private var lastMoodAt = 0L
    private var lastHistoryAt = 0L
    private var lastReactionAt = 0L
    private var reactionGapMs = 5_000L
    private var mood: MoodEngine.Result? = null
    private var phraseUntil = 0L
    private var phrase: String? = null
    private var dndWasActive = false

    // Домашняя точка (плашка) и место отдыха питомца рядом с ней.
    private var homeX = 0
    private var homeY = 0
    private var petRestX = 0
    private var petRestY = 0

    // Перетаскивание: стартовые координаты окна и крестик для удаления.
    private var dragStartX = 0
    private var dragStartY = 0
    private var dragging = false
    private var draggingPet = false
    private var petFollows = false
    private var dismissTarget: DismissTargetView? = null
    private var overDismiss = false

    private val tick = object : Runnable {
        override fun run() {
            val visible = shown
            runCatching { onTick() }
            // Над скрытым приложением опрашиваем реже — учёт не теряется, батарея целее.
            // Пока смена приложения ждёт подтверждения — чаще.
            val delay = when {
                pendingPkg != null -> 350L
                visible -> 1000L - (System.currentTimeMillis() % 1000L)
                else -> 1500L
            }
            handler.postDelayed(this, delay)
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            Log.d(TAG, "broadcast ${intent.action} locked=${isLocked()}")
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> onScreenOff()
                Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> onScreenOn()
                Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED, Intent.ACTION_DATE_CHANGED ->
                    rebuildLedger(System.currentTimeMillis())
            }
        }
    }

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            OverlayPrefs.KEY_ENABLED -> if (!prefs.enabled) stopSelf()
            OverlayPrefs.KEY_SIZE, OverlayPrefs.KEY_COLLAPSED, OverlayPrefs.KEY_TIMER, OverlayPrefs.KEY_MODE,
            OverlayPrefs.KEY_SIMPLE, OverlayPrefs.KEY_APP_NAME, OverlayPrefs.KEY_OPACITY -> applyAppearance()
            OverlayPrefs.KEY_PER_APP -> applyPosition(currentPkg)
            OverlayPrefs.KEY_HIDDEN, OverlayPrefs.KEY_LAUNCHER -> updateVisibility()
            OverlayPrefs.KEY_PET -> holder?.let {
                val def = PetDef.byId(prefs.petId)
                it.pet.setPet(def)
                PetAtlas.retainOnly(def.id)
                behavior.cancel()
                handler.post { applyPosition(currentPkg); if (shown) behavior.onShown() }
            }
            OverlayPrefs.KEY_BEHAVIOR, OverlayPrefs.KEY_ACTIVITY, OverlayPrefs.KEY_DND_UNTIL -> {
                applyBehaviorPrefs()
                startForegroundCompat()
                updateStatus()
            }
            else -> Unit
        }
    }

    private val appPrefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == AppPrefs.KEY_LANGUAGE) {
            loc = appPrefs.localized(this)
            appLabels.clear()
            startForegroundCompat()
            updateStatus()
        }
    }

    private val categoryListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        // Категория, лимит или покупка в магазине — настроение пересчитать сразу.
        lastMoodAt = 0L
        currentPkg?.let { panel?.setCategory(store.categoryOf(it)) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = OverlayPrefs(this)
        appPrefs = AppPrefs(this)
        loc = appPrefs.localized(this)
        store = AppCategoryStore(this)
        repo = UsageRepository(this)
        history = HistoryStore(this)
        perks = PerksStore(this)
        behavior.setDensity(resources.displayMetrics.density)
        startForegroundCompat()
        running = true

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(Intent.ACTION_DATE_CHANGED)
        }
        ContextCompat.registerReceiver(this, screenReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        prefs.registerListener(prefsListener)
        appPrefs.registerListener(appPrefsListener)
        store.registerListener(categoryListener)
        perks.registerListener(categoryListener)

        val pm = getSystemService(POWER_SERVICE) as PowerManager
        screenOn = pm.isInteractive && !isLocked()
        rebuildLedger(System.currentTimeMillis())
        restoreForeground(System.currentTimeMillis())
        UnlockStore(this).markUsedToday()
        if (screenOn) startTicking()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                prefs.enabled = false
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_DND -> {
                // Кнопка в уведомлении: включить на час или снять.
                if (prefs.isDnd()) prefs.setDnd(-1) else prefs.setDnd(60)
                return START_STICKY
            }
            ACTION_DEBUG_MOVE -> if (BuildConfig.DEBUG) {
                runCatching { PetMove.valueOf(intent.getStringExtra("move") ?: "") }
                    .onSuccess { move -> handler.postDelayed({ behavior.force(move) }, 6_000L) }
                return START_STICKY
            }
        }
        if (!PermissionHelper.hasOverlayRequired(this)) {
            prefs.stopReason = loc.getString(R.string.overlay_stopped_permission)
            stopSelf()
            return START_NOT_STICKY
        }
        prefs.stopReason = null
        // Перезапуск системой (intent == null) или повторный старт: убедиться, что опрос идёт.
        if (screenOn && !ticking) startTicking()
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        behavior.cancel()
        handler.removeCallbacksAndMessages(null)
        runCatching { unregisterReceiver(screenReceiver) }
        prefs.unregisterListener(prefsListener)
        appPrefs.unregisterListener(appPrefsListener)
        store.unregisterListener(categoryListener)
        perks.unregisterListener(categoryListener)
        hideDismissTarget()
        hideDndMenu()
        savePetOffset()
        detach()
        saveHistory(System.currentTimeMillis())
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Поворот: позиция и смещение питомца — из настроек новой ориентации.
        behavior.cancel()
        hideDndMenu()
        handler.post { applyPosition(currentPkg, restorePet = true); if (shown) behavior.onShown() }
    }

    // ---- foreground-уведомление ----

    private fun startForegroundCompat() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(
                CHANNEL, loc.getString(R.string.overlay_channel), NotificationManager.IMPORTANCE_MIN
            ).apply {
                description = loc.getString(R.string.overlay_channel_desc)
                setShowBadge(false)
            }
            nm.createNotificationChannel(ch)
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val stop = PendingIntent.getService(this, 1, Intent(this, PetOverlayService::class.java).setAction(ACTION_STOP), flags)
        val dnd = PendingIntent.getService(this, 2, Intent(this, PetOverlayService::class.java).setAction(ACTION_DND), flags)
        val dndOn = ::prefs.isInitialized && prefs.isDnd()
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_pet)
            .setContentTitle(loc.getString(R.string.overlay_notif_title))
            .setContentText(loc.getString(if (dndOn) R.string.dnd_notif_active else R.string.overlay_notif_text))
            .setContentIntent(open)
            .addAction(0, loc.getString(if (dndOn) R.string.dnd_off else R.string.dnd_notif_hour), dnd)
            .addAction(0, loc.getString(R.string.overlay_notif_stop), stop)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---- учёт ----

    private fun rebuildLedger(nowMs: Long) {
        val start = UsageRepository.startOfDay(nowMs)
        ledger = DayLedger(start)
        seenEvents.clear()
        ledger.applyAll(repo.events(start, nowMs))
        lastQueryEnd = nowMs
        lastMoodAt = 0L
    }

    /** Дочитать события с прошлого опроса (с нахлёстом и дедупликацией). */
    private fun pollEvents(nowMs: Long) {
        val from = (lastQueryEnd - OVERLAP_MS).coerceAtLeast(ledger.dayStartMs)
        val events = repo.events(from, nowMs)
        // Забыть ключи старше нахлёста — они уже не могут повториться.
        val cutoff = from - OVERLAP_MS
        if (seenEvents.size > 64) seenEvents.entries.removeAll { it.value < cutoff }
        for (e in events) {
            val key = "${e.timestamp}|${e.type}|${e.packageName}|${e.className}"
            if (seenEvents.containsKey(key)) continue
            seenEvents[key] = e.timestamp
            ledger.apply(e)
        }
        lastQueryEnd = nowMs
    }

    /** После старта/разблокировки: если свёртка ничего не держит открытым — восстановить по событиям. */
    private fun restoreForeground(nowMs: Long) {
        if (ledger.foregroundPackage != null) return
        val pkg = repo.currentForeground(nowMs) ?: return
        Log.d(TAG, "restore foreground: $pkg")
        ledger.reopen(pkg, nowMs)
    }

    private fun onTick() {
        val now = System.currentTimeMillis()
        if (!PermissionHelper.hasOverlayRequired(this)) {
            prefs.stopReason = loc.getString(R.string.overlay_stopped_permission)
            stopSelf()
            return
        }
        if (UsageRepository.startOfDay(now) != ledger.dayStartMs) {
            // Полночь или смена часового пояса: новый день, новая свёртка.
            saveHistory(now)
            rebuildLedger(now)
            UnlockStore(this).markUsedToday()
        }
        pollEvents(now)
        if (!screenOn) ledger.closeOpen(now)

        // Смена приложения подтверждается через CONFIRM_MS: короткие системные
        // окна (разрешения, шторка) не дёргают виджет и не запускают реакций.
        val raw = ledger.foregroundPackage
        var changed = false
        val old = currentPkg
        if (raw != currentPkg) {
            if (raw != pendingPkg) {
                pendingPkg = raw
                pendingSince = now
            } else if (now - pendingSince >= CONFIRM_MS) {
                currentPkg = raw
                pendingPkg = null
                changed = true
            }
        } else pendingPkg = null

        var moodChanged = false
        if (now - lastMoodAt >= MOOD_PERIOD_MS) {
            lastMoodAt = now
            val totals = DayMood.totals(ledger.snapshot(now), store)
            val result = DayMood.compute(totals, store, now, perks)
            if (result.state != mood?.state) holder?.pet?.setMood(result.state)
            mood = result
            moodChanged = true
        }
        if (now - lastHistoryAt >= HISTORY_PERIOD_MS) saveHistory(now)

        // «Не беспокоить» истёк — вернуть обычное поведение.
        val dnd = prefs.isDnd(now)
        if (dnd != dndWasActive) {
            dndWasActive = dnd
            applyBehaviorPrefs()
            startForegroundCompat()
            moodChanged = true
        }

        // Сначала показать/создать окна, затем реакция на смену приложения —
        // иначе первая реакция после старта сервиса теряется (окон ещё нет).
        updateVisibility()
        if (changed) {
            Log.d(TAG, "foreground: $old -> $currentPkg show=${shouldShow(currentPkg)}")
            onForegroundChanged(currentPkg, now)
        } else if (moodChanged) {
            updateStatus()
        }
        updateTimer(now)
    }

    private fun onForegroundChanged(new: String?, now: Long) {
        applyPosition(new)
        val p = panel
        if (new != null && p != null) {
            val (icon, label) = appInfo(new)
            p.setApp(icon, label)
            p.setCategory(store.categoryOf(new))
        }
        updateStatus()
        if (new == null || !shown) return
        behavior.onShown()
        react(new, now)
    }

    /**
     * Контекстная реакция на подтверждённое приложение: продуктивное — коротко
     * порадоваться; развлечение до лимита — спокойно, сверх лимита — вздохнуть;
     * нейтральное — спокойно. Не чаще раза в 5–10 с, без очереди, только для
     * последнего приложения; при «Не беспокоить» и во сне — ничего.
     */
    private fun react(pkg: String, now: Long) {
        val pet = holder?.pet ?: return
        if (prefs.isDnd(now) || pet.isSleeping || pet.isStatic) return
        if (now - lastReactionAt < reactionGapMs) return
        val state = mood?.state
        val action = when (store.categoryOf(pkg)) {
            Category.PRODUCTIVE -> if (state == MoodEngine.State.EXHAUSTED) PetAction.LOOK_AROUND
            else if (pet.pet.has(PetAction.CELEBRATE) && Random.nextBoolean()) PetAction.CELEBRATE else PetAction.JUMP
            Category.LAZY -> {
                val totals = DayMood.totals(ledger.snapshot(now), store)
                val over = totals.lazyMs / 60_000 > store.funAllowanceMinutes
                if (over) (if (Random.nextBoolean()) PetAction.ANNOYED else PetAction.SAD) else PetAction.LOOK_AROUND
            }
            Category.NEUTRAL -> PetAction.LOOK_AROUND
            Category.EXCLUDED -> return
        }
        lastReactionAt = now
        reactionGapMs = 5_000L + Random.nextLong(5_000L)
        Log.d(TAG, "react: $action for $pkg")
        behavior.cancel()
        // Грусть — не зацикленная: короткий клип поверх базы, затем обратно.
        if (action == PetAction.SAD) pet.playOnce(PetAction.SAD, 2_400L) else pet.play(action)
        handler.postDelayed({ if (shown && prefs.behavior && !behavior.isMoving) behavior.onShown() }, 3_000L)
    }

    private fun saveHistory(nowMs: Long) {
        lastHistoryAt = nowMs
        val totals = DayMood.totals(ledger.snapshot(nowMs), store)
        val m = mood ?: DayMood.compute(totals, store, nowMs, perks)
        perks.credit(history.todayKey(LocalDate.now()), totals.productiveMs)
        history.save(
            HistoryStore.DayRecord(
                date = history.todayKey(LocalDate.now()),
                productiveMs = totals.productiveMs,
                lazyMs = totals.lazyMs,
                neutralMs = totals.neutralMs,
                totalMs = totals.totalMs,
                mood = m.score
            )
        )
    }

    // ---- иконка и название приложения ----

    private val appLabels = HashMap<String, Pair<Drawable?, String>>()

    private fun appInfo(pkg: String): Pair<Drawable?, String> = appLabels.getOrPut(pkg) {
        runCatching {
            val ai = packageManager.getApplicationInfo(pkg, 0)
            val icon = packageManager.getApplicationIcon(ai)
            val label = packageManager.getApplicationLabel(ai).toString()
            icon to label
        }.getOrDefault(null to pkg.substringAfterLast('.'))
    }

    // ---- статус ----

    /** Короткий статус под таймером и строка настроения (лицо, полоска, %). */
    private fun updateStatus() {
        val v = panel ?: return
        val m = mood ?: return
        val pkg = currentPkg
        val limitMin = store.funAllowanceMinutes
        val lazyMin = m.lazyMin
        val over = lazyMin > limitMin
        val fraction = if (limitMin <= 0) (if (lazyMin > 0) 1f else 0f) else lazyMin.toFloat() / limitMin
        v.setMood(m.state, m.score)

        val p = phrase
        if (p != null && System.currentTimeMillis() < phraseUntil) {
            v.setStatus(p)
            return
        }
        phrase = null
        val text = when {
            pkg == null -> ""
            prefs.isDnd() -> dndLabel()
            m.state == MoodEngine.State.SLEEP -> loc.getString(R.string.status_sleep)
            else -> when (store.categoryOf(pkg)) {
                Category.LAZY -> when {
                    over -> loc.getString(R.string.status_over)
                    limitMin > 0 && fraction >= 0.8f -> loc.getString(R.string.status_near)
                    else -> loc.getString(R.string.status_left, (limitMin - lazyMin).coerceAtLeast(0))
                }
                Category.PRODUCTIVE -> loc.getString(R.string.status_productive)
                Category.EXCLUDED -> loc.getString(R.string.cat_excluded_short)
                else -> MoodText.title(loc, m.state)
            }
        }
        v.setStatus(text)
    }

    private fun dndLabel(): String {
        val until = prefs.dndUntil
        return if (until == OverlayPrefs.DND_FOREVER) loc.getString(R.string.dnd_status)
        else loc.getString(R.string.dnd_status_until, DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(until)))
    }

    // ---- экран ----

    private fun isLocked(): Boolean =
        (getSystemService(KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked

    private fun onScreenOff() {
        handler.removeCallbacks(unlockPoll)
        screenOn = false
        ledger.closeOpen(System.currentTimeMillis())
        stopTicking()
        behavior.onHidden()
        hideDndMenu()
        savePetOffset()
        setShown(false)
    }

    private val unlockPoll = object : Runnable {
        override fun run() {
            if (screenOn) return
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isInteractive) return
            if (isLocked()) {
                handler.postDelayed(this, 1000L)
            } else {
                onScreenOn()
            }
        }
    }

    private fun onScreenOn() {
        if (screenOn) return
        if (isLocked()) {
            // USER_PRESENT приходит не на всех прошивках — дублируем опросом раз в секунду.
            handler.removeCallbacks(unlockPoll)
            handler.postDelayed(unlockPoll, 1000L)
            return
        }
        handler.removeCallbacks(unlockPoll)
        screenOn = true
        val now = System.currentTimeMillis()
        lastQueryEnd = now - OVERLAP_MS
        pollEvents(now)
        // Activity могла остаться на экране без нового RESUMED — восстановить по событиям.
        restoreForeground(now)
        startTicking()
    }

    private fun startTicking() {
        handler.removeCallbacks(tick)
        ticking = true
        handler.post(tick)
    }

    private fun stopTicking() {
        ticking = false
        handler.removeCallbacks(tick)
    }

    // ---- окна ----

    private fun newLp(): WindowManager.LayoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        windowAnimations = 0
    }

    private fun ensureViews() {
        if (panel == null) {
            val p = OverlayView(this, this)
            panel = p
            panelLp = newLp()
            mood?.let { p.setMood(it.state, it.score) }
            currentPkg?.let {
                val (icon, label) = appInfo(it)
                p.setApp(icon, label)
                p.setCategory(store.categoryOf(it))
            }
        }
        if (holder == null) {
            val h = PetHolderView(this, this)
            val def = PetDef.byId(prefs.petId)
            h.pet.setPet(def)
            PetAtlas.retainOnly(def.id)
            mood?.let { h.pet.setMood(it.state) }
            h.pet.onReactionEnd = { phraseUntil = 0L; updateStatus() }
            holder = h
            petLp = newLp()
        }
        applyAppearance()
        applyBehaviorPrefs()
    }

    private fun attach() {
        ensureViews()
        applyPosition(currentPkg, restorePet = !petAttached)
        val p = panel!!
        val h = holder!!
        var ok = true
        // Оба окна добавляются всегда (режим прячет лишнее через visibility).
        // Питомец первым: плашка выше него, и на прогулке он проходит за таймером.
        if (!petAttached) {
            h.visibility = View.GONE
            runCatching { wm.addView(h, petLp) }.onSuccess { petAttached = true }.onFailure { ok = false }
        }
        if (!panelAttached) {
            p.visibility = View.GONE
            runCatching { wm.addView(p, panelLp) }.onSuccess { panelAttached = true }.onFailure { ok = false }
        }
        if (!ok) {
            prefs.stopReason = loc.getString(R.string.overlay_stopped_permission)
            stopSelf()
        }
    }

    private fun detach() {
        panel?.let { if (panelAttached) runCatching { wm.removeViewImmediate(it) } }
        holder?.let { if (petAttached) runCatching { wm.removeViewImmediate(it) } }
        panelAttached = false
        petAttached = false
        panel = null
        holder = null
        panelLp = null
        petLp = null
        shown = false
    }

    /** Видимость окон: по флагу и по режиму (только таймер / только питомец). */
    private fun setShown(visible: Boolean, force: Boolean = false) {
        if (shown == visible && !force) return
        shown = visible
        panel?.visibility = if (visible && prefs.showTimer) View.VISIBLE else View.GONE
        holder?.visibility = if (visible && prefs.showPet) View.VISIBLE else View.GONE
        holder?.pet?.setAnimating(visible && prefs.showPet)
    }

    private fun applyAppearance() {
        val p = panel ?: return
        val h = holder ?: return
        p.applyStyle(prefs.sizeDp, prefs.collapsed, prefs.simple, prefs.showAppName)
        h.applySize(prefs.sizeDp, prefs.collapsed)
        p.alpha = prefs.opacityPercent / 100f
        h.alpha = prefs.opacityPercent / 100f
        panelLp?.width = p.preferredWidth
        // Режим «только таймер» / «только питомец»: лишнее окно прячется.
        setShown(shown, force = true)
        if (!prefs.showPet) behavior.cancel()
        handler.post { applyPosition(currentPkg); if (shown && prefs.showPet) behavior.onShown() }
    }

    private fun applyBehaviorPrefs() {
        behavior.level = prefs.activity
        val want = prefs.behavior && holder != null && !prefs.isDnd()
        if (behavior.enabled != want) behavior.enabled = want
    }

    private fun shouldShow(pkg: String?): Boolean {
        if (!screenOn || pkg == null) return false
        if (pkg == packageName) return false
        if (prefs.isHidden(pkg)) return false
        if (!isLaunchable(pkg)) return false // системные диалоги, permission controller и т.п.
        if (!prefs.showOnLauncher && isLauncher(pkg)) return false
        return true
    }

    private val launchable = HashMap<String, Boolean>()

    private fun isLaunchable(pkg: String): Boolean = launchable.getOrPut(pkg) {
        runCatching { packageManager.getLaunchIntentForPackage(pkg) != null }.getOrDefault(false)
    }

    /** Все пакеты с HOME-активностью, кроме FallbackHome из настроек. */
    private fun isLauncher(pkg: String): Boolean {
        val now = SystemClock.uptimeMillis()
        if (launcherPkgs.isEmpty() || now - launcherCheckedAt > 60_000L) {
            launcherCheckedAt = now
            launcherPkgs = runCatching {
                packageManager.queryIntentActivities(
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
                ).map { it.activityInfo.packageName }.filter { it != "com.android.settings" }.toSet()
            }.getOrDefault(emptySet())
        }
        return launcherPkgs.contains(pkg)
    }

    private fun updateVisibility() {
        val show = shouldShow(currentPkg)
        if (show) {
            if (panel == null || holder == null || !panelAttached || !petAttached) attach()
            if (!shown) {
                setShown(true)
                behavior.onShown()
            }
        } else if (shown) {
            behavior.onHidden()
            hideDndMenu()
            savePetOffset()
            setShown(false)
        }
    }

    private fun updateTimer(nowMs: Long) {
        val p = panel ?: return
        if (!shown) return
        if (phrase != null && nowMs >= phraseUntil) updateStatus()
        val pkg = currentPkg ?: return
        p.timer.text = TimeFormat.short(ledger.totalOf(pkg, nowMs))
    }

    // ---- позиция ----

    private data class Bounds(val left: Int, val top: Int, val right: Int, val bottom: Int) {
        val width get() = right - left
        val height get() = bottom - top
    }

    private fun usableBounds(): Bounds {
        if (Build.VERSION.SDK_INT >= 30) {
            val m = wm.currentWindowMetrics
            val ins = m.windowInsets.getInsetsIgnoringVisibility(
                WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout()
            )
            val b: Rect = m.bounds
            return Bounds(ins.left, ins.top, b.width() - ins.right, b.height() - ins.bottom)
        }
        val dm = resources.displayMetrics
        val statusBar = (24 * dm.density).toInt()
        return Bounds(0, statusBar, dm.widthPixels, dm.heightPixels)
    }

    private val isLandscape: Boolean
        get() = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    private fun measured(v: View, widthPx: Int = WindowManager.LayoutParams.WRAP_CONTENT): Pair<Int, Int> {
        val ws = if (widthPx > 0) View.MeasureSpec.makeMeasureSpec(widthPx, View.MeasureSpec.EXACTLY)
        else View.MeasureSpec.UNSPECIFIED
        v.measure(ws, View.MeasureSpec.UNSPECIFIED)
        return v.measuredWidth to v.measuredHeight
    }

    /** Ширина и высота «пары» питомец+плашка (как одного блока) для расчёта долей экрана. */
    private fun pairSize(): Pair<Int, Int> {
        val p = panel ?: return 0 to 0
        val h = holder ?: return 0 to 0
        val (pw, ph) = if (prefs.showTimer) measured(p, panelLp?.width ?: 0) else 0 to 0
        val (hw, hh) = if (prefs.showPet) measured(h) else 0 to 0
        val w = pw + hw + (if (prefs.showTimer && prefs.showPet) GAP_PX else 0)
        return w to maxOf(ph, hh)
    }

    /** Зазор между питомцем и плашкой: питомец стоит рядом, не поверх. */
    private val GAP_PX: Int get() = dp(4)
    /** Отступ вокруг плашки, в который питомец не заходит. */
    private val OBSTACLE_MARGIN_PX: Int get() = dp(6)

    /**
     * Домашняя точка из настроек (доли экрана) → координаты плашки и место
     * питомца рядом (снаружи, ближе к краю). [restorePet] — поставить питомца
     * на сохранённое смещение (после старта/поворота), иначе — где он есть.
     */
    private fun applyPosition(pkg: String?, restorePet: Boolean = false) {
        val p = panel ?: return
        val h = holder ?: return
        val plp = panelLp ?: return
        val hlp = petLp ?: return
        val b = usableBounds()
        val land = isLandscape
        val pos = prefs.position(pkg, land) ?: OverlayPrefs.Pos(0f, 0.12f)
        val petOnLeft = pos.xFrac <= 0.5f
        val (w, hgt) = pairSize()
        val x = (b.left + pos.xFrac * (b.width - w)).toInt().coerceIn(b.left, (b.right - w).coerceAtLeast(b.left))
        val y = (b.top + pos.yFrac * (b.height - hgt)).toInt().coerceIn(b.top, (b.bottom - hgt).coerceAtLeast(b.top))
        val (pw, ph) = if (prefs.showTimer) measured(p, plp.width) else 0 to 0
        val (hw, hh) = measured(h)
        // Плашка ближе к центру, питомец снаружи с зазором; вертикально — по центру пары.
        val panelX = if (!prefs.showPet) x else if (petOnLeft) x + hw + GAP_PX else x
        homeX = panelX
        homeY = y + (hgt - ph) / 2
        petRestX = when {
            !prefs.showTimer -> x
            petOnLeft -> x
            else -> x + pw + GAP_PX
        }
        petRestY = y + (hgt - hh) / 2
        plp.x = homeX
        plp.y = homeY
        val wasHome = abs(hlp.x - petRestX) <= dp(12) && abs(hlp.y - petRestY) <= dp(12)
        if (restorePet) {
            val off = (prefs.petOffset(land) * b.width).roundToInt()
            hlp.x = (petRestX + off).coerceIn(petRange())
            hlp.y = petRestY
        } else if (!behavior.isMoving && wasHome) {
            hlp.x = petRestX
            hlp.y = petRestY
        }
        // Гуляющего питомца не трогаем: маршрут домой он построит сам.
        if (panelAttached) runCatching { wm.updateViewLayout(p, plp) }
        if (petAttached) runCatching { wm.updateViewLayout(h, hlp) }
    }

    private fun petYRange(): IntRange {
        val h = holder ?: return 0..0
        val b = usableBounds()
        val (_, hh) = measured(h)
        return b.top..(b.bottom - hh).coerceAtLeast(b.top)
    }

    private fun petRange(): IntRange {
        val h = holder ?: return 0..0
        val b = usableBounds()
        val (w, _) = measured(h)
        return b.left..(b.right - w).coerceAtLeast(b.left)
    }

    private fun savePosition() {
        if (panel == null || holder == null) return
        val b = usableBounds()
        val (w, hgt) = pairSize()
        val xr = (b.width - w).coerceAtLeast(1)
        val yr = (b.height - hgt).coerceAtLeast(1)
        // Левый край пары: плашка или питомец — что левее.
        val left = if (!prefs.showPet) homeX else if (!prefs.showTimer) petRestX else minOf(homeX, petRestX)
        val top = if (!prefs.showPet) homeY else if (!prefs.showTimer) petRestY else minOf(homeY, petRestY)
        prefs.savePosition(
            currentPkg, isLandscape,
            OverlayPrefs.Pos(
                ((left - b.left).toFloat() / xr).coerceIn(0f, 1f),
                ((top - b.top).toFloat() / yr).coerceIn(0f, 1f)
            )
        )
    }

    /** Смещение питомца от дома — в долях ширины экрана, отдельно для ориентации. */
    private fun savePetOffset() {
        val hlp = petLp ?: return
        if (holder == null || !petAttached) return
        val w = usableBounds().width.coerceAtLeast(1)
        prefs.savePetOffset(isLandscape, (hlp.x - petRestX).toFloat() / w)
    }

    // ---- PetBehavior.Host ----

    override fun pet(): PetSpriteView? = holder?.pet

    override fun canAct(): Boolean = screenOn && shown && petAttached && prefs.showPet && !dragging

    override fun petX(): Int = petLp?.x ?: 0

    override fun petY(): Int = petLp?.y ?: 0

    override fun restX(): Int = petRestX

    override fun restY(): Int = petRestY

    override fun xRange(): IntRange = petRange()

    override fun yRange(): IntRange = petYRange()

    override fun screenWidth(): Int = usableBounds().width

    override fun petWidth(): Int = holder?.let { if (it.width > 0) it.width else measured(it).first } ?: 0

    override fun petHeight(): Int = holder?.let { if (it.height > 0) it.height else measured(it).second } ?: 0

    /** Плашка с отступом — препятствие для прогулок; в режиме «только питомец» её нет. */
    override fun obstacle(): Rect? {
        if (!prefs.showTimer || !panelAttached) return null
        val p = panel ?: return null
        val lp = panelLp ?: return null
        val (pw, ph) = if (p.width > 0) p.width to p.height else measured(p, lp.width)
        val m = OBSTACLE_MARGIN_PX
        return Rect(lp.x - m, lp.y - m, lp.x + pw + m, lp.y + ph + m)
    }

    override fun petOnLeft(): Boolean {
        val b = usableBounds()
        return petRestX - b.left < b.right - (petRestX + petWidth())
    }

    override fun setPetPos(x: Int, y: Int) {
        val h = holder ?: return
        val lp = petLp ?: return
        lp.x = x
        lp.y = y
        if (petAttached) runCatching { wm.updateViewLayout(h, lp) }.onFailure { Log.w(TAG, "setPetPos failed", it) }
    }

    override fun mood(): MoodEngine.State = mood?.state ?: MoodEngine.State.CONTENT

    override fun temper(): PetDef.Temper = holder?.pet?.pet?.temper ?: PetDef.Temper.NORMAL

    override fun onPetRest() = savePetOffset()

    // ---- жесты: плашка ----

    override fun onDragStart() {
        val lp = panelLp ?: return
        behavior.onUserDrag()
        hideDndMenu()
        dragging = true
        draggingPet = false
        dragStartX = lp.x
        dragStartY = lp.y
        // Питомец, стоящий дома, едет вместе с плашкой; гуляющий вернётся сам.
        petFollows = abs((petLp?.x ?: petRestX) - petRestX) <= dp(12) && abs((petLp?.y ?: petRestY) - petRestY) <= dp(12)
        overDismiss = false
        showDismissTarget()
    }

    override fun onDragTo(rawX: Float, rawY: Float, downX: Float, downY: Float) {
        val p = panel ?: return
        val lp = panelLp ?: return
        if (!dragging) onDragStart()
        val b = usableBounds()
        val (pw, ph) = measured(p, lp.width)
        val (hw, hh) = holder?.let { measured(it) } ?: (0 to 0)
        val nx = (dragStartX + (rawX - downX)).toInt()
        val ny = (dragStartY + (rawY - downY)).toInt()
        lp.x = nx.coerceIn(b.left, (b.right - pw).coerceAtLeast(b.left))
        lp.y = ny.coerceIn(b.top, (b.bottom - ph).coerceAtLeast(b.top))
        if (panelAttached) runCatching { wm.updateViewLayout(p, lp) }
        homeX = lp.x
        homeY = lp.y
        if (petFollows && prefs.showPet) {
            // Сторона питомца по положению плашки на экране.
            val onLeft = lp.x + pw / 2 <= b.left + b.width / 2
            petRestX = (if (onLeft) lp.x - hw - GAP_PX else lp.x + pw + GAP_PX)
                .coerceIn(b.left, (b.right - hw).coerceAtLeast(b.left))
            petRestY = lp.y + (ph - hh) / 2
            setPetPos(petRestX, petRestY)
        }
        checkDismiss()
    }

    override fun onDragEnd() {
        dragging = false
        val dismiss = overDismiss
        hideDismissTarget()
        if (dismiss) {
            // Убрать питомца: выключаем оверлей, включить можно в приложении.
            Toast.makeText(loc, R.string.overlay_dismissed_toast, Toast.LENGTH_LONG).show()
            prefs.enabled = false
            stopSelf()
            return
        }
        finishHomeMove()
    }

    /** Дом переехал: пересчитать пару, сохранить, питомца (если ушёл) позвать домой. */
    private fun finishHomeMove() {
        val p = panel ?: return
        val plp = panelLp ?: return
        val b = usableBounds()
        val (pw, _) = measured(p, plp.width)
        val (hw, _) = holder?.let { measured(it) } ?: (0 to 0)
        val (w, _) = pairSize()
        // Левый край пары по положению плашки и стороне питомца.
        val onLeft = if (!prefs.showPet) false else if (!prefs.showTimer) true else
            (plp.x + pw / 2 <= b.left + b.width / 2)
        val left = when {
            !prefs.showPet -> plp.x
            !prefs.showTimer -> petLp?.x ?: plp.x
            onLeft -> plp.x - hw - GAP_PX
            else -> plp.x
        }
        val xr = (b.width - w).coerceAtLeast(1)
        val (_, hgt) = pairSize()
        val yr = (b.height - hgt).coerceAtLeast(1)
        val top = if (!prefs.showTimer) (petLp?.y ?: plp.y) else plp.y - (hgt - measured(p, plp.width).second) / 2
        prefs.savePosition(
            currentPkg, isLandscape,
            OverlayPrefs.Pos(((left - b.left).toFloat() / xr).coerceIn(0f, 1f), ((top - b.top).toFloat() / yr).coerceIn(0f, 1f))
        )
        applyPosition(currentPkg)
        if (!petFollows) behavior.homeMoved() else savePetOffset()
    }

    // ---- жесты: питомец ----

    override fun onPetDragStart() {
        val lp = petLp ?: return
        behavior.onUserDrag()
        hideDndMenu()
        dragging = true
        draggingPet = true
        dragStartX = lp.x
        dragStartY = lp.y
        overDismiss = false
        // В режиме «только питомец» перенос питомца — перенос дома, с крестиком.
        if (!prefs.showTimer) showDismissTarget()
    }

    override fun onPetDragTo(rawX: Float, rawY: Float, downX: Float, downY: Float) {
        val h = holder ?: return
        val lp = petLp ?: return
        if (!dragging) onPetDragStart()
        val b = usableBounds()
        val (hw, hh) = measured(h)
        lp.x = (dragStartX + (rawX - downX)).toInt().coerceIn(b.left, (b.right - hw).coerceAtLeast(b.left))
        lp.y = (dragStartY + (rawY - downY)).toInt().coerceIn(b.top, (b.bottom - hh).coerceAtLeast(b.top))
        if (petAttached) runCatching { wm.updateViewLayout(h, lp) }
        if (!prefs.showTimer) checkDismiss()
    }

    override fun onPetDragEnd() {
        dragging = false
        draggingPet = false
        val dismiss = overDismiss
        hideDismissTarget()
        if (dismiss) {
            Toast.makeText(loc, R.string.overlay_dismissed_toast, Toast.LENGTH_LONG).show()
            prefs.enabled = false
            stopSelf()
            return
        }
        val lp = petLp ?: return
        if (!prefs.showTimer) {
            // Дом = там, где оставили питомца.
            petRestX = lp.x
            petRestY = lp.y
            val b = usableBounds()
            val (hw, hh) = holder?.let { measured(it) } ?: (0 to 0)
            prefs.savePosition(
                currentPkg, isLandscape,
                OverlayPrefs.Pos(
                    ((lp.x - b.left).toFloat() / (b.width - hw).coerceAtLeast(1)).coerceIn(0f, 1f),
                    ((lp.y - b.top).toFloat() / (b.height - hh).coerceAtLeast(1)).coerceIn(0f, 1f)
                )
            )
            prefs.savePetOffset(isLandscape, 0f)
            applyPosition(currentPkg)
        } else {
            // Питомца отнесли в сторону: домой вернётся сам, в обход плашки.
            savePetOffset()
        }
    }

    private fun checkDismiss() {
        val (cx, cy) = dismissCenter()
        val (px, py) = petCenter()
        val d = dp(DISMISS_RADIUS_DP)
        val hot = abs(px - cx) < d && abs(py - cy) < d
        if (hot != overDismiss) {
            overDismiss = hot
            dismissTarget?.setHot(hot)
        }
    }

    private fun petCenter(): Pair<Float, Float> {
        val lp = (if (draggingPet || !prefs.showTimer) petLp else panelLp) ?: return 0f to 0f
        val v = (if (draggingPet || !prefs.showTimer) holder else panel) ?: return 0f to 0f
        return (lp.x + v.width / 2f) to (lp.y + v.height / 2f)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun dismissCenter(): Pair<Float, Float> {
        val b = usableBounds()
        return (b.left + b.width / 2f) to (b.bottom - dp(DISMISS_BOTTOM_DP) - dp(DISMISS_SIZE_DP) / 2f)
    }

    private fun showDismissTarget() {
        if (dismissTarget != null) return
        val t = DismissTargetView(this)
        val size = dp(DISMISS_SIZE_DP)
        val (cx, cy) = dismissCenter()
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (cx - size / 2f).toInt()
        lp.y = (cy - size / 2f).toInt()
        lp.windowAnimations = 0
        runCatching { wm.addView(t, lp) }.onSuccess {
            dismissTarget = t
            t.alpha = 0f
            t.animate().alpha(1f).setDuration(150).start()
        }
    }

    private fun hideDismissTarget() {
        val t = dismissTarget ?: return
        dismissTarget = null
        runCatching { wm.removeViewImmediate(t) }
    }

    override fun onToggleCollapse() {
        prefs.collapsed = !prefs.collapsed
    }

    override fun onPetTap() {
        val h = holder ?: return
        behavior.cancel()
        val tap = h.pet.tap()
        val state = mood?.state ?: MoodEngine.State.CONTENT
        phrase = PetTalk.onTap(loc, state, tap)
        phraseUntil = System.currentTimeMillis() + 2200L
        updateStatus()
        handler.postDelayed({ updateStatus(); if (prefs.behavior && shown) behavior.onShown() }, 2300L)
    }

    /** Двойной тап по питомцу — меню «Не беспокоить». */
    override fun onPetDoubleTap() {
        if (dndMenu != null) { hideDndMenu(); return }
        val h = holder ?: return
        val hlp = petLp ?: return
        val menu = DndMenuView(loc, prefs.isDnd()) { minutes ->
            prefs.setDnd(minutes)
            hideDndMenu()
        }
        val b = usableBounds()
        val (mw, mh) = measured(menu)
        val lp = newLp()
        lp.x = (hlp.x + h.width / 2 - mw / 2).coerceIn(b.left, (b.right - mw).coerceAtLeast(b.left))
        lp.y = (hlp.y + h.height + dp(2)).let { if (it + mh > b.bottom) hlp.y - mh - dp(2) else it }
        runCatching { wm.addView(menu, lp) }.onSuccess {
            dndMenu = menu
            handler.postDelayed(hideDnd, 6_000L)
        }
    }

    private val hideDnd = Runnable { hideDndMenu() }

    private fun hideDndMenu() {
        handler.removeCallbacks(hideDnd)
        val m = dndMenu ?: return
        dndMenu = null
        runCatching { wm.removeViewImmediate(m) }
    }

    /** Тап по плашке — открыть приложение. */
    override fun onOpenApp() {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { startActivity(i) }
    }

    companion object {
        private const val TAG = "PetOverlay"
        const val ACTION_STOP = "com.timeoverlay.pet.overlay.STOP"
        const val ACTION_DND = "com.timeoverlay.pet.overlay.DND"
        const val ACTION_DEBUG_MOVE = "com.timeoverlay.pet.overlay.DEBUG_MOVE"
        private const val CHANNEL = "overlay"
        private const val NOTIF_ID = 1
        private const val OVERLAP_MS = 2_500L
        private const val CONFIRM_MS = 650L
        private const val DISMISS_SIZE_DP = 64
        private const val DISMISS_BOTTOM_DP = 40
        private const val DISMISS_RADIUS_DP = 56
        private const val MOOD_PERIOD_MS = 20_000L
        private const val HISTORY_PERIOD_MS = 60_000L

        @Volatile var running = false
            private set

        fun start(context: Context) {
            val i = Intent(context, PetOverlayService::class.java)
            ContextCompat.startForegroundService(context, i)
        }

        fun debugMove(context: Context, move: String) {
            val i = Intent(context, PetOverlayService::class.java).setAction(ACTION_DEBUG_MOVE).putExtra("move", move)
            ContextCompat.startForegroundService(context, i)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, PetOverlayService::class.java))
        }
    }
}
