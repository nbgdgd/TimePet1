package com.timeoverlay.pet.ui

import android.content.res.ColorStateList
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.timeoverlay.pet.R
import com.timeoverlay.pet.mood.DayMood
import com.timeoverlay.pet.mood.MoodEngine
import com.timeoverlay.pet.mood.MoodText
import com.timeoverlay.pet.overlay.LimitBarView

/**
 * Четыре строки «подпись, иконка, слово, шкала, число»: настроение, состояние,
 * продуктивность, лимит развлечений (layout `item_kv_row`). Живут на вкладке
 * «Аналитика» за день.
 */
object MoodRows {

    fun labels(root: View) {
        label(root.findViewById(R.id.rowMood), R.string.tile_mood)
        label(root.findViewById(R.id.rowState), R.string.tile_state)
        label(root.findViewById(R.id.rowScore), R.string.tile_productivity)
        label(root.findViewById(R.id.rowLimit), R.string.home_limit_row)
    }

    private fun label(row: View, res: Int) {
        row.findViewById<TextView>(R.id.kvLabel).setText(res)
    }

    fun bind(root: View, r: MoodEngine.Result?, state: MoodEngine.State, score: Int, t: DayMood.Totals, limitMin: Int) {
        val ctx = root.context
        val track = ctx.themeColor(R.attr.tp_track)
        val moodColor = ContextCompat.getColor(ctx, MoodText.colorRes(state))
        // Настроение: лицо, слово, шкала 0..100 и процент.
        val mood = root.findViewById<View>(R.id.rowMood)
        mood.findViewById<TextView>(R.id.kvValue).text = MoodText.title(ctx, state)
        icon(mood, MoodText.faceRes(state), moodColor)
        bar(mood, if (r == null) 0f else r.score / 100f, moodColor, track, if (r == null) "-" else "${r.score}%")
        // Состояние: лапа в цвете состояния, слово, шкала сил 0..5.
        val st = root.findViewById<View>(R.id.rowState)
        st.findViewById<TextView>(R.id.kvValue).text = MoodText.stateWord(ctx, state)
        icon(st, R.drawable.ic_pet, moodColor)
        val energy = MoodText.energyLevel(state)
        bar(st, energy / 5f, moodColor, track, "$energy / 5")
        // Продуктивность: зелёная шкала.
        val sc = root.findViewById<View>(R.id.rowScore)
        sc.findViewById<TextView>(R.id.kvValue).text = ""
        bar(sc, if (score < 0) 0f else score / 100f, ContextCompat.getColor(ctx, R.color.productive), track, if (score < 0) "-" else "$score%")
        // Лимит развлечений: красная шкала «сколько из лимита».
        val lazyMin = (t.lazyMs / 60_000L).toInt()
        val lim = root.findViewById<View>(R.id.rowLimit)
        lim.findViewById<TextView>(R.id.kvValue).text = ""
        bar(
            lim, if (limitMin <= 0) (if (lazyMin > 0) 1f else 0f) else lazyMin.toFloat() / limitMin,
            ContextCompat.getColor(ctx, R.color.lazy), track, ctx.getString(R.string.home_limit_value, lazyMin, limitMin)
        )
    }

    private fun icon(row: View, res: Int, color: Int) {
        row.findViewById<ImageView>(R.id.kvIcon).apply {
            visibility = View.VISIBLE
            setImageResource(res)
            imageTintList = ColorStateList.valueOf(color)
        }
    }

    private fun bar(row: View, fraction: Float, color: Int, track: Int, number: String) {
        row.findViewById<LimitBarView>(R.id.kvBar).apply {
            visibility = View.VISIBLE
            setTrackColor(track)
            set(fraction, color)
        }
        row.findViewById<TextView>(R.id.kvNumber).apply {
            visibility = View.VISIBLE
            text = number
        }
    }
}
