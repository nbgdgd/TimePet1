package com.timeoverlay.pet.data

import android.content.Context
import android.content.SharedPreferences
import com.timeoverlay.pet.mood.DayMood
import java.util.Calendar

/**
 * Очки и магазин.
 *
 * Очки: 1 за каждые полные 10 минут в продуктивных приложениях. Начисление
 * идемпотентно: хранится, сколько минут за сегодня уже засчитано, поэтому
 * сервис и главный экран могут вызывать [credit] сколько угодно раз.
 *
 * Покупки:
 * - [Perk.ENERGY_DRINK] — питомец не спит этой ночью (до ближайших 07:00);
 * - [Perk.NIGHT_OFF] — ночной режим выключен на 7 дней;
 * - [Perk.TREAT] — +10 к настроению до конца дня.
 *
 * Всё локально, SharedPreferences "perks".
 */
class PerksStore(context: Context) {

    enum class Perk(val cost: Int) {
        TREAT(10), ENERGY_DRINK(15), NIGHT_OFF(60)
    }

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    val balance: Int get() = prefs.getInt(KEY_BALANCE, 0)

    /** Засчитать продуктивное время за день [dateKey] (мс с полуночи); вернуть, сколько очков добавилось. */
    fun credit(dateKey: String, productiveMs: Long): Int {
        val chunks = (productiveMs / CHUNK_MS).toInt()
        val sameDay = prefs.getString(KEY_CREDIT_DATE, null) == dateKey
        val credited = if (sameDay) prefs.getInt(KEY_CREDIT_CHUNKS, 0) else 0
        val delta = chunks - credited
        if (delta <= 0 && sameDay) return 0
        prefs.edit()
            .putString(KEY_CREDIT_DATE, dateKey)
            .putInt(KEY_CREDIT_CHUNKS, chunks)
            .putInt(KEY_BALANCE, balance + delta.coerceAtLeast(0))
            .apply()
        return delta.coerceAtLeast(0)
    }

    /** Ночной режим отменён: энергетик на эту ночь или выключенная ночь. */
    fun isAwake(nowMs: Long = System.currentTimeMillis()): Boolean =
        nowMs < prefs.getLong(KEY_AWAKE_UNTIL, 0L) || nowMs < prefs.getLong(KEY_NIGHT_OFF_UNTIL, 0L)

    fun energyActive(nowMs: Long = System.currentTimeMillis()): Boolean = nowMs < prefs.getLong(KEY_AWAKE_UNTIL, 0L)

    /** До какого момента выключен ночной режим (0 — не выключен). */
    fun nightOffUntil(nowMs: Long = System.currentTimeMillis()): Long =
        prefs.getLong(KEY_NIGHT_OFF_UNTIL, 0L).takeIf { it > nowMs } ?: 0L

    /** Прибавка к настроению за сегодня. */
    fun moodBonus(nowMs: Long = System.currentTimeMillis()): Int =
        if (prefs.getString(KEY_TREAT_DATE, null) == dayKey(nowMs)) TREAT_BONUS else 0

    fun isActive(perk: Perk, nowMs: Long = System.currentTimeMillis()): Boolean = when (perk) {
        Perk.TREAT -> moodBonus(nowMs) > 0
        Perk.ENERGY_DRINK -> energyActive(nowMs)
        Perk.NIGHT_OFF -> nightOffUntil(nowMs) > 0L
    }

    fun canBuy(perk: Perk, nowMs: Long = System.currentTimeMillis()): Boolean =
        balance >= perk.cost && !isActive(perk, nowMs)

    /** Купить; false — не хватает очков или уже действует. */
    fun buy(perk: Perk, nowMs: Long = System.currentTimeMillis()): Boolean {
        if (!canBuy(perk, nowMs)) return false
        val e = prefs.edit().putInt(KEY_BALANCE, balance - perk.cost)
        when (perk) {
            Perk.TREAT -> e.putString(KEY_TREAT_DATE, dayKey(nowMs))
            Perk.ENERGY_DRINK -> e.putLong(KEY_AWAKE_UNTIL, nextMorning(nowMs))
            Perk.NIGHT_OFF -> e.putLong(KEY_NIGHT_OFF_UNTIL, nowMs + 7L * 24 * 3600_000)
        }
        e.apply()
        return true
    }

    fun registerListener(l: SharedPreferences.OnSharedPreferenceChangeListener) =
        prefs.registerOnSharedPreferenceChangeListener(l)

    fun unregisterListener(l: SharedPreferences.OnSharedPreferenceChangeListener) =
        prefs.unregisterOnSharedPreferenceChangeListener(l)

    private fun dayKey(nowMs: Long): String {
        val c = Calendar.getInstance().apply { timeInMillis = nowMs }
        return "%04d-%02d-%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    /** Ближайшие 07:00 после [nowMs] — конец ночи для питомца. */
    private fun nextMorning(nowMs: Long): Long {
        val c = Calendar.getInstance().apply {
            timeInMillis = nowMs
            set(Calendar.HOUR_OF_DAY, DayMood.NIGHT_END_HOUR)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (c.timeInMillis <= nowMs) c.add(Calendar.DAY_OF_MONTH, 1)
        return c.timeInMillis
    }

    companion object {
        private const val PREFS = "perks"
        private const val KEY_BALANCE = "balance"
        private const val KEY_CREDIT_DATE = "credit_date"
        private const val KEY_CREDIT_CHUNKS = "credit_chunks"
        private const val KEY_AWAKE_UNTIL = "awake_until"
        private const val KEY_NIGHT_OFF_UNTIL = "night_off_until"
        private const val KEY_TREAT_DATE = "treat_date"
        const val CHUNK_MS = 10 * 60_000L
        const val TREAT_BONUS = 10
    }
}
