package com.timeoverlay.pet.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import com.timeoverlay.pet.R

/**
 * Быстрое меню «Не беспокоить» по двойному тапу на питомце: своё маленькое
 * окно под питомцем. Пункты: 30 минут, 1 час, до отключения; при активном
 * режиме — «Выкл». Само прячется через несколько секунд.
 */
@SuppressLint("ViewConstructor")
class DndMenuView(context: Context, active: Boolean, private val onPick: (minutes: Int) -> Unit) :
    LinearLayout(context) {

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(0xF0202127.toInt())
        }
        setPadding(dp(8), dp(6), dp(8), dp(6))
        val title = TextView(context)
        title.text = context.getString(R.string.dnd_short)
        title.setTextColor(0x9EFFFFFF.toInt())
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        title.includeFontPadding = false
        addView(title, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(6) })
        if (active) chip(context.getString(R.string.dnd_off), -1)
        chip(context.getString(R.string.dnd_30), 30)
        chip(context.getString(R.string.dnd_60), 60)
        chip(context.getString(R.string.dnd_forever_short), 0)
    }

    private fun chip(text: String, minutes: Int) {
        val t = TextView(context)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        t.includeFontPadding = false
        t.setPadding(dp(9), dp(6), dp(9), dp(6))
        t.background = GradientDrawable().apply {
            cornerRadius = dp(9).toFloat()
            setColor(if (minutes < 0) 0xFF5B4AD1.toInt() else 0x33FFFFFF)
        }
        t.setOnClickListener { onPick(minutes) }
        addView(t, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { marginStart = dp(4) })
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
}
