package com.timeoverlay.pet.data

/**
 * Посекундный учёт активного времени приложений за один день.
 *
 * Чистая логика без Android: на вход подаются события UsageEvents
 * (тип + пакет + время), на выходе — накопленное время каждого пакета.
 * Одна и та же свёртка используется оверлеем (инкрементально, раз в секунду)
 * и экранами приложения (полная свёртка с полуночи), поэтому цифры совпадают.
 *
 * Правила:
 * - Время идёт только у одного пакета — того, чья Activity последней
 *   получила RESUMED. Переключение A → B закрывает интервал A и открывает B.
 * - У пакета может быть несколько активных Activity сразу (двухпанельные
 *   Настройки на планшете, диалоги): интервал закрывается, когда PAUSED /
 *   STOPPED получили все они, а не первая попавшаяся.
 * - Выключение экрана, блокировка и выключение устройства закрывают
 *   интервал принудительно — фон, музыка при погашенном экране и экран
 *   блокировки не считаются.
 * - Возврат в приложение продолжает его дневную сумму, а не начинает с нуля.
 * - Двойного учёта нет: интервалы одного пакета не пересекаются.
 */
class DayLedger(val dayStartMs: Long) {

    /** Минимальный набор полей события, чтобы не зависеть от android.* в тестах. */
    data class Event(
        val type: Int,
        val packageName: String?,
        val timestamp: Long,
        val className: String? = null
    )

    private val closed = HashMap<String, Long>()
    private var openPackage: String? = null
    private var openSince: Long = 0L
    /** Activity открытого пакета, которые сейчас RESUMED. */
    private val openActivities = HashSet<String>()

    /** Пакет, который сейчас на экране (по последним событиям), или null. */
    val foregroundPackage: String? get() = openPackage

    /** Начало текущего открытого интервала (для «сессии»), или 0. */
    val foregroundSince: Long get() = if (openPackage != null) openSince else 0L

    fun apply(e: Event) {
        val ts = e.timestamp.coerceAtLeast(dayStartMs)
        when (e.type) {
            ACTIVITY_RESUMED -> {
                val pkg = e.packageName ?: return
                val cls = e.className ?: pkg
                if (openPackage == pkg) {
                    openActivities.add(cls) // ещё одна Activity того же пакета
                    return
                }
                close(ts)
                openPackage = pkg
                openSince = ts
                openActivities.add(cls)
            }
            ACTIVITY_PAUSED, ACTIVITY_STOPPED -> {
                if (e.packageName == null || e.packageName != openPackage) return
                openActivities.remove(e.className ?: e.packageName)
                if (openActivities.isEmpty()) close(ts)
            }
            SCREEN_NON_INTERACTIVE, KEYGUARD_SHOWN, DEVICE_SHUTDOWN -> close(ts)
            else -> Unit
        }
    }

    fun applyAll(events: Iterable<Event>) = events.forEach(::apply)

    /** Принудительно закрыть открытый интервал (например, экран погас, а события ещё не пришли). */
    fun closeOpen(atMs: Long) = close(atMs)

    /**
     * Открыть интервал пакета вручную (после разблокировки RESUMED может не
     * прийти, если Activity осталась на экране). Ничего не делает, если
     * какой-то интервал уже открыт.
     */
    fun reopen(packageName: String, atMs: Long) {
        if (openPackage != null) return
        openPackage = packageName
        openSince = atMs.coerceAtLeast(dayStartMs)
        openActivities.add(packageName)
    }

    /** Накопленное сегодня время пакета, включая идущий интервал. */
    fun totalOf(packageName: String, nowMs: Long): Long {
        val base = closed[packageName] ?: 0L
        return if (openPackage == packageName) base + live(nowMs) else base
    }

    /** Все пакеты с их временем на момент [nowMs] (идущий интервал учтён). */
    fun snapshot(nowMs: Long): Map<String, Long> {
        val out = HashMap(closed)
        val open = openPackage
        if (open != null) out[open] = (out[open] ?: 0L) + live(nowMs)
        return out
    }

    fun totalMillis(nowMs: Long): Long = snapshot(nowMs).values.sum()

    private fun live(nowMs: Long): Long = (nowMs - openSince).coerceAtLeast(0L)

    private fun close(atMs: Long) {
        val pkg = openPackage ?: return
        val dur = (atMs - openSince).coerceAtLeast(0L)
        if (dur > 0) closed[pkg] = (closed[pkg] ?: 0L) + dur
        openPackage = null
        openActivities.clear()
    }

    companion object {
        // Значения UsageEvents.Event.* — литералами, чтобы не зависеть от API-уровня:
        // константы ACTIVITY_* появились в 29, но числа те же, что у MOVE_TO_*.
        const val ACTIVITY_RESUMED = 1        // MOVE_TO_FOREGROUND
        const val ACTIVITY_PAUSED = 2         // MOVE_TO_BACKGROUND
        const val SCREEN_INTERACTIVE = 15
        const val SCREEN_NON_INTERACTIVE = 16
        const val KEYGUARD_SHOWN = 17
        const val KEYGUARD_HIDDEN = 18
        const val ACTIVITY_STOPPED = 23
        const val DEVICE_SHUTDOWN = 26
    }
}
