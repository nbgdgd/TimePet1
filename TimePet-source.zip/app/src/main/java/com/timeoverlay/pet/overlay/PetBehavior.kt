package com.timeoverlay.pet.overlay

import android.graphics.Point
import android.graphics.Rect
import android.os.Handler
import android.os.SystemClock
import android.util.Log
import com.timeoverlay.pet.mood.MoodEngine
import com.timeoverlay.pet.pet.PetAction
import com.timeoverlay.pet.pet.PetDef
import com.timeoverlay.pet.pet.PetMove
import com.timeoverlay.pet.ui.PetSpriteView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Самостоятельная жизнь питомца поверх приложений — по образцу настольных
 * питомцев (Shimeji): двигается только питомец, таймер стоит на месте.
 *
 * Цикл: отдых рядом с таймером → прогулка (несколько отрезков ходьбы или бега
 * с паузами и короткими действиями: оглядеться, сесть, прыгнуть, помахать,
 * потянуться, прилечь/задремать) → самостоятельное возвращение ходьбой или
 * бегом к таймеру (рядом, не поверх) → отдых. Прогулка 10–40 секунд,
 * паузы 1–5 с.
 *
 * Плашка таймера с отступом — препятствие ([Host.obstacle]): путь, который
 * пересекает её на высоте дома, прокладывается в обход — спуститься под
 * плашку (или подняться над ней), пройти, вернуться на свою высоту.
 * Маршрут строится заново при каждом отрезке, поэтому перенос таймера и
 * поворот экрана учитываются сами.
 *
 * Скорость постоянна на отрезке и совпадает с шагом кадров ходьбы/бега,
 * на концах — плавный разгон и торможение; разворот — смена кадров и
 * короткая пауза. Цели — в полосе ±45 % ширины экрана от дома, внутри границ,
 * края предпочтительнее; ячейка плашки исключается.
 *
 * Характер ([PetDef.Temper]) задаёт частоту и длину прогулок, скорость,
 * долю бега, прыжки, склонность к отдыху и дрёме. Уровень активности
 * (настройка) и настроение — множители интервала. Во время ручного
 * перетаскивания и минуту после него автоматика стоит; «Не беспокоить» —
 * прогулки прекращаются, ушедший питомец возвращается домой.
 *
 * Не постоянный цикл: между прогулками одна отложенная задача, шаги
 * по 33 мс только пока питомец движется.
 */
class PetBehavior(private val handler: Handler, private val host: Host) {

    interface Host {
        fun pet(): PetSpriteView?
        /** Питомец виден, экран включён, пользователь его не тащит. */
        fun canAct(): Boolean
        /** Текущее положение окна питомца. */
        fun petX(): Int
        fun petY(): Int
        /** Домашняя точка питомца (рядом с таймером). */
        fun restX(): Int
        fun restY(): Int
        /** Допустимые диапазоны положения окна питомца. */
        fun xRange(): IntRange
        fun yRange(): IntRange
        fun screenWidth(): Int
        fun petWidth(): Int
        fun petHeight(): Int
        /** Ближайший к дому край — левый. */
        fun petOnLeft(): Boolean
        /** Плашка таймера с отступом (в координатах окон) или null, если её нет. */
        fun obstacle(): Rect?
        fun setPetPos(x: Int, y: Int)
        fun mood(): MoodEngine.State
        fun temper(): PetDef.Temper
        /** Питомец остановился (для сохранения позиции). */
        fun onPetRest()
    }

    var enabled = false
        set(v) {
            field = v
            if (v) schedule(firstDelay()) else stopAndReturn()
        }

    /** 0 спокойный, 1 обычный, 2 активный. */
    var level = 1

    private var moving = false
    private var pausedUntil = 0L
    private var density = 1f
    private var facingRight = true

    private val next = Runnable { act() }
    private var motion: Runnable? = null
    /** Отрезки текущей прогулки; пусто — отдых. */
    private val route = ArrayDeque<Segment>()
    /** Номер текущего маршрута: отложенные шаги старого маршрута после отмены игнорируются. */
    private var token = 0

    /** Отрезок маршрута: дойти до x на высоте дома (или null — действие на месте) и сделать что-то. */
    private class Segment(val toX: Int?, val run: Boolean, val action: PetAction?, val pauseMs: Long, val hop: Boolean = false)

    fun setDensity(d: Float) {
        density = d
    }

    /** Виджет показан заново (смена приложения, экран включился). */
    fun onShown() {
        if (!enabled) return
        token++
        cancelMotion()
        route.clear()
        schedule(firstDelay())
    }

    fun onHidden() = cancel()

    /** Пользователь начал тащить: остановить всё и выдержать паузу после. */
    fun onUserDrag() {
        token++
        cancelMotion()
        route.clear()
        handler.removeCallbacks(next)
        pausedUntil = SystemClock.uptimeMillis() + USER_PAUSE_MS
        if (enabled) schedule(USER_PAUSE_MS + Random.nextLong(10_000L))
    }

    /** Остановить всё немедленно (питомец остаётся где стоит). */
    fun cancel() {
        token++
        cancelMotion()
        route.clear()
        handler.removeCallbacks(next)
    }

    /** Прекратить прогулки; если питомец не дома — вернуться бегом. */
    fun stopAndReturn() {
        token++
        cancelMotion()
        route.clear()
        handler.removeCallbacks(next)
        val pet = host.pet() ?: return
        if (!host.canAct() || pet.isStatic) return
        if (!atHome()) goHome(pet, run = true)
    }

    /** Домашняя точка сместилась (таймер перенесли или повернули экран): маршрут заново, домой пешком. */
    fun homeMoved() {
        token++
        if (moving) { cancelMotion(); route.clear() }
        handler.removeCallbacks(next)
        schedule(1_500L + Random.nextLong(1_500L))
    }

    /** Для отладки: выполнить действие сейчас, если можно. */
    fun force(move: PetMove) {
        val pet = host.pet() ?: return
        if (!host.canAct() || pet.isStatic) return
        token++
        cancelMotion()
        route.clear()
        Log.d(TAG, "force: $move x=${host.petX()} home=${host.restX()}")
        when (move) {
            PetMove.WALK, PetMove.SLIDE -> planWalk(pet, forceRun = false)
            PetMove.RUN -> planWalk(pet, forceRun = true)
            PetMove.PEEK -> startPeek(pet)
            else -> playOnSpot(pet, move)
        }
        if (route.isNotEmpty()) nextSegment(pet)
        if (enabled) schedule(interval())
    }

    val isMoving: Boolean get() = moving

    // ---- планирование ----

    private fun firstDelay(): Long = 8_000L + Random.nextLong(interval() / 3)

    private fun interval(): Long {
        val (lo, hi) = when (level) {
            0 -> 120_000L to 300_000L
            2 -> 15_000L to 45_000L
            else -> 45_000L to 120_000L
        }
        val k = when (host.mood()) {
            MoodEngine.State.HAPPY -> 0.7f
            MoodEngine.State.CONTENT -> 1f
            MoodEngine.State.TIRED -> 1.8f
            MoodEngine.State.SAD -> 1.5f
            MoodEngine.State.EXHAUSTED -> 2.5f
            MoodEngine.State.SLEEP -> 4f
        }
        return ((lo + Random.nextLong(hi - lo)) * k * host.temper().walkRate).toLong()
    }

    private fun schedule(delay: Long) {
        handler.removeCallbacks(next)
        handler.postDelayed(next, delay)
    }

    private fun atHome(): Boolean =
        abs(host.petX() - host.restX()) <= dp(12) && abs(host.petY() - host.restY()) <= dp(12)

    private fun act() {
        if (!enabled) return
        val pet = host.pet()
        if (pet == null || !host.canAct() || pet.isStatic || moving || pet.isBusy ||
            SystemClock.uptimeMillis() < pausedUntil
        ) {
            schedule(8_000L + Random.nextLong(8_000L))
            return
        }
        val away = !atHome()
        val mood = host.mood()
        if (mood == MoodEngine.State.SLEEP) {
            // Ночью только домой, если вдруг не дома.
            if (away) goHome(pet, run = false)
            schedule(interval())
            return
        }
        val t = host.temper()
        token++
        when {
            away -> goHome(pet, run = Random.nextFloat() < t.runChance)
            Random.nextFloat() < restChance(t, mood) -> rest(pet, t, mood)
            PetMove.PEEK in pet.pet.moves && nearEdge() && Random.nextFloat() < 0.18f -> startPeek(pet)
            else -> { planWalk(pet, forceRun = null); nextSegment(pet) }
        }
        schedule(interval())
    }

    private fun restChance(t: PetDef.Temper, mood: MoodEngine.State): Float = when (mood) {
        MoodEngine.State.EXHAUSTED -> 0.9f
        MoodEngine.State.SAD, MoodEngine.State.TIRED -> max(t.restChance, 0.6f)
        MoodEngine.State.HAPPY -> t.restChance * 0.6f
        else -> t.restChance
    }

    /** Отдых на месте: сесть, прилечь, задремать, оглядеться, потянуться. */
    private fun rest(pet: PetSpriteView, t: PetDef.Temper, mood: MoodEngine.State) {
        val can = pet.pet.moves
        val pick = when {
            Random.nextFloat() < t.sleepChance && PetMove.LIE in can -> PetMove.LIE
            mood == MoodEngine.State.EXHAUSTED -> if (PetMove.LIE in can) PetMove.LIE else PetMove.SIT
            else -> listOf(PetMove.SIT, PetMove.LOOK_AROUND, PetMove.STRETCH, PetMove.WOBBLE, PetMove.WAVE)
                .filter { it in can }.randomOrNull() ?: PetMove.LOOK_AROUND
        }
        Log.d(TAG, "rest: $pick mood=$mood")
        playOnSpot(pet, pick)
    }

    private fun playOnSpot(pet: PetSpriteView, move: PetMove) {
        when (move) {
            PetMove.JUMP -> hop(pet) {}
            PetMove.WAVE -> pet.play(PetAction.WAVE)
            PetMove.SIT -> pet.play(PetAction.SIT)
            PetMove.LIE -> pet.play(PetAction.LIE)
            PetMove.LOOK_AROUND -> pet.play(PetAction.LOOK_AROUND)
            PetMove.STRETCH -> pet.play(PetAction.STRETCH)
            PetMove.WOBBLE -> pet.play(PetAction.WOBBLE)
            else -> pet.play(PetAction.LOOK_AROUND)
        }
    }

    /**
     * Маршрут прогулки: 1–4 отрезка в полосе вокруг дома (края предпочтительнее,
     * ячейка плашки исключена), между ними паузы и действия, в конце —
     * возвращение к таймеру.
     */
    private fun planWalk(pet: PetSpriteView, forceRun: Boolean?) {
        val t = host.temper()
        val rest = host.restX()
        val w = host.screenWidth()
        val band = (w * 0.45f).toInt()
        val can = pet.pet.moves
        val canRun = PetMove.RUN in can
        val budgetMs = (10_000L + Random.nextLong(30_000L)) * t.walkLength
        var used = 0f
        var from = host.petX()
        val n = (1 + Random.nextInt(3) + (if (t.walkLength > 1.1f) 1 else 0)).coerceIn(1, 4)
        route.clear()
        repeat(n) {
            val target = pickTarget(from, rest, band) ?: return@repeat
            val run = forceRun ?: (canRun && Random.nextFloat() < t.runChance)
            val dist = pathLength(Point(from, host.restY()), Point(target, host.restY()))
            if (dist < dp(30)) return@repeat
            val ms = dist / (speedDpPerSec(run) * density) * 1000f
            if (used + ms > budgetMs) return@repeat
            used += ms
            val action = midAction(can, t)
            val pause = 1_000L + Random.nextLong(4_000L)
            route.addLast(Segment(target, run, action, pause, hop = action == null && Random.nextFloat() < t.jumpChance))
            used += pause
            from = target
        }
        // Домой: последний отрезок всегда к таймеру.
        val runHome = forceRun ?: (canRun && Random.nextFloat() < t.runChance)
        route.addLast(Segment(rest, runHome, null, 0L))
        Log.d(TAG, "walk plan: ${route.size} segments from ${host.petX()} home=$rest obstacle=${host.obstacle()} budget=${budgetMs.toInt()}")
    }

    /** Допустимые x на высоте дома: внутри границ и не над плашкой. */
    private fun freeSpans(): List<IntRange> {
        val range = host.xRange()
        val o = host.obstacle() ?: return listOf(range)
        val pw = host.petWidth()
        val restY = host.restY()
        val ph = host.petHeight()
        if (restY + ph <= o.top || restY >= o.bottom) return listOf(range)
        val blocked = (o.left - pw)..o.right
        val out = ArrayList<IntRange>()
        if (range.first < blocked.first) out.add(range.first..min(range.last, blocked.first - 1))
        if (range.last > blocked.last) out.add(max(range.first, blocked.last + 1)..range.last)
        return out.filter { it.last >= it.first }
    }

    private fun pickTarget(from: Int, rest: Int, band: Int): Int? {
        val spans = freeSpans().mapNotNull { s ->
            val lo = max(s.first, rest - band)
            val hi = min(s.last, rest + band)
            if (hi >= lo) lo..hi else null
        }.filter { it.last - it.first >= dp(20) || (abs(it.first - from) >= dp(40)) }
        if (spans.isEmpty()) return null
        val s = spans.random()
        // Треть случаев — к краю полосы, иначе случайная точка.
        val x = if (Random.nextFloat() < 0.33f) (if (host.petOnLeft()) s.first else s.last)
        else s.first + Random.nextInt(s.last - s.first + 1)
        // Не топтаться на месте.
        return if (abs(x - from) < dp(40)) (if (abs(s.first - from) > abs(s.last - from)) s.first else s.last) else x
    }

    private fun midAction(can: Set<PetMove>, t: PetDef.Temper): PetAction? {
        val r = Random.nextFloat()
        return when {
            r < 0.35f -> null // просто постоять
            r < 0.55f -> PetAction.LOOK_AROUND
            r < 0.68f && PetMove.SIT in can -> PetAction.SIT
            r < 0.78f && PetMove.WAVE in can -> PetAction.WAVE
            r < 0.86f && PetMove.STRETCH in can -> PetAction.STRETCH
            r < 0.92f && PetMove.WOBBLE in can -> PetAction.WOBBLE
            r < 0.96f && PetMove.LIE in can && t.sleepChance > 0.15f -> PetAction.LIE
            else -> PetAction.LOOK_AROUND
        }
    }

    /** Следующий отрезок маршрута. */
    private fun nextSegment(pet: PetSpriteView) {
        val seg = route.removeFirstOrNull()
        if (seg == null) {
            host.onPetRest()
            return
        }
        if (!host.canAct() || !enabled && seg.toX != host.restX()) {
            route.clear()
            return
        }
        val toX = seg.toX
        val tk = token
        val afterMove = {
            pet.stopWalking()
            val afterAction = {
                handler.postDelayed({
                    if (tk != token) return@postDelayed
                    if (route.isNotEmpty()) nextSegment(pet) else host.onPetRest()
                }, seg.pauseMs)
            }
            if (tk == token) when {
                seg.hop -> hop(pet) { if (tk == token) afterAction() }
                seg.action != null -> {
                    pet.play(seg.action)
                    // Дождаться конца действия (клипы короткие), затем пауза.
                    handler.postDelayed({ if (tk == token) afterAction() }, actionMs(pet, seg.action))
                }
                else -> afterAction()
            }
        }
        if (toX == null) afterMove()
        else walkPath(pet, Point(toX, host.restY()), seg.run, afterMove)
    }

    private fun actionMs(pet: PetSpriteView, a: PetAction): Long =
        pet.pet.clip(a).durations.sum().coerceIn(600L, 12_000L)

    /** Возвращение домой одним отрезком, без телепортации. */
    private fun goHome(pet: PetSpriteView, run: Boolean) {
        val rest = host.restX()
        Log.d(TAG, "home: ${host.petX()},${host.petY()} -> $rest,${host.restY()} run=$run")
        route.clear()
        route.addLast(Segment(rest, run && PetMove.RUN in pet.pet.moves, null, 0L))
        nextSegment(pet)
    }

    // ---- путь в обход плашки ----

    /**
     * Путь от [from] до [to] (левый верхний угол окна питомца). Если прямой
     * горизонтальный отрезок задевает плашку — обход: вниз под неё (или вверх
     * над ней), по горизонтали, обратно на высоту цели.
     */
    fun pathTo(from: Point, to: Point): List<Point> {
        val o = host.obstacle() ?: return listOf(to)
        val pw = host.petWidth()
        val ph = host.petHeight()
        fun hits(y: Int, x1: Int, x2: Int): Boolean {
            if (y + ph <= o.top || y >= o.bottom) return false
            val lo = min(x1, x2)
            val hi = max(x1, x2) + pw
            return hi > o.left && lo < o.right
        }
        if (from.y == to.y && !hits(from.y, from.x, to.x)) return listOf(to)
        if (from.y != to.y && !hits(from.y, from.x, to.x) && !hits(to.y, from.x, to.x)) {
            return listOf(Point(to.x, from.y), to)
        }
        val yr = host.yRange()
        val below = o.bottom
        val above = o.top - ph
        val detourY = when {
            below <= yr.last -> below
            above >= yr.first -> above
            else -> return listOf(to) // некуда обойти — идём как есть
        }
        return listOf(Point(from.x, detourY), Point(to.x, detourY), to)
    }

    private fun pathLength(from: Point, to: Point): Float {
        var total = 0f
        var prev = from
        for (p in pathTo(from, to)) {
            total += sqrt(((p.x - prev.x) * (p.x - prev.x) + (p.y - prev.y) * (p.y - prev.y)).toFloat())
            prev = p
        }
        return total
    }

    /** Пройти к [to] по обходному пути, отрезок за отрезком. */
    private fun walkPath(pet: PetSpriteView, to: Point, run: Boolean, onDone: () -> Unit) {
        val legs = ArrayDeque(pathTo(Point(host.petX(), host.petY()), to))
        val slide = PetMove.SLIDE in pet.pet.moves
        val tk = token
        fun step() {
            if (tk != token) return
            val leg = legs.removeFirstOrNull()
            if (leg == null) { onDone(); return }
            Log.d(TAG, "leg -> ${leg.x},${leg.y} run=$run")
            animateTo(pet, Point(host.petX(), host.petY()), leg, speedDpPerSec(run), run, slide) { step() }
        }
        step()
    }

    // ---- движение ----

    private fun speedDpPerSec(run: Boolean): Float {
        val base = (if (run) 120f else 42f) * host.temper().speed
        return when (host.mood()) {
            MoodEngine.State.SAD, MoodEngine.State.TIRED -> base * 0.7f
            MoodEngine.State.EXHAUSTED -> base * 0.5f
            MoodEngine.State.HAPPY -> base * 1.1f
            else -> base
        }
    }

    private fun nearEdge(): Boolean {
        val range = host.xRange()
        val x = host.restX()
        val edge = (host.screenWidth() * 0.2f).toInt()
        return (host.petOnLeft() && x - range.first < edge) || (!host.petOnLeft() && range.last - x < edge)
    }

    /**
     * Выглянуть из-за края: дойти до края, высунуться на 45 % ширины за экран
     * (окно система за экран не пускает, поэтому сдвигается сам питомец внутри
     * окна и обрезается краем), постоять, спрятаться обратно и вернуться домой.
     */
    private fun startPeek(pet: PetSpriteView) {
        val range = host.xRange()
        val off = (host.petWidth() * 0.45f) * (if (host.petOnLeft()) -1f else 1f)
        val edge = if (host.petOnLeft()) range.first else range.last
        Log.d(TAG, "peek: ${host.petX()} -> edge $edge")
        walkPath(pet, Point(edge, host.restY()), false) {
            pet.stopWalking()
            pet.animate().translationX(off).setDuration(450).start()
            pet.play(PetAction.LOOK_AROUND)
            val hold = 3_000L + Random.nextLong(3_000L)
            val back = Runnable {
                pet.animate().translationX(0f).setDuration(450).start()
                if (!host.canAct()) return@Runnable
                goHome(pet, run = false)
            }
            motion = back
            handler.postDelayed(back, hold)
        }
    }

    /** Прыжок на месте: кадры прыжка + небольшой подскок окна. */
    private fun hop(pet: PetSpriteView, onDone: () -> Unit) {
        if (!pet.pet.has(PetAction.JUMP)) { onDone(); return }
        cancelMotion()
        pet.play(PetAction.JUMP)
        val start = SystemClock.uptimeMillis()
        val dur = 620L
        val x = host.petX()
        val y = host.petY()
        moving = true
        val step = object : Runnable {
            override fun run() {
                if (!moving) return
                val t = ((SystemClock.uptimeMillis() - start).toFloat() / dur).coerceIn(0f, 1f)
                host.setPetPos(x, y + (-sin(t * Math.PI) * dp(10)).roundToInt())
                if (t >= 1f) {
                    moving = false
                    motion = null
                    host.setPetPos(x, y)
                    onDone()
                } else handler.postDelayed(this, STEP_MS)
            }
        }
        motion = step
        handler.post(step)
    }

    /**
     * Движение по отрезку с трапецеидальным профилем скорости: разгон и
     * торможение по 300 мс, между ними постоянная скорость (в такт кадрам
     * ходьбы). Кадры: бег/ходьба по направлению x; чисто вертикальный
     * отрезок — теми же кадрами в прежнюю сторону.
     */
    private fun animateTo(
        pet: PetSpriteView, from: Point, to: Point, dpPerSec: Float, run: Boolean, bob: Boolean,
        onDone: () -> Unit
    ) {
        cancelMotion()
        val dx = to.x - from.x
        val dy = to.y - from.y
        val dist = sqrt((dx * dx + dy * dy).toFloat())
        if (dist < 1f) { onDone(); return }
        val vertical = dx == 0
        // По вертикали — медленнее: шаг «вниз/вверх» короче.
        val v = dpPerSec * density / 1000f * (if (vertical) 0.75f else 1f) // px/мс
        val ramp = min(RAMP_MS.toFloat(), dist / v / 3f)
        val cruise = ((dist - v * ramp) / v).coerceAtLeast(0f)
        val duration = (2 * ramp + cruise).toLong().coerceIn(200L, 15_000L)
        val goingRight = if (vertical) facingRight else dx > 0
        val turned = goingRight != facingRight
        facingRight = goingRight
        val start = SystemClock.uptimeMillis() + (if (turned) TURN_MS else 0L)
        moving = true
        pet.walk(if (goingRight) 1f else -1f, run)
        val step = object : Runnable {
            override fun run() {
                if (!moving) return
                if (!host.canAct()) { finish(); return }
                val e = (SystemClock.uptimeMillis() - start).toFloat()
                if (e < 0f) { handler.postDelayed(this, STEP_MS); return }
                val p = motionProgress(e, ramp, cruise)
                val x = from.x + (dx * p).roundToInt()
                val y = from.y + (dy * p).roundToInt()
                val bobY = if (bob && !vertical) (-abs(sin(p * dist / (dp(28).toFloat()) * Math.PI)) * dp(3)).roundToInt() else 0
                host.setPetPos(x, y + bobY)
                if (e >= duration) finish() else handler.postDelayed(this, STEP_MS)
            }

            private fun finish() {
                moving = false
                motion = null
                host.setPetPos(to.x, to.y)
                onDone()
            }
        }
        motion = step
        handler.post(step)
    }

    private fun cancelMotion() {
        motion?.let { handler.removeCallbacks(it) }
        motion = null
        host.pet()?.let { if (it.translationX != 0f) { it.animate().cancel(); it.translationX = 0f } }
        if (moving) {
            moving = false
            host.pet()?.stopWalking()
        }
    }

    private fun dp(v: Int): Int = (v * density + 0.5f).toInt()

    companion object {
        private const val TAG = "PetBehavior"
        private const val STEP_MS = 33L
        private const val RAMP_MS = 300L
        private const val TURN_MS = 180L
        private const val USER_PAUSE_MS = 60_000L

        /** Трапецеидальный профиль скорости; вынесен для тестов. */
        fun motionProgress(e: Float, ramp: Float, cruise: Float): Float {
            // Путь при v=1: разгон даёт ramp/2, ход — cruise, торможение — ramp/2.
            val total = ramp + cruise
            if (total <= 0f) return 1f
            val s = when {
                e <= ramp -> e * e / (2f * ramp)
                e <= ramp + cruise -> ramp / 2f + (e - ramp)
                else -> {
                    val d = (e - ramp - cruise).coerceAtMost(ramp)
                    ramp / 2f + cruise + d - d * d / (2f * ramp)
                }
            }
            return (s / total).coerceIn(0f, 1f)
        }
    }
}
