package com.timeoverlay.pet.ui

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import com.google.android.material.snackbar.Snackbar
import com.timeoverlay.pet.R
import com.timeoverlay.pet.data.AppPrefs
import com.timeoverlay.pet.data.PermissionHelper
import com.timeoverlay.pet.data.Reminders
import com.timeoverlay.pet.data.UnlockStore
import com.timeoverlay.pet.mood.DayMood
import com.timeoverlay.pet.mood.PetTalk
import com.timeoverlay.pet.overlay.OverlayPrefs
import com.timeoverlay.pet.overlay.PetOverlayService
import com.timeoverlay.pet.pet.PetAction
import com.timeoverlay.pet.pet.PetCredits
import com.timeoverlay.pet.pet.PetDef
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.Executors

/**
 * Вкладка «Питомец»: персонаж (карточка с «Применить»), поведение,
 * «Не беспокоить», напоминания и всё про плавающий виджет.
 */
class PetFragment : Fragment() {

    private val io = Executors.newSingleThreadExecutor()
    private lateinit var overlay: OverlayPrefs
    private lateinit var appPrefs: AppPrefs
    private lateinit var preview: OverlayPreview
    private var dndList: OptionList? = null
    private var bubbleText: CharSequence? = null
    private val restoreBubble = Runnable {
        val t = bubbleText ?: return@Runnable
        bubbleText = null
        view?.findViewById<TextView>(R.id.bubble)?.text = t
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_pet, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        overlay = OverlayPrefs(requireContext())
        appPrefs = AppPrefs(requireContext())
        setupPet(view)
        setupBehavior(view)
        setupDnd(view)
        setupReminders(view)
        setupOverlay(view)
    }

    override fun onResume() {
        super.onResume()
        refreshHiddenCount()
        refreshSwitch()
        refreshDnd()
        refreshReminders()
        celebrateUnlocks()
    }

    /** Питомец ставится на пол сцены так, чтобы не залезать под пузырь реплики. */
    private fun placePetBelowBubble(v: View, pet: PetSpriteView, def: PetDef, sizeRes: Int) {
        val scene = v.findViewById<SceneView>(R.id.scene)
        val bubble = v.findViewById<TextView>(R.id.bubble)
        val base = resources.getDimensionPixelSize(sizeRes)
        val gap = (8 * resources.displayMetrics.density).toInt()
        scene.placePet(pet, def, base, if (bubble.height > 0) bubble.bottom + gap else 0)
        bubble.post { if (isAdded) scene.placePet(pet, def, base, bubble.bottom + gap) }
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }

    // ---- персонаж ----

    private fun setupPet(v: View) {
        val pet = v.findViewById<PetSpriteView>(R.id.petView)
        val bubble = v.findViewById<TextView>(R.id.bubble)
        pet.setOnClickListener {
            val tap = pet.tap()
            if (bubbleText == null) bubbleText = bubble.text
            bubble.text = PetTalk.onTap(requireContext(), pet.moodState, tap)
            bubble.removeCallbacks(restoreBubble)
            bubble.postDelayed(restoreBubble, 2500)
        }
        v.findViewById<View>(R.id.characterRow).setOnClickListener {
            PetSheet.new(overlay.petId).show(childFragmentManager, "pet")
        }
        showCurrentPet(v)
        io.execute {
            val state = DayMood.todayState(v.context)
            activity?.runOnUiThread { if (isAdded) pet.setMood(state) }
        }
    }

    private fun showCurrentPet(v: View) {
        val def = PetDef.byId(overlay.petId)
        val pet = v.findViewById<PetSpriteView>(R.id.petView)
        pet.setPet(def)
        placePetBelowBubble(v, pet, def, R.dimen.pet_tab_size)
        v.findViewById<TextView>(R.id.characterName).text = def.displayName
        v.findViewById<TextView>(R.id.petSubtitle).text = getString(R.string.pet_tab_subtitle, def.displayName)
        v.findViewById<TextView>(R.id.petLicense).setText(PetCredits.licenseRes(def))
        if (::preview.isInitialized) preview.setPet(def)
        // Подсказка о следующем открытии.
        val unlocks = UnlockStore(v.context)
        val p = unlocks.progress()
        val next = PetDef.ALL.firstOrNull { it.unlock != null && !unlocks.isUnlocked(it, p) }
        val hint = v.findViewById<TextView>(R.id.unlockHint)
        if (next?.unlock == null) hint.visibility = View.GONE else {
            hint.visibility = View.VISIBLE
            hint.text = next.displayName + ": " + getString(R.string.pet_unlock_cond, next.unlock.minutes, next.unlock.days) +
                ". " + getString(R.string.pet_progress_min, p.minutes.coerceAtMost(next.unlock.minutes), next.unlock.minutes) +
                ", " + getString(R.string.pet_progress_days, p.days.coerceAtMost(next.unlock.days), next.unlock.days)
        }
    }

    /** Из карточки нажали «Применить». */
    fun onPetApplied() {
        val v = view ?: return
        showCurrentPet(v)
        v.findViewById<PetSpriteView>(R.id.petView).play(PetAction.WAVE)
    }

    /** Только что открывшиеся питомцы: короткая анимация и сообщение с кнопкой «Применить». */
    private fun celebrateUnlocks() {
        val v = view ?: return
        val fresh = UnlockStore(v.context).takeFreshlyUnlocked()
        val def = fresh.firstOrNull() ?: return
        val pet = v.findViewById<PetSpriteView>(R.id.petView)
        pet.play(PetAction.CELEBRATE)
        pet.animate().scaleX(1.08f).scaleY(1.08f).setDuration(220).withEndAction {
            pet.animate().scaleX(1f).scaleY(1f).setDuration(220).start()
        }.start()
        Snackbar.make(v, getString(R.string.pet_unlocked_msg, def.displayName), 8_000)
            .setAction(R.string.pet_apply) {
                overlay.petId = def.id
                onPetApplied()
            }.show()
        showCurrentPet(v)
    }

    // ---- поведение ----

    private fun setupBehavior(v: View) {
        bindSwitch(v.findViewById(R.id.behaviorSwitch), overlay.behavior) { overlay.behavior = it }
        val levels = OptionList(
            v.findViewById(R.id.levelList),
            listOf(getString(R.string.level_calm), getString(R.string.level_normal), getString(R.string.level_active))
        ) { overlay.activity = it }
        levels.select(overlay.activity)
        bindSwitch(v.findViewById(R.id.animSwitch), appPrefs.animations) { appPrefs.animations = it }
        bindSwitch(v.findViewById(R.id.smoothSwitch), appPrefs.smoothing) { appPrefs.smoothing = it }
    }

    // ---- не беспокоить ----

    private fun setupDnd(v: View) {
        dndList = OptionList(
            v.findViewById(R.id.dndList),
            listOf(getString(R.string.dnd_off), getString(R.string.dnd_30), getString(R.string.dnd_60), getString(R.string.dnd_forever))
        ) { i ->
            overlay.setDnd(when (i) { 1 -> 30; 2 -> 60; 3 -> 0; else -> -1 })
            refreshDnd()
        }
    }

    private fun refreshDnd() {
        val v = view ?: return
        val until = overlay.dndUntil
        val active = overlay.isDnd()
        val status = v.findViewById<TextView>(R.id.dndStatus)
        val index = when {
            !active -> 0
            until == OverlayPrefs.DND_FOREVER -> 3
            until - System.currentTimeMillis() > 30 * 60_000L -> 2
            else -> 1
        }
        dndList?.select(index)
        status.text = when {
            !active -> ""
            until == OverlayPrefs.DND_FOREVER -> getString(R.string.dnd_status)
            else -> getString(R.string.dnd_status_until, DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(until)))
        }
    }

    // ---- напоминания ----

    private fun setupReminders(v: View) {
        val list = OptionList(
            v.findViewById(R.id.reminderList),
            listOf(getString(R.string.reminders_off), getString(R.string.reminders_rare), getString(R.string.reminders_normal))
        ) { i ->
            appPrefs.reminders = i
            Reminders.schedule(v.context)
            refreshReminders()
        }
        list.select(appPrefs.reminders)
        v.findViewById<View>(R.id.reminderSettings).setOnClickListener {
            runCatching {
                startActivity(
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, v.context.packageName)
                )
            }
        }
    }

    private fun refreshReminders() {
        val v = view ?: return
        val blocked = appPrefs.reminders != 0 && !Reminders.canNotify(v.context)
        v.findViewById<View>(R.id.reminderBlocked).visibility = if (blocked) View.VISIBLE else View.GONE
        v.findViewById<View>(R.id.reminderSettings).visibility = if (blocked) View.VISIBLE else View.GONE
    }

    // ---- оверлей ----

    private fun setupOverlay(v: View) {
        v.findViewById<MaterialSwitch>(R.id.overlaySwitch)
            .setOnCheckedChangeListener { _, checked -> onSwitch(checked) }

        preview = OverlayPreview(v.context)
        preview.setPet(PetDef.byId(overlay.petId))
        v.findViewById<FrameLayout>(R.id.sizePreview).addView(preview, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        ))
        preview.apply(overlay)

        val modes = OptionList(
            v.findViewById(R.id.modeList),
            listOf(getString(R.string.mode_both), getString(R.string.mode_timer), getString(R.string.mode_pet))
        ) { i ->
            overlay.mode = OverlayPrefs.Mode.values()[i]
            preview.apply(overlay)
        }
        modes.select(overlay.mode.ordinal)

        val size: Slider = v.findViewById(R.id.sizeSlider)
        val sizeValue: TextView = v.findViewById(R.id.sizeValue)
        size.value = overlay.sizeDp.coerceIn(40, 100).toFloat()
        sizeValue.text = getString(R.string.overlay_size_value, overlay.sizeDp)
        size.addOnChangeListener { _, value, _ ->
            overlay.sizeDp = value.toInt()
            sizeValue.text = getString(R.string.overlay_size_value, value.toInt())
            preview.apply(overlay)
        }

        bindSwitch(v.findViewById(R.id.simpleSwitch), overlay.simple) { overlay.simple = it; preview.apply(overlay) }
        bindSwitch(v.findViewById(R.id.appNameSwitch), overlay.showAppName) { overlay.showAppName = it; preview.apply(overlay) }
        bindSwitch(v.findViewById(R.id.perAppSwitch), overlay.perAppPosition) { overlay.perAppPosition = it }
        bindSwitch(v.findViewById(R.id.launcherSwitch), overlay.showOnLauncher) { overlay.showOnLauncher = it }

        val opacity: Slider = v.findViewById(R.id.opacitySlider)
        val opacityValue: TextView = v.findViewById(R.id.opacityValue)
        opacity.value = overlay.opacityPercent.toFloat()
        opacityValue.text = getString(R.string.overlay_opacity_value, overlay.opacityPercent)
        opacity.addOnChangeListener { _, value, _ ->
            overlay.opacityPercent = value.toInt()
            opacityValue.text = getString(R.string.overlay_opacity_value, value.toInt())
            preview.alpha = value / 100f
        }

        v.findViewById<MaterialButton>(R.id.hiddenButton).setOnClickListener { showHiddenApps() }
    }

    private fun refreshSwitch() {
        val v = view ?: return
        val sw = v.findViewById<MaterialSwitch>(R.id.overlaySwitch)
        val on = overlay.enabled && PetOverlayService.running
        sw.setOnCheckedChangeListener(null)
        sw.isChecked = on
        sw.jumpDrawablesToCurrentState()
        sw.setOnCheckedChangeListener { _, checked -> onSwitch(checked) }
        v.findViewById<TextView>(R.id.overlayStatus).text =
            getString(if (on) R.string.overlay_status_on else R.string.overlay_status_off)
    }

    private fun onSwitch(checked: Boolean) {
        val ctx = requireContext()
        if (checked) {
            overlay.enabled = true
            if (PermissionHelper.hasOverlayRequired(ctx)) {
                overlay.stopReason = null
                PetOverlayService.start(ctx)
            } else {
                // Без разрешений — на главный, там шаги настройки.
                (activity as? MainActivity)?.openTab(R.id.tab_home)
            }
        } else {
            overlay.enabled = false
            PetOverlayService.stop(ctx)
        }
        view?.postDelayed({ refreshSwitch() }, 400)
    }

    private fun bindSwitch(sw: MaterialSwitch, value: Boolean, onChange: (Boolean) -> Unit) {
        sw.isChecked = value
        sw.setOnCheckedChangeListener { _, checked -> onChange(checked) }
    }

    private fun refreshHiddenCount() {
        val v = view ?: return
        val n = overlay.hiddenApps.size
        v.findViewById<TextView>(R.id.hiddenCount).text =
            if (n == 0) getString(R.string.overlay_hidden_none) else getString(R.string.overlay_hidden_count, n)
    }

    private fun showHiddenApps() {
        val ctx = requireContext()
        io.execute {
            val pm = ctx.packageManager
            val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(launch, 0)
                .map { it.activityInfo.packageName }
                .distinct()
                .filter { it != ctx.packageName }
                .mapNotNull { pkg ->
                    runCatching { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() }
                        .getOrNull()?.let { pkg to it }
                }
                .sortedBy { it.second.lowercase() }
            activity?.runOnUiThread {
                if (!isAdded) return@runOnUiThread
                val hidden = overlay.hiddenApps.toMutableSet()
                val labels = apps.map { it.second }.toTypedArray()
                val checked = BooleanArray(apps.size) { hidden.contains(apps[it].first) }
                AlertDialog.Builder(ctx)
                    .setTitle(R.string.overlay_hidden_apps)
                    .setMultiChoiceItems(labels, checked) { _, i, isChecked ->
                        if (isChecked) hidden.add(apps[i].first) else hidden.remove(apps[i].first)
                    }
                    .setNegativeButton(R.string.cancel, null)
                    .setPositiveButton(android.R.string.ok) { _, _ ->
                        overlay.hiddenApps = hidden
                        refreshHiddenCount()
                    }
                    .show()
            }
        }
    }
}
