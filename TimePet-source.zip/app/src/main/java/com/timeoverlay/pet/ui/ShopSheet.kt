package com.timeoverlay.pet.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.button.MaterialButton
import com.timeoverlay.pet.R
import com.timeoverlay.pet.data.PerksStore
import java.text.DateFormat
import java.util.Date

/**
 * Магазин: баланс очков и три покупки (вкусняшка, энергетик, ночной режим
 * выкл). Очки начисляет [PerksStore] за продуктивное время; после покупки
 * главный экран и сервис пересчитывают настроение сами (слушатели prefs).
 */
class ShopSheet : BottomSheetDialogFragment() {

    private lateinit var perks: PerksStore

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.sheet_shop, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        perks = PerksStore(requireContext())
        val list = view.findViewById<ViewGroup>(R.id.perkList)
        val inflater = LayoutInflater.from(view.context)
        for (perk in PerksStore.Perk.values()) {
            val row = inflater.inflate(R.layout.item_perk, list, false)
            row.findViewById<TextView>(R.id.perkTitle).setText(title(perk))
            row.findViewById<TextView>(R.id.perkDesc).setText(desc(perk))
            row.findViewById<MaterialButton>(R.id.perkBuy).setOnClickListener { buy(perk) }
            row.tag = perk
            list.addView(row)
        }
        refresh()
    }

    private fun buy(perk: PerksStore.Perk) {
        val ok = perks.buy(perk)
        if (!ok) Toast.makeText(requireContext(), R.string.shop_not_enough, Toast.LENGTH_SHORT).show()
        else Toast.makeText(requireContext(), R.string.shop_bought, Toast.LENGTH_SHORT).show()
        refresh()
        (parentFragment as? HomeFragment)?.onPerksChanged()
    }

    private fun refresh() {
        val v = view ?: return
        v.findViewById<TextView>(R.id.shopBalance).text = getString(R.string.points_label, perks.balance)
        val list = v.findViewById<ViewGroup>(R.id.perkList)
        val now = System.currentTimeMillis()
        for (i in 0 until list.childCount) {
            val row = list.getChildAt(i)
            val perk = row.tag as PerksStore.Perk
            val active = perks.isActive(perk, now)
            val state = row.findViewById<TextView>(R.id.perkState)
            state.visibility = if (active) View.VISIBLE else View.GONE
            state.text = when (perk) {
                PerksStore.Perk.NIGHT_OFF -> getString(
                    R.string.shop_until, DateFormat.getDateInstance(DateFormat.SHORT).format(Date(perks.nightOffUntil(now)))
                )
                else -> getString(R.string.shop_active)
            }
            row.findViewById<MaterialButton>(R.id.perkBuy).apply {
                text = if (active) getString(R.string.shop_active) else getString(R.string.shop_cost, perk.cost)
                isEnabled = !active && perks.balance >= perk.cost
            }
        }
    }

    private fun title(p: PerksStore.Perk) = when (p) {
        PerksStore.Perk.TREAT -> R.string.perk_treat_title
        PerksStore.Perk.ENERGY_DRINK -> R.string.perk_energy_title
        PerksStore.Perk.NIGHT_OFF -> R.string.perk_night_off_title
    }

    private fun desc(p: PerksStore.Perk) = when (p) {
        PerksStore.Perk.TREAT -> R.string.perk_treat_desc
        PerksStore.Perk.ENERGY_DRINK -> R.string.perk_energy_desc
        PerksStore.Perk.NIGHT_OFF -> R.string.perk_night_off_desc
    }
}
