package com.timeoverlay.pet.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.timeoverlay.pet.R
import com.timeoverlay.pet.data.AppCategoryStore
import com.timeoverlay.pet.data.Category
import com.timeoverlay.pet.data.TimeFormat
import com.timeoverlay.pet.data.UsageRepository

/**
 * Список приложений: иконка, название, категория (маленький тег), время.
 * Сортировка по времени — снаружи (репозиторий уже отдаёт по убыванию).
 * Тап открывает подробности с изменением категории.
 */
class AppUsageAdapter(
    private val categories: AppCategoryStore,
    private val onClick: (UsageRepository.AppUsage) -> Unit
) : ListAdapter<UsageRepository.AppUsage, AppUsageAdapter.Holder>(DIFF) {

    private var maxMillis: Long = 1L

    fun submit(data: List<UsageRepository.AppUsage>) {
        maxMillis = data.maxOfOrNull { it.millis }?.coerceAtLeast(1L) ?: 1L
        submitList(data)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_app_usage, parent, false)
        return Holder(v)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class Holder(v: View) : RecyclerView.ViewHolder(v) {
        private val icon: ImageView = v.findViewById(R.id.icon)
        private val name: TextView = v.findViewById(R.id.name)
        private val time: TextView = v.findViewById(R.id.time)
        private val category: TextView = v.findViewById(R.id.category)

        fun bind(a: UsageRepository.AppUsage) {
            if (a.icon != null) icon.setImageDrawable(a.icon)
            else icon.setImageResource(android.R.drawable.sym_def_app_icon)
            name.text = a.label
            time.text = TimeFormat.long(itemView.context, a.millis)
            val c = categories.categoryOf(a.packageName)
            category.text = categoryLabel(c)
            category.setTextColor(categoryColor(itemView.context, c))
            itemView.setOnClickListener { onClick(a) }
        }

        private fun categoryLabel(c: Category): String = when (c) {
            Category.PRODUCTIVE -> itemView.context.getString(R.string.cat_productive)
            Category.LAZY -> itemView.context.getString(R.string.cat_lazy)
            Category.NEUTRAL -> ""
            Category.EXCLUDED -> itemView.context.getString(R.string.cat_excluded_short)
        }

        private fun categoryColor(ctx: android.content.Context, c: Category): Int = when (c) {
            Category.PRODUCTIVE -> ContextCompat.getColor(ctx, R.color.productive)
            Category.LAZY -> ContextCompat.getColor(ctx, R.color.lazy)
            Category.NEUTRAL -> ContextCompat.getColor(ctx, R.color.neutral)
            Category.EXCLUDED -> ctx.themeColor(R.attr.tp_text_muted)
        }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<UsageRepository.AppUsage>() {
            override fun areItemsTheSame(
                a: UsageRepository.AppUsage, b: UsageRepository.AppUsage
            ): Boolean = a.packageName == b.packageName

            override fun areContentsTheSame(
                a: UsageRepository.AppUsage, b: UsageRepository.AppUsage
            ): Boolean = a == b
        }
    }
}
